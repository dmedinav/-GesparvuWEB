# Change Log
All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](http://keepachangelog.com/)
and this project adheres to [Semantic Versioning](http://semver.org/).

## 1.0.0 - 2019-10-16

### Added
- Disable checkbox for IPE.


## 0.6.0 - 2019-08-13

### Added
- Enrollment pages with logic.
- Monthly attendance logic.
- Service for new pages.
- Small width guard.
- Unit test for new pages, services and guards.


## 0.5.0 - 2019-07-26

### Added
- Exceptions calendar section.
- Fill day with service information in calendar.
- Exception creation based on selected day.
- Calendar logic.
- Calendar event handling with tooltip on click.

## 0.4.0 - 2019-07-15

### Added
- Login page with token saving.
- HTTP Interceptor for authenticated request.
- Guards for auth and no auth routes.
- Error handling.
- Add movement to enrollment.
- Enrollment search to add a movement.


## 0.3.0 - 2019-06-25

### Changed
- Complete style modification based on new design.
- Responsive style for daily attendance.
- Service request for daily attendance instead of monthly.
- New logic for daily attendance table.

## 0.2.0 - 2019-06-14

### Added
- Exception creation logic with service call.
- Exception creation button.
- Holiday filter in calendar.
- Exception filter in calendar.
- Attendande code mapping with backend.

## 0.1.0 - 2019-06-04

### Added
- Add Unit Test.
- All absent buttons with logic.
- All presents buttons with logic.
- Attendance update with backend call.
- Date logic for routed params.
- Components creation for enrollment table.
- Service requests to the backend for enrollment list.
- Set environments.
- Project base and setup.