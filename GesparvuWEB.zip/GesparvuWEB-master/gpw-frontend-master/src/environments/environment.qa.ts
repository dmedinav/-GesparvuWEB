export const environment = {
    production: false,
    JUNJI_RAD_API_URL: 'https://appqaprg001.azurewebsites.net'
};
