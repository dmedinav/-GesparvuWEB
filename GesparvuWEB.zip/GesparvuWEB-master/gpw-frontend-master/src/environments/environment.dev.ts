export const environment = {
    production: false,
    JUNJI_RAD_API_URL: 'https://appdevprg001.azurewebsites.net'
};
