export const environment = {
    production: true,
    JUNJI_RAD_API_URL: 'https://appprodprg001.azurewebsites.net'
};
