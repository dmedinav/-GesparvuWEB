import { RouterTestingModule } from '@angular/router/testing';
import { EnrollmentServiceMock } from '../../mocks/enrollments.mocks';
import { EnrollmentService } from '@services/enrollment/enrollment.service';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { PrimaryButtonModule } from '../../components/primary-button/primary-button.module';
import { DefaultImageContainerModule } from '../../components/default-image-container/default-image-container.module';
import { MaterialModule } from '../../material.module';
import { ReactiveFormsModule } from '@angular/forms';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { InfantSearchComponent } from './infant-search.component';
import { BrowserDynamicTestingModule } from '@angular/platform-browser-dynamic/testing';
import { GenericModalComponent } from '../../components/generic-modal/generic-modal.component';
import { SecondaryButtonModule } from '../../components/secondary-button/secondary-button.module';
import { HttpClientModule } from '@angular/common/http';
import { RouterMovementsMock } from '../../mocks/router.mock';
import { Router } from '@angular/router';
import { InfantService } from '../../services/infant/infant.service';
import { InfantServiceMock, infantBaseMock, infantNotNewMock, infantPostMock, infantWithRutMock } from '../../mocks/infant.mock';
import { ISimpleGroup } from '../../common/interfaces/groups.interface';
import { ISexuality } from '../../common/interfaces/infant.interface';

describe('InfantSearchComponent', () => {
  let component: InfantSearchComponent;
  let fixture: ComponentFixture<InfantSearchComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [InfantSearchComponent, GenericModalComponent],
      imports: [
        RouterTestingModule,
        BrowserAnimationsModule,
        ReactiveFormsModule,
        MaterialModule,
        DefaultImageContainerModule,
        PrimaryButtonModule,
        SecondaryButtonModule,
        HttpClientModule,
      ],
      providers: [
        { provide: Router, useClass: RouterMovementsMock },
        { provide: EnrollmentService, useClass: EnrollmentServiceMock },
        { provide: InfantService, useClass: InfantServiceMock },
      ],
    })
      .overrideModule(BrowserDynamicTestingModule, { set: { entryComponents: [GenericModalComponent] } })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(InfantSearchComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  xdescribe('showLoader', () => {

    beforeEach(() => {
      component.searchNoRut.setValue(false);
      component.areSexualitiesLoaded.isLoaded = false;
      component.isGroupsLoaded.isLoaded = false;
      component.isDataLoaded.isLoaded = true;
      spyOn(sessionStorage, 'getItem').and.returnValue(false);
    });

    it('should return true case 1', () => {
      component.searchNoRut.setValue(true);
      component.areSexualitiesLoaded.isLoaded = true;
      component.isGroupsLoaded.isLoaded = false;
      expect(component.showLoader).toBeTruthy();

      component.areSexualitiesLoaded.isLoaded = false;
      component.isGroupsLoaded.isLoaded = true;
      expect(component.showLoader).toBeTruthy();
    });

    it('should return true case 2', () => {
      component.isDataLoaded.isLoaded = false;
      expect(component.showLoader).toBeTruthy();
    });

    it('should return true case 3', () => {
      component.searchNoRut.setValue(false);
      component.isDataLoaded.isLoaded = false;

      component.areSexualitiesLoaded.isLoaded = true;
      component.isGroupsLoaded.isLoaded = false;
      expect(component.showLoader).toBeTruthy();

      component.areSexualitiesLoaded.isLoaded = false;
      component.isGroupsLoaded.isLoaded = true;
      expect(component.showLoader).toBeTruthy();
    });

  });

  describe('Without infant in sessionStorage', () => {

    it('should create', () => {
      expect(component).toBeTruthy();
    });

    it('should format a rut', () => {
      component.searchRut.setValue('111111111');
      component.rutFormatter();
      expect(component.searchRut.value).toBe('11.111.111-1');
    });

  });

  describe('With new infant in sessionStorage', () => {

    beforeEach(() => {
      spyOn(sessionStorage, 'getItem').and.returnValue(JSON.stringify(infantBaseMock));
      fixture = TestBed.createComponent(InfantSearchComponent);
      component = fixture.componentInstance;
      fixture.detectChanges();
    });

    it('should create', () => {
      expect(component).toBeTruthy();
    });

  });

  describe('With new infant with rut in sessionStorage', () => {

    beforeEach(() => {
      spyOn(sessionStorage, 'getItem').and.returnValue(JSON.stringify(infantWithRutMock));
      fixture = TestBed.createComponent(InfantSearchComponent);
      component = fixture.componentInstance;
      fixture.detectChanges();
    });

    it('should create', () => {
      expect(component).toBeTruthy();
    });

  });

  describe('With not new infant in sessionStorage', () => {

    beforeEach(() => {
      spyOn(sessionStorage, 'getItem').and.returnValue(JSON.stringify(infantNotNewMock));
      fixture = TestBed.createComponent(InfantSearchComponent);
      component = fixture.componentInstance;
      fixture.detectChanges();
    });

    it('should create', () => {
      expect(component).toBeTruthy();
    });

  });

  describe('With no infant in sessionStorage', () => {

    it('should search infant', async () => {
      component.searchRut.setValue('11111111-1');
      await component.searchInfant(component.searchInfantForm.value);
      expect(component.isDataLoaded.isLoaded).toBeTruthy();
      expect(component.newInfant.new).toBeFalsy();
    });

    it('should search infant with K rut', async () => {
      component.searchRut.setValue('76271714-K');
      await component.searchInfant(component.searchInfantForm.value);
      expect(component.isDataLoaded.isLoaded).toBeTruthy();
      expect(component.newInfant.new).toBeFalsy();
    });

    it('should search infant with 0 as DV', async () => {
      component.searchRut.setValue('90753000-0');
      await component.searchInfant(component.searchInfantForm.value);
      expect(component.isDataLoaded.isLoaded).toBeTruthy();
      expect(component.newInfant.new).toBeFalsy();
    });

    it('should not search if rut is invalid', async () => {
      // tslint:disable-next-line: no-string-literal
      const infantServiceSpy = spyOn(component['infantService'], 'getSimInfantByRut').and.callThrough();
      component.searchRut.setValue('invalid');
      fixture.detectChanges();
      await component.searchInfant(component.searchInfantForm.value);
      expect(infantServiceSpy).toHaveBeenCalledTimes(0);
      expect(component.isDataLoaded.isLoaded).toBeTruthy();
      expect(component.isDataLoaded.hasErrors).toBeFalsy();
    });

    it('should get an error when search an infant', async () => {
      // tslint:disable-next-line: no-string-literal
      const infantServiceSpy = spyOn(component['infantService'], 'getSimInfantByRut').and.callThrough();
      component.searchRut.setValue('66666666-6');
      fixture.detectChanges();
      await component.searchInfant(component.searchInfantForm.value);
      expect(infantServiceSpy).toHaveBeenCalledTimes(1);
      expect(component.isDataLoaded.isLoaded).toBeTruthy();
      expect(component.isDataLoaded.hasErrors).toBeTruthy();
    });

    it('should get an error when search an infant with not found code', async () => {
      // tslint:disable-next-line: no-string-literal
      const infantServiceSpy = spyOn(component['infantService'], 'getSimInfantByRut').and.callThrough();
      component.searchRut.setValue('77777777-7');
      fixture.detectChanges();
      await component.searchInfant(component.searchInfantForm.value);
      expect(infantServiceSpy).toHaveBeenCalledTimes(1);
      expect(component.isDataLoaded.isLoaded).toBeTruthy();
      expect(component.isDataLoaded.hasErrors).toBeTruthy();
      expect(component.newInfant.new).toBeTruthy();
    });

    describe('createNewInfant', () => {

      beforeEach(async () => {
        fixture = TestBed.createComponent(InfantSearchComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
        // tslint:disable-next-line: no-string-literal
        spyOn(component['groupService'], 'getGroupsByTeacher').and.returnValue([{ id: 1, name: 'A' }] as ISimpleGroup[]);
        // tslint:disable-next-line: no-string-literal
        spyOn(component['sexualityService'], 'getSexualities').and.returnValue([{ id: 1, description: 'M' }] as ISexuality[]);
        await component.getSexualities();
        await component.getGroups();
        component.newInfant = infantPostMock;
      });

      it('should create an infant with rut', async () => {
        const navigateSpy = spyOn(component, 'navigateToDetails').and.callThrough();

        component.searchNoRut.setValue(false);
        component.simpleFillForm();
        await component.createNewInfant();

        expect(component.newInfant.rut).toBeDefined();
        expect(navigateSpy).toHaveBeenCalled();
      });

      it('should create an infant without rut', async () => {
        const navigateSpy = spyOn(component, 'navigateToDetails').and.callThrough();

        component.searchNoRut.setValue(true);
        component.infantForm.enable();
        component.simpleFillForm();
        await component.createNewInfant();

        expect(component.newInfant.rut).toBeUndefined();
        expect(navigateSpy).toHaveBeenCalled();
      });

      it('should not create an infant', async () => {
        const navigateSpy = spyOn(component, 'navigateToDetails').and.callThrough();
        await component.createNewInfant();
        expect(navigateSpy).toHaveBeenCalledTimes(0);
      });

    });

  });

});
