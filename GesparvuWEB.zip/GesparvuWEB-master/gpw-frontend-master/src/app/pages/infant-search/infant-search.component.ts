import { Component, OnInit, OnDestroy } from '@angular/core';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
import { InfantService } from '../../services/infant/infant.service';
import { ModalService } from '../../services/modal/modal.service';
import { Router } from '@angular/router';
import { IDataLoaded, IDefaultImageContainer } from '../../common/interfaces/default.interface';
import { IInfant, ISexuality, IInfantCreation } from '../../common/interfaces/infant.interface';
import { DEFAULT_ERROR_MESSAGE_CONTAINER } from '../../common/constants/default-image-container-messages';
import { SexualityService } from '../../services/sexuality/sexuality.service';
import { Subscription } from 'rxjs';
import { ENROLLMENT_NOT_FOUND } from '../../common/constants/response-codes.constants';
import { GroupService } from '../../services/group/group.service';
import { ISimpleGroup } from '../../common/interfaces/groups.interface';
import { INFANT_SESSION_STORAGE_KEY } from '../../common/constants/default.constants';
import Utils from '../../common/utils/utils';
import { validateRut } from '../../common/validators/rut-validator';
import { HOME_ROUTE, INFANT_CREATION_DETAILS_ROUTE } from '../../common/constants/routes.constants';

@Component({
  selector: 'app-infant-search',
  templateUrl: './infant-search.component.html',
  styleUrls: ['./infant-search.component.scss']
})

export class InfantSearchComponent implements OnInit, OnDestroy {

  searchInfantForm: FormGroup;
  infantForm: FormGroup;
  infantFormInitialValues: any;
  isDataLoaded: IDataLoaded;
  areSexualitiesLoaded: IDataLoaded;
  errorMessage: IDefaultImageContainer;
  infant: IInfant;
  newInfant: IInfantCreation;
  sexualities: ISexuality[];
  cautionMessage: IDefaultImageContainer;
  subscription: Subscription;
  notFound: boolean;
  isGroupsLoaded: IDataLoaded;
  groups: ISimpleGroup[];
  deleteSessionStorage: boolean;
  isPresentLabel: string;
  infantInSessionStorage: boolean;
  minEnrollmentDate: Date;
  maxEnrollmentDate: Date;

  get searchRut() { return this.searchInfantForm.controls.rut; }
  get searchNoRut() { return this.searchInfantForm.controls.noRut; }
  get infantRut() { return this.infantForm.controls.rut; }
  get infantNames() { return this.infantForm.controls.names; }
  get infantFathersLastname() { return this.infantForm.controls.fathersLastname; }
  get infantMothersLastname() { return this.infantForm.controls.mothersLastname; }
  get infantBirthDate() { return this.infantForm.controls.birthDate; }
  get infantSexuality() { return this.infantForm.controls.sexuality; }
  get infantIsPresent() { return this.infantForm.controls.isPresent; }

  get showLoader() {
    /* istanbul ignore next */
    return (
      (!this.isDataLoaded.isLoaded) ||
      (!this.isDataLoaded.isLoaded && (!this.areSexualitiesLoaded.isLoaded || !this.isGroupsLoaded.isLoaded)) ||
      (this.infantInSessionStorage && (!this.areSexualitiesLoaded.isLoaded || !this.isGroupsLoaded.isLoaded))
    );
  }

  get showInfantData() {
    /* istanbul ignore next */
    return (
      (this.isGroupsLoaded.isLoaded && this.areSexualitiesLoaded.isLoaded && this.isDataLoaded.isLoaded) &&
      (
        this.infant ||
        (this.isDataLoaded.hasErrors && this.isDataLoaded.isLoaded && this.notFound)
      )
    );
  }

  get showIPEFormLink() {
    return this.searchInfantForm.controls.noRut.value;
  }

  constructor(
    private formBuilder: FormBuilder,
    private infantService: InfantService,
    private sexualityService: SexualityService,
    public readonly groupService: GroupService,
    public modalService: ModalService,
    public router: Router,
  ) {
    this.isDataLoaded = {
      hasErrors: false,
      isLoaded: true,
    };
    this.areSexualitiesLoaded = {
      hasErrors: false,
      isLoaded: false,
    };
    this.isGroupsLoaded = {
      hasErrors: false,
      isLoaded: false,
    };
    this.errorMessage = DEFAULT_ERROR_MESSAGE_CONTAINER;
    this.infant = null;
    this.cautionMessage = null;
    this.subscription = new Subscription();
    this.notFound = false;
    this.newInfant = {} as IInfantCreation;
    this.deleteSessionStorage = true;
    this.infantInSessionStorage = false;

    // Set `minEnrollmentDate` to be the first day of the previous month and
    // set `maxEnrollmentDate` to be the last day of the curent month
    const today = new Date();
    this.minEnrollmentDate = new Date(today.getUTCFullYear(), today.getUTCMonth() - 2, 1);
    this.maxEnrollmentDate = new Date(today.getUTCFullYear(), today.getUTCMonth() + 1, 0);
  }

  ngOnInit() {
    this.getSexualities();
    this.getGroups();

    this.searchInfantForm = this.formBuilder.group({
      rut: new FormControl('', Validators.compose([
        Validators.required,
        validateRut
      ])),
      noRut: new FormControl(false, Validators.compose([])),
    });

    this.infantForm = this.formBuilder.group({
      rut: new FormControl(null, Validators.compose([Validators.required])),
      names: new FormControl(null, Validators.compose([Validators.required, Validators.maxLength(100)])),
      fathersLastname: new FormControl(null, Validators.compose([Validators.required, Validators.maxLength(100)])),
      mothersLastname: new FormControl(null, Validators.compose([Validators.maxLength(100)])),
      birthDate: new FormControl(),
      enrollmentDate: new FormControl(new Date(), Validators.compose([Validators.required])),
      sexuality: new FormControl(),
      group: new FormControl(null, Validators.compose([Validators.required])),
      isPresent: new FormControl(false)
    });
    this.infantFormInitialValues = this.infantForm.value;

    this.subscription.add(this.searchNoRut.valueChanges.subscribe(() => {
      this.disableSearch();
    }));

    this.subscription.add(this.infantIsPresent.valueChanges.subscribe(() => {
      this.changeIsPresentLabel();
    }));

    this.loadFromSessionStorage();
  }

  ngOnDestroy() {
    if (this.deleteSessionStorage) {
      sessionStorage.clear();
    }
    this.subscription.unsubscribe();
  }

  public rutFormatter() {
    const rut = Utils.formatToRut(this.searchInfantForm.value.rut);
    this.searchInfantForm.patchValue({
      rut
    });
  }

  public changeIsPresentLabel() {
    this.isPresentLabel = this.infantIsPresent.value ? 'Presente' : 'Ausente';
  }

  public loadFromSessionStorage() {
    const sessionInfant = sessionStorage.getItem(INFANT_SESSION_STORAGE_KEY);

    if (sessionInfant) {
      this.infantInSessionStorage = true;
      this.newInfant = JSON.parse(sessionInfant);
      this.loadNewInfant();
    }
  }

  public loadNewInfant() {
    this.infant = {} as IInfant;

    // Disable infant form if the infant is normalized
    if (!this.newInfant.new && this.newInfant.normalized) {
      this.disableInfantInfoFields();
    }

    // Disable infant rut if loaded infant does not exists yet
    if (this.newInfant.new) {
      this.infantRut.disable();
    }

    this.searchRut.setValue(this.newInfant.rut);
    this.simpleFillForm();
  }

  public disableSearch() {
    if (this.searchNoRut.value) {
      Utils.disableFields([this.searchRut, this.infantForm]);
    } else {
      this.searchRut.enable();
      this.infantForm.enable();

      // Disable infant form if the infant is normalized
      const shouldDisableInfantInfoFields = this.infantInSessionStorage
        ? !this.newInfant.new && this.newInfant.normalized
        : this.infant && this.infant.normalized;
      if (shouldDisableInfantInfoFields) {
        this.disableInfantInfoFields();
      }

      // Disable infant rut if loaded infant does not exists yet
      if (this.newInfant.new) {
        this.infantRut.disable();
      }
    }
  }

  public disableInfantInfoFields() {
    Utils.disableFields([
      this.infantRut,
      this.infantNames,
      this.infantFathersLastname,
      this.infantMothersLastname,
      this.infantBirthDate,
      this.infantSexuality
    ]);
  }

  public clearInfantForm() {
    this.infantForm.reset(this.infantFormInitialValues);
    this.infantForm.enable();
  }

  public simpleFillForm() {
    Object.keys(this.infantForm.controls).forEach(key => {
      this.infantForm.controls[key].setValue(this.newInfant[key]);
    });
  }

  public fillInfantForm() {
    Object.keys(this.infantForm.controls).forEach(key => {
      if (key === 'rut') {
        this.infantForm.controls[key].setValue(this.infant.rut + '-' + this.infant.rutDv);
      } else if (key !== 'group' && key !== 'isPresent' && key !== 'enrollmentDate') {
        this.infantForm.controls[key].setValue(this.infant[key]);
      }
    });
  }

  public async searchInfant(formValue) {
    if (this.searchInfantForm.valid && !this.searchNoRut.value) {
      const rut = formValue.rut.replace(/\./g, '');
      this.isDataLoaded.isLoaded = false;
      this.isDataLoaded.hasErrors = false;
      this.notFound = false;

      // Clear infant form and enable it in case fields were disabled
      this.clearInfantForm();
      this.infantInSessionStorage = false;

      try {
        const response = await this.infantService.getSimInfantByRut(rut);
        this.infant = response;
        this.fillInfantForm();

        // Set `this.newinfant` as not new
        this.newInfant.new = false;

        // Disable infant form if the infant is normalized
        if (this.infant.normalized) {
          this.disableInfantInfoFields();
        }
      } catch (err) {
        this.errorMessage.title = err.errorMessage;
        this.isDataLoaded.hasErrors = true;
        this.clearInfantForm();

        if (err.code === ENROLLMENT_NOT_FOUND) {
          this.notFound = true;

          // Set `this.newinfant` as new
          this.newInfant.new = true;

          // Disable infant rut if loaded infant does not exists yet
          this.infantRut.setValue(this.searchRut.value);
          this.infantRut.disable();
        } else {
          this.infant = null;
          this.searchRut.reset();
          this.modalService.openModal(this.errorMessage);
        }
      }
      this.isDataLoaded.isLoaded = true;
    }
  }

  public async getSexualities() {
    this.areSexualitiesLoaded.isLoaded = false;
    this.areSexualitiesLoaded.hasErrors = false;
    try {
      this.sexualities = await this.sexualityService.getSexualities();
    } catch (err) {
      this.errorMessage.title = err.errorMessage;
      this.areSexualitiesLoaded.hasErrors = true;
      this.modalService.openModal(this.errorMessage);
    }
    this.areSexualitiesLoaded.isLoaded = true;
  }

  public async getGroups() {
    this.isGroupsLoaded.isLoaded = false;
    this.isGroupsLoaded.hasErrors = false;
    this.groups = [];
    try {
      this.groups = await this.groupService.getGroupsByTeacher();
    } catch (err) {
      this.errorMessage.title = err.errorMessage;
      this.isGroupsLoaded.hasErrors = true;
      this.modalService.openModal(this.errorMessage);
    }
    this.isGroupsLoaded.isLoaded = true;
  }

  public createNewInfant() {
    if (this.infantForm.valid) {
      const isNew = this.newInfant.new;

      this.newInfant = this.infantForm.getRawValue();
      this.newInfant.new = isNew;

      if (this.infant) {
        this.newInfant.normalized = this.infant.normalized;
      }

      const infantSexuality = this.sexualities.find(s => s.id === this.newInfant.sexuality);
      this.newInfant.sexualityName = infantSexuality ? infantSexuality.description : '';
      this.newInfant.groupName = this.groups.find(g => g.id === this.newInfant.group).name;

      sessionStorage.setItem(INFANT_SESSION_STORAGE_KEY, JSON.stringify(this.newInfant));

      this.deleteSessionStorage = false;
      this.navigateToDetails();
    }
  }

  public navigateToDetails() {
    this.router.navigateByUrl(`${HOME_ROUTE}/${INFANT_CREATION_DETAILS_ROUTE}`);
  }
}
