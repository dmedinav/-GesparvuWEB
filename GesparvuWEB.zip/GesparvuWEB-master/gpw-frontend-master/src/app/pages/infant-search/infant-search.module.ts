import { CommonAppModule } from '../../common/common.module';
import { ReactiveFormsModule } from '@angular/forms';
import { Routes, RouterModule } from '@angular/router';
import { InfantSearchComponent } from './infant-search.component';
import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { PrimaryButtonModule } from '../../components/primary-button/primary-button.module';

const routes: Routes = [
  {
    path: '',
    component: InfantSearchComponent,
  },
];

@NgModule({
  imports: [
    CommonModule,
    ReactiveFormsModule,
    RouterModule.forChild(routes),
    PrimaryButtonModule,
    CommonAppModule,
  ],
  declarations: [
    InfantSearchComponent
  ],
  exports: [
    InfantSearchComponent
  ]
})
export class InfantSearchModule { }
