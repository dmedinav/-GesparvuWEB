import { SCREEN_WIDTH } from './../../common/constants/screen-width';
import { SUCCESS_DEFAULT_SAVE_CONTAINER, EMPTY_GROUP_LIST_CONTAINER } from './../../common/constants/default-image-container-messages';
import { ExceptionServiceMock } from './../../mocks/exceptions.mocks';
import { ExceptionService } from './../../services/exception/exception.service';
import { GroupServiceMock, groupsMock, GroupServiceEmptyMock, GroupServiceRejectMock } from './../../mocks/groups.mocks';
import { GroupService } from '@services/group/group.service';
import { RouterMovementsMock } from './../../mocks/router.mock';
import { ReactiveFormsModule } from '@angular/forms';
import { CalendarModule } from './../../components/calendar/calendar.module';
import { PrimaryButtonModule } from './../../components/primary-button/primary-button.module';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MaterialModule } from '../../material.module';
import { TestBed, async, ComponentFixture } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { ExceptionsComponent } from './exceptions.component';
import { HttpClientModule } from '@angular/common/http';
import { DefaultImageContainerModule } from '../../components/default-image-container/default-image-container.module';
import { Router } from '@angular/router';
import { calendarInformationMock } from '../../mocks/calendar.mock';
import { HOME_ROUTE } from '../../common/constants/routes.constants';

// tslint:disable:no-string-literal
describe('ExceptionsComponent', () => {

  let component: ExceptionsComponent;
  let fixture: ComponentFixture<ExceptionsComponent>;

  describe('Normal behavior', () => {
    beforeEach(async(() => {
      TestBed.configureTestingModule({
        imports: [
          RouterTestingModule,
          BrowserAnimationsModule,
          PrimaryButtonModule,
          CalendarModule,
          MaterialModule,
          ReactiveFormsModule,
          DefaultImageContainerModule,
          HttpClientModule,
        ],
        declarations: [
          ExceptionsComponent,
        ],
        providers: [
          { provide: Router, useClass: RouterMovementsMock },
          { provide: GroupService, useClass: GroupServiceMock },
          { provide: ExceptionService, useClass: ExceptionServiceMock },
        ]
      }).compileComponents();
      fixture = TestBed.createComponent(ExceptionsComponent);
      component = fixture.componentInstance;
      fixture.detectChanges();
    }));

    it('should disable exception form', async () => {
      fixture.whenStable().then(async () => {
        const date = new Date('2019-01-02T00:00:00');
        expect(component.exceptionCreationForm.disabled).toBe(false);
        component.updateCurrentDate(date);
        expect(component.exceptionCreationForm.disabled).toBe(true);
      });
    });

    it('should get calendar information ', async () => {
      fixture.whenStable().then(async () => {
        const date = new Date('2019-01-01T00:00:00');
        expect(component.calendarInformation).toBe(calendarInformationMock);
        expect(component.isCalendarLoaded.hasErrors).toBe(false);
      });
    });

    it('should not get calendar information if service throw error', async () => {
      fixture.whenStable().then(async () => {
        const modalSpy = spyOn(component['modalService'], 'openModal').and.returnValue({});
        spyOn(component['exceptionService'], 'getCalendarInformation').and.returnValue(Promise.reject({ errorMessage: 'error' }));
        const date = new Date('2019-01-01T00:00:00');
        await component.getCalendarInformation(date);
        expect(modalSpy).toHaveBeenCalledTimes(1);
        expect(component.isCalendarLoaded.hasErrors).toBe(true);
      });
    });

    it('should call next on resetTooltip observable', async () => {
      fixture.whenStable().then(async () => {
        const resetSpy = spyOn(component.resetTooltip, 'next').and.returnValue({});
        expect(resetSpy).toHaveBeenCalledTimes(0);
        component.resetCalendarTooltip();
        expect(resetSpy).toHaveBeenCalledTimes(1);
      });
    });

    it('should set selectedGroup if exceptionForm is with new value', async () => {
      fixture.whenStable().then(async () => {
        expect(component.selectedGroupName).toBe(groupsMock[0].name);
        component.groupSelectionForm.patchValue({ group: groupsMock[1].id });
        component.updateSelectedGroupName();
        fixture.detectChanges();
        expect(component.selectedGroupName).toBe(groupsMock[1].name);
      });
    });

    it('should create an exception when exception service is call without errors', async () => {
      fixture.whenStable().then(async () => {
        const modalSpy = spyOn(component['modalService'], 'openModal').and.returnValue({});
        component.updateForm('exceptionType', 1);
        component.updateForm('description', 'Description');
        await component.createException(component.exceptionCreationForm.value);
        expect(modalSpy).toHaveBeenCalledWith(SUCCESS_DEFAULT_SAVE_CONTAINER);
      });
    });

    it('should not create an exception when exception form is invalid', async () => {
      fixture.whenStable().then(async () => {
        const modalSpy = spyOn(component['modalService'], 'openModal').and.returnValue({});
        await component.createException(component.exceptionCreationForm.value);
        expect(modalSpy).toHaveBeenCalledTimes(0);
      });
    });

    it('should not create an exception when exception service throw an exception', async () => {
      fixture.whenStable().then(async () => {
        spyOn(component['exceptionService'], 'createException').and.returnValue(Promise.reject({ errorMessage: 'Error' }));
        component.updateForm('exceptionType', 1);
        component.updateForm('description', 'Description');
        const modalSpy = spyOn(component['modalService'], 'openModal').and.returnValue({});
        await component.createException(component.exceptionCreationForm.value);
        expect(modalSpy).toHaveBeenCalledWith(component.errorMessage);
        expect(component.isExceptionCreated.hasErrors).toBe(true);
      });
    });

  });

  describe('Empty group', () => {

    beforeEach(async(() => {
      TestBed.configureTestingModule({
        imports: [
          RouterTestingModule,
          BrowserAnimationsModule,
          PrimaryButtonModule,
          CalendarModule,
          MaterialModule,
          ReactiveFormsModule,
          DefaultImageContainerModule,
          HttpClientModule,
        ],
        declarations: [
          ExceptionsComponent,
        ],
        providers: [
          { provide: Router, useClass: RouterMovementsMock },
          { provide: GroupService, useClass: GroupServiceEmptyMock },
          { provide: ExceptionService, useClass: ExceptionServiceMock },
        ]
      }).compileComponents();
      (window as any).innerWidth = SCREEN_WIDTH.DESKTOP + 100;
      fixture = TestBed.createComponent(ExceptionsComponent);
      component = fixture.componentInstance;
      fixture.detectChanges();
    }));

    it('should get empty groups', () => {
      fixture.whenStable().then(async () => {
        expect(component.groups.length).toBe(0);
        expect(component.errorMessage).toBe(EMPTY_GROUP_LIST_CONTAINER);
      });
    });

  });

  describe('Reject service group', () => {

    beforeEach(async(() => {
      TestBed.configureTestingModule({
        imports: [
          RouterTestingModule,
          BrowserAnimationsModule,
          PrimaryButtonModule,
          CalendarModule,
          MaterialModule,
          ReactiveFormsModule,
          DefaultImageContainerModule,
          HttpClientModule,
        ],
        declarations: [
          ExceptionsComponent,
        ],
        providers: [
          { provide: Router, useClass: RouterMovementsMock },
          { provide: GroupService, useClass: GroupServiceRejectMock },
          { provide: ExceptionService, useClass: ExceptionServiceMock },
        ]
      }).compileComponents();
      fixture = TestBed.createComponent(ExceptionsComponent);
      component = fixture.componentInstance;
      fixture.detectChanges();
    }));

    it('should have error on data loading', async () => {
      await fixture.whenStable().then(() => {
        expect(component.isDataLoaded.hasErrors).toBe(true);
      });
    });

  });
});
