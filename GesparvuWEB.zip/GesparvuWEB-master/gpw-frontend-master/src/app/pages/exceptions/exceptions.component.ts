import {
  SUCCESS_DEFAULT_SAVE_CONTAINER,
  EMPTY_GROUP_LIST_CONTAINER,
  DEFAULT_ERROR_MESSAGE_CONTAINER
} from './../../common/constants/default-image-container-messages';
import { ExceptionService } from './../../services/exception/exception.service';
import { IExceptionCalendar, IExceptionType, IExceptionRequest } from './../../common/interfaces/exceptions.interface';
import { Component, OnInit, OnDestroy, ViewChildren } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';
import { IDataLoaded, IDefaultImageContainer } from '../../common/interfaces/default.interface';
import { GroupService } from '@services/group/group.service';
import { ISimpleGroup } from '../../common/interfaces/groups.interface';
import { ModalService } from '@services/modal/modal.service';
import { Subscription, Subject } from 'rxjs';
import Utils from '@utils/utils';
import { GoogleAnalyticsService } from '@services/google-analytics/google-analytics.service';
import { GA_CREATE_EXCEPTION_ACTION, GA_CREATE_EXCEPTION_LABEL } from 'app/common/constants/default.constants';
@Component({
  selector: 'app-exceptions-content',
  templateUrl: './exceptions.component.html',
  styleUrls: ['./exceptions.component.scss']
})

export class ExceptionsComponent implements OnInit, OnDestroy {

  selectedDate: Date;
  exceptionCreationForm: FormGroup;
  groupSelectionForm: FormGroup;
  isCalendarLoaded: IDataLoaded;
  isDataLoaded: IDataLoaded;
  isExceptionCreated: IDataLoaded;
  errorMessage: IDefaultImageContainer;
  groups: ISimpleGroup[];
  exceptionTypes: IExceptionType[];
  subscription: Subscription;
  selectedGroupName: string;
  calendarInformation: IExceptionCalendar[];
  resetTooltip: Subject<boolean>;

  constructor(
    private formBuilder: FormBuilder,
    private exceptionService: ExceptionService,
    public groupService: GroupService,
    public readonly modalService: ModalService,
    public gaService: GoogleAnalyticsService,
  ) {
    this.resetTooltip = new Subject();
    this.selectedDate = new Date();
    this.isDataLoaded = {
      hasErrors: false,
      isLoaded: false,
    };
    this.isCalendarLoaded = {
      hasErrors: false,
      isLoaded: false,
    };
    this.isExceptionCreated = {
      hasErrors: false,
      isLoaded: true,
    };
    this.groups = [];
    this.exceptionTypes = [];
    this.calendarInformation = [];
    this.errorMessage = DEFAULT_ERROR_MESSAGE_CONTAINER;
    this.subscription = new Subscription();
  }

  get selectedGroup() {
    return this.groupSelectionForm.get('group').value;
  }

  ngOnInit() {
    Promise.all([
      this.getGroups(),
      this.getExceptionTypes(),
    ])
    .then(() => {
      if (this.groups.length > 0) {

        this.groupSelectionForm = this.formBuilder.group({
          group: new FormControl(this.groups[0].id, Validators.compose([
            Validators.required,
          ])),
        });

        this.selectedGroupName = this.groups[0].name;

        this.exceptionCreationForm = this.formBuilder.group({
          date: new FormControl(this.selectedDate.toISOString(), Validators.compose([
            Validators.required,
          ])),
          group: new FormControl(this.groups[0].id, Validators.compose([
            Validators.required,
          ])),
          exceptionType: new FormControl('', Validators.compose([
            Validators.required,
          ])),
          description: new FormControl('', Validators.compose([
            Validators.required,
            Validators.maxLength(200)
          ])),
        });

        this.getCalendarInformation(this.selectedDate);

        this.subscription.add(this.groupSelectionForm.valueChanges.subscribe(() => {
          this.updateSelectedGroupName();
          this.getCalendarInformation(this.selectedDate);
          this.updateForm('group', this.selectedGroup);
        }));
      } else {
        this.isCalendarLoaded.isLoaded = true;
        this.errorMessage = EMPTY_GROUP_LIST_CONTAINER;
      }
    })
    .catch((err) => {
      this.isDataLoaded.hasErrors = true;
      this.errorMessage.title = err.errorMessage;
      this.modalService.openModal(this.errorMessage);
    })
    .finally(() => {
      this.isDataLoaded.isLoaded = true;
    });
  }

  public async getExceptionTypes() {
    this.exceptionTypes = await this.exceptionService.getAllExceptionTypes();
  }

  public async getGroups() {
    this.groups = await this.groupService.getGroupsByTeacher();
  }

  public async getCalendarInformation(currentDate: Date) {
    this.updateCurrentDate(currentDate, true);
    this.isCalendarLoaded.isLoaded = false;
    try {
      this.calendarInformation = await this.exceptionService.getCalendarInformation(
        this.selectedGroup,
        this.selectedDate.getUTCFullYear(),
        this.selectedDate.getUTCMonth() + 1
      );
      this.disableFormForHolidays();
    } catch (err) {
      this.isCalendarLoaded.hasErrors = true;
      this.errorMessage.title = err.errorMessage;
      this.modalService.openModal(this.errorMessage);
    }
    this.isCalendarLoaded.isLoaded = true;
  }

  public updateCurrentDate(currentDate: Date, monthChanged: boolean = false) {
    this.selectedDate = currentDate;
    this.exceptionCreationForm.reset();
    this.updateForm('group', this.selectedGroup);
    this.updateForm('date', currentDate.toISOString());
    if (!monthChanged) { this.disableFormForHolidays(); }
  }

  public updateForm(key: string, value: any) {
    this.exceptionCreationForm.patchValue({
      [key]: value
    });
  }

  public resetCalendarTooltip() {
    this.resetTooltip.next(true);
  }

  public updateSelectedGroupName() {
    this.selectedGroupName = this.groups.find((group) => group.id === this.selectedGroup).name;
  }

  public async createException(exception: IExceptionRequest) {
    if (this.exceptionCreationForm.valid && !this.exceptionCreationForm.disabled) {
      this.isExceptionCreated.isLoaded = false;
      this.isExceptionCreated.hasErrors = false;

      try {
        await this.exceptionService.createException(exception);
        this.modalService.openModal(SUCCESS_DEFAULT_SAVE_CONTAINER);

        // Send google analytics event
        this.gaService.sendAttendanceManagementEvent(GA_CREATE_EXCEPTION_ACTION, GA_CREATE_EXCEPTION_LABEL);
      } catch (err) {
        this.isExceptionCreated.hasErrors = true;
        this.errorMessage.title = err.errorMessage;
        this.modalService.openModal(this.errorMessage);
      }

      this.isExceptionCreated.isLoaded = true;
      this.getCalendarInformation(this.selectedDate);
    }
  }

  public disableFormForHolidays() {
    const selectedDay = this.calendarInformation.find((day) => Utils.compareDates(day.date, this.selectedDate));
    if (selectedDay && selectedDay.irrevocable) {
      this.exceptionCreationForm.disable();
    } else {
      this.exceptionCreationForm.enable();
    }
  }

  ngOnDestroy(): void {
    this.resetTooltip.unsubscribe();
    this.subscription.unsubscribe();
  }

}
