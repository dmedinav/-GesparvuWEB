import { CalendarModule } from './../../components/calendar/calendar.module';
import { CommonAppModule } from '../../common/common.module';
import { ReactiveFormsModule } from '@angular/forms';
import { Routes, RouterModule } from '@angular/router';
import { ExceptionsComponent } from './exceptions.component';
import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { SecondaryButtonModule } from '../../components/secondary-button/secondary-button.module';
import { PrimaryButtonModule } from '../../components/primary-button/primary-button.module';

const routes: Routes = [
  {
    path: '',
    component: ExceptionsComponent,
  },
];

@NgModule({
  imports: [
    CommonModule,
    ReactiveFormsModule,
    RouterModule.forChild(routes),
    CommonAppModule,
    SecondaryButtonModule,
    PrimaryButtonModule,
    CalendarModule,
  ],
  declarations: [
    ExceptionsComponent
  ],
  exports: [
    ExceptionsComponent
  ]
})
export class ExceptionsModule { }
