import { HOME_ROUTE, MOVEMENT_MAIN_ROUTE } from './../../common/constants/routes.constants';
import { RouterTestingModule } from '@angular/router/testing';
import { EnrollmentServiceMock } from './../../mocks/enrollments.mocks';
import { EnrollmentService } from '@services/enrollment/enrollment.service';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { PrimaryButtonModule } from '../../components/primary-button/primary-button.module';
import { DefaultImageContainerModule } from './../../components/default-image-container/default-image-container.module';
import { MaterialModule } from '../../material.module';
import { ReactiveFormsModule } from '@angular/forms';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { MovementSearchComponent } from './movement-search.component';
import { BrowserDynamicTestingModule } from '@angular/platform-browser-dynamic/testing';
import { GenericModalComponent } from '../../components/generic-modal/generic-modal.component';
import { SecondaryButtonModule } from '../../components/secondary-button/secondary-button.module';
import { EMPTY_ENROLLMENT_SEARCH_CONTAINER } from '../../common/constants/default-image-container-messages';

describe('MovementSearchComponent', () => {
  let component: MovementSearchComponent;
  let fixture: ComponentFixture<MovementSearchComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [MovementSearchComponent, GenericModalComponent],
      imports: [
        RouterTestingModule,
        BrowserAnimationsModule,
        ReactiveFormsModule,
        MaterialModule,
        DefaultImageContainerModule,
        PrimaryButtonModule,
        SecondaryButtonModule,
      ],
      providers: [
        { provide: EnrollmentService, useClass: EnrollmentServiceMock },
      ],
    })
    .overrideModule(BrowserDynamicTestingModule, { set: { entryComponents: [GenericModalComponent] } })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MovementSearchComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should navigate to button route', () => {
    const spy = spyOn(component.router, 'navigateByUrl');
    component.navigateTo('1');
    expect(spy).toHaveBeenCalledWith(`${HOME_ROUTE}/${MOVEMENT_MAIN_ROUTE}/1`);
  });

  it('should format a string to rut or name', () => {
    component.searchForMovementForm.setValue({rutOrName: '111111111'});
    component.rutOrNameFormatter();
    expect(component.searchForMovementForm.value.rutOrName === '111111111').toBeFalsy();
    expect(component.searchForMovementForm.value.rutOrName).toBe('11.111.111-1');

    component.searchForMovementForm.setValue({rutOrName: 'test'});
    component.rutOrNameFormatter();
    expect(component.searchForMovementForm.value.rutOrName).toBe('test');
  });

  it('should search enrollments and display the table', () => {
    const numberOfColumns = 4;
    component.searchForMovementForm.setValue({rutOrName: '11.111.111-1'});
    component.searchEnrollments( component.searchForMovementForm.value).then(() => {
      fixture.detectChanges();
      const table: HTMLElement[] = fixture.nativeElement.querySelectorAll('td');
      expect(table.length / numberOfColumns).toBe(component.enrollments.length);
    });
  });

  it('should search enrollments with invalid form', () => {
    component.searchForMovementForm.setValue({rutOrName: ''});
    component.searchEnrollments( component.searchForMovementForm.value).then(() => {
      fixture.detectChanges();
      const table: HTMLElement[] = fixture.nativeElement.querySelectorAll('td');
      expect(table.length).toBe(0);
    });
  });

  it('should throw an error and display a modal', () => {
    const dialogElement = fixture.nativeElement.querySelector('mat-dialog-container');
    expect(dialogElement).toBeNull();

    component.searchForMovementForm.setValue({rutOrName: 'error'});
    component.searchEnrollments( component.searchForMovementForm.value).catch(() => {
      fixture.detectChanges();
      const table: HTMLElement[] = fixture.nativeElement.querySelectorAll('td');
      expect(table.length).toBe(0);

      component.modalService.openModal(EMPTY_ENROLLMENT_SEARCH_CONTAINER);
      expect(dialogElement).toBeDefined();
    });
  });

  it('should not find enrollments', () => {
    component.searchForMovementForm.setValue({rutOrName: 'empty'});
    component.searchEnrollments( component.searchForMovementForm.value).then(() => {
      fixture.detectChanges();
      const table: HTMLElement[] = fixture.nativeElement.querySelectorAll('td');
      expect(table.length).toBe(0);
    });
  });

});
