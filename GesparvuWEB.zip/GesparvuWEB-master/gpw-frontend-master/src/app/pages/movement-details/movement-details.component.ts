import { Component, OnInit, OnDestroy } from '@angular/core';
import { FormGroup, FormBuilder } from '@angular/forms';
import { Location } from '@angular/common';
import { Router } from '@angular/router';
import Utils from '@utils/utils';
import { DEFAULT_ERROR_MESSAGE_CONTAINER, SUCCESS_MOVEMENT_SAVE_CONTAINER } from './../../common/constants/default-image-container-messages';
import { HOME_ROUTE, MOVEMENT_SEARCH_ROUTE } from './../../common/constants/routes.constants';
import { MOVEMENT_SESSION_STORAGE_KEY, ENROLLMENT_SESSION_STORAGE_KEY, GA_CREATE_MOVEMENT_ACTION, GA_CREATE_MOVEMENT_LABEL } from '../../common/constants/default.constants';
import { IDataLoaded } from '../../common/interfaces/default.interface';
import { IDefaultImageContainer } from './../../common/interfaces/default.interface';
import { IEnrollmentsByGroupResponse } from 'app/common/interfaces/enrollments.interface';
import { IMovement } from 'app/common/interfaces/movements.interface';
import { GoogleAnalyticsService } from '@services/google-analytics/google-analytics.service';
import { GroupService } from '@services/group/group.service';
import { ModalService } from '@services/modal/modal.service';
import { MovementService } from './../../services/movement/movement.service';

@Component({
  selector: 'app-movement-details',
  templateUrl: './movement-details.component.html'
})

export class MovementDetailsComponent implements OnInit, OnDestroy {

  movementCreationForm: FormGroup;
  movement: IMovement;
  enrollment: IEnrollmentsByGroupResponse;
  enrollmentRut: string;
  enrollmentFullName: string;
  exitWithButton: boolean;
  isCreationCompleted: IDataLoaded;
  isMovementCreated: boolean;
  errorMessage: IDefaultImageContainer;
  groups: [];

  constructor(
    private router: Router,
    private formBuilder: FormBuilder,
    private movementService: MovementService,
    private location: Location,
    private modalService: ModalService,
    public gaService: GoogleAnalyticsService,
    public readonly groupService: GroupService,
  ) {
    this.enrollmentRut = '';
    this.exitWithButton = false;
    this.isMovementCreated = false;
    this.isCreationCompleted = {
      isLoaded: true,
      hasErrors: false,
    };
    this.errorMessage = DEFAULT_ERROR_MESSAGE_CONTAINER;
    this.groups = [];
  }

  ngOnInit() {
    const movementString = sessionStorage.getItem(MOVEMENT_SESSION_STORAGE_KEY);
    const enrollmentString = sessionStorage.getItem(ENROLLMENT_SESSION_STORAGE_KEY);

    if (enrollmentString) {
      this.enrollment = JSON.parse(enrollmentString) as IEnrollmentsByGroupResponse;
      this.enrollmentRut = Utils.formatToRut(this.enrollment.infant.rut + this.enrollment.infant.rutDv);
      this.enrollmentFullName = [
        this.enrollment.infant.names,
        this.enrollment.infant.fathersLastname,
        this.enrollment.infant.mothersLastname,
      ].join(' ').trim();
    }

    if (movementString) {
      this.movement = JSON.parse(movementString) as IMovement;
      this.movementCreationForm = this.formBuilder.group(this.movement);
    } else {
      this.router.navigateByUrl(`${HOME_ROUTE}/${MOVEMENT_SEARCH_ROUTE}`);
    }
  }

  ngOnDestroy(): void {
    if (!this.exitWithButton) {
      sessionStorage.removeItem(MOVEMENT_SESSION_STORAGE_KEY);
      sessionStorage.removeItem(ENROLLMENT_SESSION_STORAGE_KEY);
    }
  }

  public goBack() {
    this.exitWithButton = true;
    this.location.back();
  }

  public async createMovement() {
    if (this.movementCreationForm.valid && !this.isMovementCreated) {
      this.isMovementCreated = true;
      this.isCreationCompleted.isLoaded = false;

      try {
        await this.movementService.createMovement(this.movementCreationForm.value);
        this.modalService.openModal(SUCCESS_MOVEMENT_SAVE_CONTAINER);
        sessionStorage.removeItem(MOVEMENT_SESSION_STORAGE_KEY);
        sessionStorage.removeItem(ENROLLMENT_SESSION_STORAGE_KEY);

        // Send google analytics event
        this.gaService.sendInfantManagementEvent(GA_CREATE_MOVEMENT_ACTION, GA_CREATE_MOVEMENT_LABEL);
      } catch (err) {
        this.isMovementCreated = false;
        this.isCreationCompleted.hasErrors = true;
        this.errorMessage.title = err.errorMessage;
        this.modalService.openModal(this.errorMessage);
      }

      this.isCreationCompleted.isLoaded = true;
    }
  }
}
