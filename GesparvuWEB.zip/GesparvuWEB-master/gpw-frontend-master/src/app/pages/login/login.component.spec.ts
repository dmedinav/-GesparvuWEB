import { HOME_ROUTE } from '../../common/constants/routes.constants';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { CommonAppModule } from './../../common/common.module';
import { async, ComponentFixture, TestBed, inject } from '@angular/core/testing';
import { DefaultImageContainerModule } from '../../components/default-image-container/default-image-container.module';
import { PrimaryButtonModule } from '../../components/primary-button/primary-button.module';
import { ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { RouterTestingModule } from '@angular/router/testing';
import { GenericModalComponent } from '../../components/generic-modal/generic-modal.component';
import { BrowserDynamicTestingModule } from '@angular/platform-browser-dynamic/testing';
import { AuthService } from '@services/auth/auth.service';
import { AuthServiceMock, userLoginMock } from '../../mocks/auth.mock';
import { LoginComponent } from './login.component';
import { Router } from '@angular/router';

// tslint:disable:no-string-literal
describe('LoginComponent', () => {
  let component: LoginComponent;
  let fixture: ComponentFixture<LoginComponent>;

  beforeEach(async (() => {
    TestBed.configureTestingModule({
      declarations: [ LoginComponent ],
      imports: [
        BrowserAnimationsModule,
        ReactiveFormsModule,
        CommonAppModule,
        DefaultImageContainerModule,
        PrimaryButtonModule,
        HttpClientModule,
        RouterTestingModule,
      ],
      providers: [
        { provide: AuthService, useClass: AuthServiceMock },
      ],
    })
    .overrideModule(BrowserDynamicTestingModule, { set: { entryComponents: [GenericModalComponent] } })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LoginComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should not sign in if form is invalid', () => {
    const signSpy = spyOn(component['authService'], 'signIn').and.returnValue(Promise.resolve({}));
    component.signIn(userLoginMock);
    expect(signSpy).toHaveBeenCalledTimes(0);
  });

  it('should sign in and navigate to home path', inject([Router], (router: Router) => {
    const signSpy = spyOn(component['authService'], 'signIn').and.returnValue(Promise.resolve({}));
    spyOn(router, 'navigateByUrl').and.stub();
    component.loginForm.patchValue(userLoginMock);
    component.loginForm.updateValueAndValidity({emitEvent: false});
    component.signIn(component.loginForm.value).then(() => {
      expect(signSpy).toHaveBeenCalledWith(userLoginMock);
      expect(router.navigateByUrl).toHaveBeenCalledWith(HOME_ROUTE);
    });
  }));

  it('should not sign if sevice reject', () => {
    const signSpy = spyOn(component['authService'], 'signIn').and.returnValue(Promise.reject({}));
    component.loginForm.patchValue(userLoginMock);
    component.loginForm.updateValueAndValidity({emitEvent: false});
    component.signIn(userLoginMock).then(() => {
      expect(signSpy).toHaveBeenCalledWith(userLoginMock);
      expect(component.isLoggedIn.hasErrors).toBeTruthy();
    });
  });

});
