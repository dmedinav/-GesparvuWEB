import { Router } from '@angular/router';
import { AuthService } from './../../services/auth/auth.service';
import { Component, OnInit } from '@angular/core';
import { IUserLogin } from '../../common/interfaces/user-login.interface';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
import { IDataLoaded } from '../../common/interfaces/default.interface';
import { HOME_ROUTE } from '../../common/constants/routes.constants';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {

  userInfo: IUserLogin;
  loginForm: FormGroup;
  isLoggedIn: IDataLoaded;
  errorMessage: string;

  constructor(
    private authService: AuthService,
    private formBuilder: FormBuilder,
    private router: Router,
  ) {
    this.isLoggedIn = {
      hasErrors: false,
      isLoaded: true,
    };
  }

  ngOnInit() {
    this.loginForm = this.formBuilder.group({
      username: new FormControl({ value: '', disabled: false },
        Validators.compose([
          Validators.required,
        ])),
      password: new FormControl({ value: '', disabled: false },
        Validators.compose([
          Validators.required,
        ])),
    });
  }

  public async signIn(formValue) {
    if (this.loginForm.valid) {
      this.isLoggedIn.isLoaded = false;
      this.isLoggedIn.hasErrors = false;
      try {
        await this.authService.signIn(formValue);
        this.router.navigateByUrl(HOME_ROUTE);
      } catch (err) {
        this.errorMessage = err.errorMessage;
        this.isLoggedIn.hasErrors = true;
      }
      this.isLoggedIn.isLoaded = true;
    }
  }

}
