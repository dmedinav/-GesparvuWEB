import { CommonAppModule } from './../../common/common.module';
import { Routes, RouterModule } from '@angular/router';
import { DailyAttendanceContentComponent } from './daily-attendance-content.component';
import { NgModule } from '@angular/core';
import { PrimaryButtonModule } from '../../components/primary-button/primary-button.module';
import { SwitchRadioButtonModule } from '../../components/switch-radio-button/switch-radio-button.module';

const routes: Routes = [
  {
    path: '',
    component: DailyAttendanceContentComponent,
  },
];

@NgModule({
  imports: [
    RouterModule.forChild(routes),
    PrimaryButtonModule,
    SwitchRadioButtonModule,
    CommonAppModule,
  ],
  declarations: [
    DailyAttendanceContentComponent
  ],
})
export class DailyAttendanceContentModule { }
