import {
  EMPTY_ENROLLMENT_LIST_CONTAINER,
  SUCCESS_ATTENDANCE_SAVE_CONTAINER,
  DEFAULT_ERROR_MESSAGE_CONTAINER,
  NOT_WORKING_DAY_CONTAINER,
  EMPTY_GROUP_LIST_CONTAINER,
} from './../../common/constants/default-image-container-messages';
import { AttendanceService } from './../../services/attendance/attendance.service';
import { IAttendanceUpdateObject } from './../../common/interfaces/attendance.interface';
import { IDataLoaded, IDefaultImageContainer } from './../../common/interfaces/default.interface';
import { EnrollmentService } from './../../services/enrollment/enrollment.service';
import { Component, OnInit, OnDestroy } from '@angular/core';
import { ISwitchRadioButton, ISwitchRadioButtonOutput } from '../../common/interfaces/switch-radio-button.interface';
import { FormGroup, FormBuilder, Validators, FormControl, FormArray } from '@angular/forms';
import { Subscription } from 'rxjs';
import { IEnrollmentsByGroupResponse } from '../../common/interfaces/enrollments.interface';
import { ENROLLMENT_COLUMNS, GA_CREATE_ATTENDANCE_ACTION, GA_CREATE_ATTENDANCE_LABEL } from '../../common/constants/default.constants';
import { IAttendanceCodeTypes } from '../../common/interfaces/attendance-types.interface';
import { validateDailyAttendance } from '../../common/validators/daily-attendance';
import { ITotalAttendance } from '../../common/interfaces/total-attendance.interface';
import { ModalService } from '@services/modal/modal.service';
import { ISimpleGroup } from '../../common/interfaces/groups.interface';
import { GroupService } from '@services/group/group.service';
import { GoogleAnalyticsService } from '@services/google-analytics/google-analytics.service';

@Component({
  selector: 'app-daily-attendance-content',
  templateUrl: './daily-attendance-content.component.html',
  styleUrls: ['./daily-attendance-content.component.scss']
})
export class DailyAttendanceContentComponent implements OnInit, OnDestroy {

  switchLeftButton: ISwitchRadioButton;
  switchRightButton: ISwitchRadioButton;
  filterAttendanceForm: FormGroup;
  attendanceForm: FormGroup;
  subscription: Subscription;
  enrollments: IEnrollmentsByGroupResponse[];
  attendanceCodes: IAttendanceCodeTypes;
  isNewDataLoaded: IDataLoaded;
  isGroupsLoaded: IDataLoaded;
  isAttendanceSaved: IDataLoaded;
  errorMessage: IDefaultImageContainer;
  displayedColumns: string[];
  today: number;
  cautionMessage: IDefaultImageContainer;
  groups: ISimpleGroup[];
  workingDay: boolean;
  activeMonth: boolean;
  totalAttendance: ITotalAttendance;
  calendarMaxDate: Date;

  constructor(
    private formBuilder: FormBuilder,
    public readonly enrollmentService: EnrollmentService,
    public readonly groupService: GroupService,
    private attendanceService: AttendanceService,
    public readonly modalService: ModalService,
    public gaService: GoogleAnalyticsService,
  ) {
    this.calendarMaxDate = new Date();
    this.enrollments = [];
    this.workingDay = true;
    this.switchLeftButton = { text: 'Ausente', value: 2, colorClass: 'warning-color' };
    this.switchRightButton = { text: 'Presente', value: 1, colorClass: 'success-color' };
    this.displayedColumns = ENROLLMENT_COLUMNS;
    this.cautionMessage = null;
    this.today = new Date().getUTCDate();
    this.errorMessage = DEFAULT_ERROR_MESSAGE_CONTAINER;
    this.isNewDataLoaded = {
      hasErrors: false,
      isLoaded: true,
    };
    this.isAttendanceSaved = {
      hasErrors: false,
      isLoaded: true,
    };
    this.isGroupsLoaded = {
      hasErrors: false,
      isLoaded: false,
    };
    this.subscription = new Subscription();

    this.totalAttendance = {
      attendance: 0,
      noAttendance: 0,
      total: 0
    };
  }

  ngOnInit() {
    this.getGroups()
      .then(() => {
        if (this.groups.length > 0) {
          this.filterAttendanceForm = this.formBuilder.group({
            date: new FormControl(new Date(), Validators.compose([
              Validators.required,
            ])),
            group: new FormControl(this.groups[0].id, Validators.compose([
              Validators.required,
            ])),
          });

          this.attendanceForm = this.formBuilder.group({
            attendances: this.formBuilder.array([]),
          });

          this.subscription.add(this.filterAttendanceForm.valueChanges.subscribe(() => {
            // Do not update enrollments if filter form is invalid
            if (this.filterAttendanceForm.invalid) return;

            const rawFilters = this.filterAttendanceForm.getRawValue();

            if (rawFilters.date && rawFilters.group) {
              this.getEnrollmentsByDay(rawFilters.date, rawFilters.group);
            }
          }));

          this.getEnrollmentsByDay(new Date(), this.groups[0].id);
        } else {
          this.updateCautionMessage();
        }
      });
  }

  get attendances() {
    return this.attendanceForm.get('attendances') as FormArray;
  }

  public async getGroups() {
    this.isGroupsLoaded.isLoaded = false;
    this.isGroupsLoaded.hasErrors = false;
    this.groups = [];
    try {
      this.groups = await this.groupService.getGroupsByTeacher();
    } catch (err) {
      this.errorMessage.title = err.errorMessage;
      this.isGroupsLoaded.hasErrors = true;
      this.modalService.openModal(this.errorMessage);
    }
    this.isGroupsLoaded.isLoaded = true;
  }

  public async getEnrollmentsByDay(date: Date, group: number) {
    this.isNewDataLoaded.isLoaded = false;
    this.isNewDataLoaded.hasErrors = false;
    this.enrollments = [];
    this.workingDay = true;
    const month = date.getUTCMonth() + 1;
    const day = date.getUTCDate();
    const year = date.getUTCFullYear();

    try {
      const enrollmentsByGroup = await this.enrollmentService.getEnrollmentsByGroupIdAndCompleteDate(group, year, month, day);
      this.enrollments = enrollmentsByGroup.enrollments;
      this.attendanceCodes = enrollmentsByGroup.attendanceCodes;
      this.workingDay = !this.isNotWorkingDay();
      this.activeMonth = enrollmentsByGroup.isActiveMonth;
    } catch (err) {
      this.errorMessage.title = err.errorMessage;
      this.isNewDataLoaded.hasErrors = true;
      this.modalService.openModal(this.errorMessage);
    }
    this.today = day;
    if (!this.isNewDataLoaded.hasErrors) {
      this.updateButtonValues();
      this.addAttendanceInFormGroup();
      this.updateCautionMessage();
      this.updateTotalAttendance();
    }
    this.isNewDataLoaded.isLoaded = true;
  }

  public clearAttendanceForm() {
    this.attendances.clearValidators();
    while (this.attendances.length !== 0) {
      this.attendances.removeAt(0);
    }
  }

  public updateButtonValues() {
    this.switchLeftButton.value = this.attendanceCodes.RAD_NO_ATTENDANCE_CODE;
    this.switchRightButton.value = this.attendanceCodes.RAD_ATTENDANCE_CODE;
  }

  public addAttendanceInFormGroup(): void {
    this.clearAttendanceForm();
    for (const enrollment of this.enrollments) {
      const currentAttendanceValue = enrollment.attendances[0].attendance;
      this.attendances.push(
        this.formBuilder.group({
          id: enrollment.attendances[0].id,
          attendance: this.formBuilder.group({
            [this.today]: currentAttendanceValue,
          }),
        })
      );
    }
    this.attendances.setValidators([validateDailyAttendance(this.attendanceCodes, this.today.toString())]);
    this.attendances.updateValueAndValidity({ emitEvent: false });
    this.totalAttendance.total = this.attendances.value.length;
  }

  public changeAttendance(output: ISwitchRadioButtonOutput) {
    this.attendances.controls.forEach(control => {
      if (control.value.id === Number(output.id)) {
        control.patchValue({
          attendance: {
            [this.today]: Number(output.value),
          }
        });
      }
    });
    this.updateTotalAttendance();
  }

  public updateCautionMessage() {
    this.cautionMessage = !this.workingDay ? NOT_WORKING_DAY_CONTAINER :
    this.groups.length === 0 ? EMPTY_GROUP_LIST_CONTAINER :
    this.enrollments.length === 0 ? EMPTY_ENROLLMENT_LIST_CONTAINER : null;
  }

  public async saveAttendance(attendances: IAttendanceUpdateObject) {
    if (this.attendances.valid && this.activeMonth) {
      this.isAttendanceSaved.isLoaded = false;
      this.isAttendanceSaved.hasErrors = false;

      try {
        await this.attendanceService.updateAttendanceObject(attendances);
        this.modalService.openModal(SUCCESS_ATTENDANCE_SAVE_CONTAINER);

        // Send google analytics event
        this.gaService.sendAttendanceManagementEvent(GA_CREATE_ATTENDANCE_ACTION, GA_CREATE_ATTENDANCE_LABEL);
      } catch (err) {
        this.isAttendanceSaved.hasErrors = true;
        this.errorMessage.title = err.errorMessage;
        this.modalService.openModal(this.errorMessage);
      }

      this.isAttendanceSaved.isLoaded = true;
    }
  }

  public isNotWorkingDay(): boolean {
    return this.enrollments.find(e => e.attendances[0].attendance === this.attendanceCodes.RAD_HOLIDAY_CODE) != null;
  }

  public updateTotalAttendance() {
    this.totalAttendance.attendance = this.attendances.value
      .filter(a => a.attendance[this.today] === this.attendanceCodes.RAD_ATTENDANCE_CODE).length;
    this.totalAttendance.noAttendance = this.attendances.value
      .filter(a => a.attendance[this.today] === this.attendanceCodes.RAD_NO_ATTENDANCE_CODE).length;
  }

  public updateAllTodayAttendances(code: number) {
    this.attendances.controls.forEach(control => {
      control.patchValue({
        attendance: {
          [this.today]: Number(code),
        }
      });
    });
    this.updateTotalAttendance();
  }

  ngOnDestroy() {
    this.subscription.unsubscribe();
  }

}
