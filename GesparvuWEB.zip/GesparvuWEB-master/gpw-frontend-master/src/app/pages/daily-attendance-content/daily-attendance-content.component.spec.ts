import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { DailyAttendanceContentComponent } from './daily-attendance-content.component';
import { MaterialModule } from '../../material.module';
import { ReactiveFormsModule } from '@angular/forms';
import { DefaultImageContainerModule } from '../../components/default-image-container/default-image-container.module';
import { PrimaryButtonModule } from '../../components/primary-button/primary-button.module';
import { SwitchRadioButtonModule } from '../../components/switch-radio-button/switch-radio-button.module';
import { HttpClientModule } from '@angular/common/http';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { EnrollmentService } from '@services/enrollment/enrollment.service';
import { EnrollmentServiceMock } from '../../mocks/enrollments.mocks';
import {
  switchRadioButtonOutputMockError,
  switchRadioButtonOutputMockNoAttendance
} from '../../mocks/component-params.mock';
import { AttendanceService } from '@services/attendance/attendance.service';
import { AttendanceServiceMock } from '../../mocks/attendance.mocks';
import { IAttendanceUpdateObject } from '../../common/interfaces/attendance.interface';
import { GenericModalComponent } from '../../components/generic-modal/generic-modal.component';
import { SecondaryButtonModule } from '../../components/secondary-button/secondary-button.module';
import {
  NOT_WORKING_DAY_CONTAINER,
  EMPTY_ENROLLMENT_LIST_CONTAINER,
  SUCCESS_ATTENDANCE_SAVE_CONTAINER,
  EMPTY_GROUP_LIST_CONTAINER,
} from '../../common/constants/default-image-container-messages';
import { BrowserDynamicTestingModule } from '@angular/platform-browser-dynamic/testing';
import { GroupService } from '@services/group/group.service';
import { GroupServiceMock, groupsMock } from '../../mocks/groups.mocks';

describe('DailyAttendanceContentComponent', () => {
  let component: DailyAttendanceContentComponent;
  let fixture: ComponentFixture<DailyAttendanceContentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [DailyAttendanceContentComponent, GenericModalComponent],
      imports: [
        ReactiveFormsModule,
        MaterialModule,
        DefaultImageContainerModule,
        SwitchRadioButtonModule,
        PrimaryButtonModule,
        HttpClientModule,
        BrowserAnimationsModule,
        SecondaryButtonModule,
      ],
      providers: [
        { provide: EnrollmentService, useClass: EnrollmentServiceMock },
        { provide: AttendanceService, useClass: AttendanceServiceMock },
        { provide: GroupService, useClass: GroupServiceMock },
      ],
    })
      .overrideModule(BrowserDynamicTestingModule, { set: { entryComponents: [GenericModalComponent] } })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DailyAttendanceContentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should create with no data in filterForm', () => {
    const spy = spyOn(component, 'getEnrollmentsByDay').and.returnValue({});
    fixture.whenStable().then(() => {
      component.filterAttendanceForm.setValue({date: true, group: 1});
      setTimeout(() => { expect(spy).toHaveBeenCalledTimes(2); }, 0);
    });
  });

  it('should create with no data in filterForm and never called get enrollment a second time', () => {
    const spy = spyOn(component, 'getEnrollmentsByDay').and.returnValue({});
    fixture.whenStable().then(() => {
      component.filterAttendanceForm.setValue({date: false, group: 1});
      setTimeout(() => { expect(spy).toHaveBeenCalledTimes(1); }, 0);
    });
  });

  it('should create without groups', () => {
    // tslint:disable-next-line: no-string-literal
    spyOn(component['groupService'], 'getGroupsByTeacher').and.returnValue([]);
    component.ngOnInit();
    expect(component).toBeTruthy();
  });

  it('should have invalid form', () => {
    fixture.whenStable().then(async () => {
      fixture.detectChanges();

      component.getEnrollmentsByDay(new Date(), 1).then(() => {
        expect(component.attendances.valid).toBeFalsy();
      });
    });
  });

  it('should not get enrollments without group id', () => {
    fixture.whenStable().then(async () => {
      component.getEnrollmentsByDay(new Date(), null).catch(() => {
        expect(component.attendances.length).toBe(0);
        expect(component.attendanceCodes).toBeUndefined();
      });
    });
  });

  it('should get enrollments by day and load attendance codes', () => {
    fixture.whenStable().then(async () => {

      component.getEnrollmentsByDay(new Date(), 1).then(() => {
        expect(component.attendances.length).toBeGreaterThan(0);
        expect(component.attendanceCodes).toBeDefined();
      });
    });
  });

  it('should get an error when calls getGroups() and open a modal', () => {
    // tslint:disable-next-line: no-string-literal
    spyOn(component['groupService'], 'getGroupsByTeacher').and.returnValue(Promise.reject({}));
    fixture.whenStable().then(async () => {

      const dialogElement = fixture.nativeElement.querySelector('mat-dialog-container');
      expect(dialogElement).toBeNull();
      expect(dialogElement).toBeDefined();

      component.getGroups().catch(() => {
        expect(dialogElement).toBeDefined();
      });
    });
  });

  it('should get enrollments and display the table', () => {
    fixture.whenStable().then(async () => {
      fixture.detectChanges();

      const numberOfColumns = 4;
      component.getEnrollmentsByDay(new Date(), 1).then(() => {
        fixture.detectChanges();
        const table: HTMLElement[] = fixture.nativeElement.querySelectorAll('td');
        expect(table.length / numberOfColumns).toBe(component.enrollments.length);
      });
    });
  });

  it('should change and update attendance and not change if form id does not exist', () => {
    fixture.whenStable().then(async () => {

      component.getEnrollmentsByDay(new Date(), 1).then(() => {
        expect(component.attendances.controls[0].value.attendance[component.today]).toBe(component.attendanceCodes.RAD_ATTENDANCE_CODE);
        component.changeAttendance(switchRadioButtonOutputMockNoAttendance);
        expect(component.attendances.controls[0].value.attendance[component.today]).toBe(component.attendanceCodes.RAD_NO_ATTENDANCE_CODE);
        component.changeAttendance(switchRadioButtonOutputMockError);
        expect(component.attendances.controls[0].value.attendance[component.today]).toBe(component.attendanceCodes.RAD_NO_ATTENDANCE_CODE);
      });
    });
  });

  it('should update all today attendances', () => {
    fixture.whenStable().then(async () => {

      component.getEnrollmentsByDay(new Date(), 1).then(() => {
        component.updateAllTodayAttendances(component.attendanceCodes.RAD_ATTENDANCE_CODE);
        expect(component.attendances.controls.filter(c =>
          c.value.attendance[component.today] === component.attendanceCodes.RAD_ATTENDANCE_CODE).length
        ).toBe(component.attendances.controls.length);

        component.updateAllTodayAttendances(component.attendanceCodes.RAD_NO_ATTENDANCE_CODE);
        expect(component.attendances.controls.filter(c =>
          c.value.attendance[component.today] === component.attendanceCodes.RAD_NO_ATTENDANCE_CODE).length
        ).toBe(component.attendances.controls.length);
      });
    });
  });

  it('should open a modal', () => {
    const dialogElement = fixture.nativeElement.querySelector('mat-dialog-container');
    expect(dialogElement).toBeNull();
    component.modalService.openModal(SUCCESS_ATTENDANCE_SAVE_CONTAINER);
    expect(dialogElement).toBeDefined();
  });

  describe('saveAttendance', () => {
    let modalSpy;

    beforeEach(() => {
      // tslint:disable-next-line:no-string-literal
      modalSpy = spyOn(component['modalService'], 'openModal');
    });

    it('should open a modal with success message', () => {
      fixture.whenStable().then(async () => {

        const attendance: IAttendanceUpdateObject = { attendances: [{ id: 1, attendance: '2' }] };
        component.getEnrollmentsByDay(new Date(), 1).then(async () => {
          component.updateAllTodayAttendances(component.attendanceCodes.RAD_ATTENDANCE_CODE);
          await component.saveAttendance(attendance);
          expect(modalSpy).toHaveBeenCalledWith(SUCCESS_ATTENDANCE_SAVE_CONTAINER);
        });
      });
    });

    it('should open a modal with error message', () => {
      fixture.whenStable().then(async () => {

        const attendance: IAttendanceUpdateObject = undefined;
        component.getEnrollmentsByDay(new Date(), 1).then(async () => {
          component.updateAllTodayAttendances(component.attendanceCodes.RAD_ATTENDANCE_CODE);
          await component.saveAttendance(attendance);
          expect(modalSpy).toHaveBeenCalledWith(component.errorMessage);
        });
      });
    });

    it('should not open a modal in not active month', () => {
      fixture.whenStable().then(async () => {

        const attendance: IAttendanceUpdateObject = undefined;
        component.getEnrollmentsByDay(new Date(), 1).then(async () => {
          component.activeMonth = false;
          await component.saveAttendance(attendance);
          expect(modalSpy).toHaveBeenCalledTimes(0);
        });
      });
    });
  });

  it('should update caution message to NOT_WORKING_DAY_CONTAINER', () => {
    component.workingDay = false;
    component.updateCautionMessage();
    expect(component.cautionMessage).toBe(NOT_WORKING_DAY_CONTAINER);
  });

  it('should update caution message to EMPTY_GROUP_LIST_CONTAINER', () => {
    component.enrollments = [];
    component.updateCautionMessage();
    expect(component.cautionMessage).toBe(EMPTY_GROUP_LIST_CONTAINER);
  });

  it('should update caution message to EMPTY_ENROLLMENT_LIST_CONTAINER', () => {
    component.enrollments = [];
    component.groups = groupsMock;
    component.updateCautionMessage();
    expect(component.cautionMessage).toBe(EMPTY_ENROLLMENT_LIST_CONTAINER);
  });

});
