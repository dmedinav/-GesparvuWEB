import { Subscription } from 'rxjs';
import Utils from '@utils/utils';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
import { IEnrollmentsByGroupResponse } from './../../common/interfaces/enrollments.interface';
import { EnrollmentService } from './../../services/enrollment/enrollment.service';
import { ActivatedRoute, Router } from '@angular/router';
import {
  DEFAULT_ERROR_MESSAGE_CONTAINER,
  DEFAULT_EMPTY_MESSAGE_CONTAINER
} from './../../common/constants/default-image-container-messages';
import { IDataLoaded, IDefaultImageContainer } from './../../common/interfaces/default.interface';
import { Component, OnInit, OnDestroy } from '@angular/core';
import { GroupService } from '@services/group/group.service';
import { Location } from '@angular/common';
import { ModalService } from '@services/modal/modal.service';
import { ISimpleGroup } from 'app/common/interfaces/groups.interface';
import { ITransfer } from '../../common/interfaces/transfers.interface';
import { TRANSFER_SESSION_STORAGE_KEY, ENROLLMENT_SESSION_STORAGE_KEY } from 'app/common/constants/default.constants';
import { HOME_ROUTE, TRANSFER_MAIN_ROUTE } from 'app/common/constants/routes.constants';


@Component({
  selector: 'app-transfers-assignation',
  templateUrl: './transfer-assignation.component.html',
  styleUrls: ['./transfer-assignation.component.scss']
})
export class TransferAssignationComponent implements OnInit, OnDestroy {

  subscription: Subscription;
  isDataLoaded: IDataLoaded;
  cautionMessage: IDefaultImageContainer;
  errorMessage: IDefaultImageContainer;
  enrollmendId: string;
  enrollment: IEnrollmentsByGroupResponse;
  transferCreationForm: FormGroup;
  enrollmentRut: string;
  groups: ISimpleGroup[];
  maxTransferDate: Date;
  minTransferDate: Date;
  isPresentLabel: string;
  newTransfer: ITransfer;
  transferInSessionStorage: boolean;
  deleteSessionStorage: boolean;

  get newGroup() { return this.transferCreationForm.get('newGroup'); }
  get transferDate() { return this.transferCreationForm.get('transferDate'); }
  get enrollmentIsPresent() { return this.transferCreationForm.get('isPresent'); }

  constructor(
    private formBuilder: FormBuilder,
    private location: Location,
    private readonly enrollmentService: EnrollmentService,
    private route: ActivatedRoute,
    public readonly groupService: GroupService,
    public readonly modalService: ModalService,
    public router: Router,
  ) {
    this.subscription = new Subscription();
    this.cautionMessage = DEFAULT_EMPTY_MESSAGE_CONTAINER;
    this.errorMessage = DEFAULT_ERROR_MESSAGE_CONTAINER;
    this.enrollmendId = this.route.snapshot.paramMap.get('enrollment');
    this.isDataLoaded = {
      hasErrors: false,
      isLoaded: false,
    };

    // Set `minTransferDate` to be the first day of the previous month and
    // set `maxTransferDate` to be the last day of the curent month
    const today = new Date();
    this.minTransferDate = new Date(today.getUTCFullYear(), today.getUTCMonth() - 2, 1);
    this.maxTransferDate = new Date(today.getUTCFullYear(), today.getUTCMonth() + 1, 0);

    this.enrollmentRut = '';
    this.groups = [];
    this.newTransfer = {} as ITransfer;
    this.transferInSessionStorage = false;
    this.deleteSessionStorage = true;
  }

  ngOnInit() {
    Promise.all([
      this.groupService.getGroupsByTeacher(),
      this.enrollmentService.getEnrollmentById(this.enrollmendId)
    ])
      .then(([groups, enrollment]) => {
        this.groups = groups.filter(group => group.id !== enrollment.group.id);

        this.enrollment = enrollment;
        this.enrollmentRut = Utils.formatToRut(this.enrollment.infant.rut + this.enrollment.infant.rutDv);

        // Set `minTransferDate` to be equal to enrollment's enrollment date
        // if `minTransferDate` is before to it
        const enrollmentDate = new Date(this.enrollment.enrollmentDate);
        if (this.minTransferDate.getTime() < enrollmentDate.setHours(0,0,0,0)) {
          this.minTransferDate = enrollmentDate;
        }

        this.transferCreationForm = this.formBuilder.group({
          enrollment: enrollment.id,
          newGroup: new FormControl('', Validators.compose([Validators.required])),
          transferDate: new FormControl({value: new Date()}, Validators.compose([Validators.required])),
          isPresent: new FormControl(false),
        });

        this.subscription.add(this.enrollmentIsPresent.valueChanges.subscribe(() => {
          this.changeIsPresentLabel();
        }));

        this.loadFromSessionStorage();
      })
      .catch((err) => {
        if (err.statusCode === 404) {
          this.cautionMessage.title = err.errorMessage;
        } else {
          this.errorMessage.title = err.errorMessage;
          this.modalService.openModal(this.errorMessage);
        }
        this.isDataLoaded.hasErrors = true;
      })
      .finally(() => {
        this.isDataLoaded.isLoaded = true;
      });
  }

  ngOnDestroy() {
    if (this.deleteSessionStorage) {
      sessionStorage.clear();
    }
  }

  public changeIsPresentLabel() {
    this.isPresentLabel = this.enrollmentIsPresent.value ? 'Presente' : 'Ausente';
  }

  public loadFromSessionStorage() {
    const sessionTransfer = sessionStorage.getItem(TRANSFER_SESSION_STORAGE_KEY);

    if (sessionTransfer) {
      this.transferInSessionStorage = true;
      this.newTransfer = JSON.parse(sessionTransfer);
      this.simpleFillForm();
    }
  }

  public simpleFillForm() {
    Object.keys(this.transferCreationForm.controls).forEach(key => {
      this.transferCreationForm.controls[key].setValue(this.newTransfer[key]);
    });
  }

  public goBack() {
    this.location.back();
  }

  public createNewTransfer() {
    if (this.transferCreationForm.valid) {
      this.newTransfer = this.transferCreationForm.getRawValue();
      this.newTransfer.newGroupName = this.groups.find(g => g.id === this.newTransfer.newGroup).name;

      sessionStorage.setItem(TRANSFER_SESSION_STORAGE_KEY, JSON.stringify(this.newTransfer));
      sessionStorage.setItem(ENROLLMENT_SESSION_STORAGE_KEY, JSON.stringify(this.enrollment));

      this.deleteSessionStorage = false;

      this.navigateToDetails();
    }
  }

  public navigateToDetails() {
    this.router.navigateByUrl(`${HOME_ROUTE}/${TRANSFER_MAIN_ROUTE}/${this.enrollmendId}/details`);
  }
}
