import { TRANSFER_MAIN_ROUTE } from '../../common/constants/routes.constants';
import { HOME_ROUTE } from './../../common/constants/routes.constants';
import {
  EMPTY_ENROLLMENT_SEARCH_CONTAINER,
  DEFAULT_ERROR_MESSAGE_CONTAINER
} from './../../common/constants/default-image-container-messages';
import { ModalService } from './../../services/modal/modal.service';
import { IDataLoaded, IDefaultImageContainer } from './../../common/interfaces/default.interface';
import { IEnrollmentsByGroupResponse } from './../../common/interfaces/enrollments.interface';
import { EnrollmentService } from './../../services/enrollment/enrollment.service';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
import { Component, OnInit } from '@angular/core';
import Utils from '@utils/utils';
import { ENROLLMENT_SEARCH_COLUMNS } from '../../common/constants/default.constants';
import { Router } from '@angular/router';

@Component({
  selector: 'app-tranfers-search',
  templateUrl: './transfer-search.component.html',
  styleUrls: ['./transfer-search.component.scss']
})

export class TransferSearchComponent implements OnInit {

  searchForTransferForm: FormGroup;
  enrollments: IEnrollmentsByGroupResponse[];
  errorMessage: IDefaultImageContainer;
  isNewDataLoaded: IDataLoaded;
  displayedColumns: string[];
  cautionMessage: IDefaultImageContainer;

  constructor(
    private formBuilder: FormBuilder,
    private enrollmentService: EnrollmentService,
    public modalService: ModalService,
    public router: Router,
  ) {
    this.isNewDataLoaded = {
      hasErrors: false,
      isLoaded: true,
    };
    this.errorMessage = DEFAULT_ERROR_MESSAGE_CONTAINER;
    this.enrollments = null;
    this.cautionMessage = null;
    this.displayedColumns = ENROLLMENT_SEARCH_COLUMNS;
  }

  ngOnInit() {
    this.searchForTransferForm = this.formBuilder.group({
      rutOrName: new FormControl('', Validators.compose([
        Validators.required,
      ])),
    });
  }

  public rutOrNameFormatter() {
    const rut = Utils.formatToRutAndName(this.searchForTransferForm.value.rutOrName);
    this.searchForTransferForm.patchValue({
      rutOrName: rut
    });
  }

  public updateCautionMessage() {
    this.cautionMessage = this.enrollments.length === 0 ? EMPTY_ENROLLMENT_SEARCH_CONTAINER : null;
  }

  public navigateTo(id: string) {
    this.router.navigateByUrl(`${HOME_ROUTE}/${TRANSFER_MAIN_ROUTE}/${id}`);
  }

  public async searchEnrollments(formValue) {
    const filter = formValue.rutOrName.replace(/\./g, '');
    if (this.searchForTransferForm.valid) {
      this.enrollments = null;
      this.isNewDataLoaded.isLoaded = false;
      this.isNewDataLoaded.hasErrors = false;
      try {
        const response = await this.enrollmentService.getEnrollmentsByFilter(filter);
        this.enrollments = response.enrollments;
        this.updateCautionMessage();
      } catch (err) {
        this.errorMessage.title = err.errorMessage;
        this.isNewDataLoaded.hasErrors = true;
        this.modalService.openModal(this.errorMessage);
      }
      this.isNewDataLoaded.isLoaded = true;
    }
  }
}
