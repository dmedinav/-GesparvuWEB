import { SecondaryButtonModule } from './../../components/secondary-button/secondary-button.module';
import { CommonAppModule } from '../../common/common.module';
import { ReactiveFormsModule } from '@angular/forms';
import { Routes, RouterModule } from '@angular/router';
import { InfantDetailsComponent } from './infant-details.component';
import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { PrimaryButtonModule } from '../../components/primary-button/primary-button.module';

const routes: Routes = [
  {
    path: '',
    component: InfantDetailsComponent,
  },
];

@NgModule({
  imports: [
    CommonModule,
    ReactiveFormsModule,
    RouterModule.forChild(routes),
    PrimaryButtonModule,
    SecondaryButtonModule,
    CommonAppModule,
  ],
  declarations: [
    InfantDetailsComponent
  ],
  exports: [
    InfantDetailsComponent
  ]
})
export class InfantDetailsModule { }
