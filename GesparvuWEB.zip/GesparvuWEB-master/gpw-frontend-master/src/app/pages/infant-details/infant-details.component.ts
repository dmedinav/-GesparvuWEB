import { DEFAULT_ERROR_MESSAGE_CONTAINER, SUCCESS_INFANT_SAVE_CONTAINER } from './../../common/constants/default-image-container-messages';
import { IDefaultImageContainer } from './../../common/interfaces/default.interface';
import { ModalService } from '@services/modal/modal.service';
import { Location } from '@angular/common';
import { InfantService } from './../../services/infant/infant.service';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
import { HOME_ROUTE, INFANT_CREATION_SEARCH_ROUTE } from './../../common/constants/routes.constants';
import { Component, OnInit, OnDestroy } from '@angular/core';
import { IInfantCreation } from '../../common/interfaces/infant.interface';
import { Router } from '@angular/router';
import { IDataLoaded } from '../../common/interfaces/default.interface';
import { INFANT_SESSION_STORAGE_KEY, GA_CREATE_ENROLLMENT_ACTION, GA_CREATE_ENROLLMENT_LABEL } from '../../common/constants/default.constants';
import { GoogleAnalyticsService } from '@services/google-analytics/google-analytics.service';

@Component({
  selector: 'app-infant-details',
  templateUrl: './infant-details.component.html',
  styleUrls: ['./infant-details.component.scss']
})

export class InfantDetailsComponent implements OnInit, OnDestroy {

  infantCreationForm: FormGroup;
  infant: IInfantCreation;
  exitWithButton: boolean;
  isCreationCompleted: IDataLoaded;
  isInfantCreated: boolean;
  errorMessage: IDefaultImageContainer;

  constructor(
    private router: Router,
    private formBuilder: FormBuilder,
    private infantService: InfantService,
    private location: Location,
    private modalService: ModalService,
    public gaService: GoogleAnalyticsService,
  ) {
    this.exitWithButton = false;
    this.isInfantCreated = false;
    this.isCreationCompleted = {
      isLoaded: true,
      hasErrors: false,
    };
    this.errorMessage = DEFAULT_ERROR_MESSAGE_CONTAINER;
  }

  ngOnInit() {
    const infantString = sessionStorage.getItem(INFANT_SESSION_STORAGE_KEY);
    if (infantString) {
      this.infant = JSON.parse(infantString) as IInfantCreation;
      this.infantCreationForm = this.formBuilder.group({
        ...this.infant,
        description: this.infant.rut ?
         new FormControl('', Validators.maxLength(600)) :
         new FormControl('', Validators.compose([Validators.required, Validators.maxLength(600)]))
      });
    } else {
      this.router.navigateByUrl(`${HOME_ROUTE}/${INFANT_CREATION_SEARCH_ROUTE}`);
    }
  }

  get description() {
    return this.infantCreationForm.controls.description.value;
  }

  public goBack() {
    this.exitWithButton = true;
    this.location.back();
  }

  public async createInfant(infantValue: IInfantCreation) {
    if (this.infantCreationForm.valid && !this.isInfantCreated) {
      this.isInfantCreated = true;
      this.isCreationCompleted.isLoaded = false;

      if (infantValue.rut) { infantValue.rut = infantValue.rut.replace(/\./g, ''); }

      try {
        await this.infantService.createInfant(infantValue);
        this.modalService.openModal(SUCCESS_INFANT_SAVE_CONTAINER);
        sessionStorage.removeItem(INFANT_SESSION_STORAGE_KEY);

        // Send google analytics event
        this.gaService.sendInfantManagementEvent(GA_CREATE_ENROLLMENT_ACTION, GA_CREATE_ENROLLMENT_LABEL);
      } catch (err) {
        this.isInfantCreated = false;
        this.isCreationCompleted.hasErrors = true;
        this.errorMessage.title = err.errorMessage;
        this.modalService.openModal(this.errorMessage);
      }

      this.isCreationCompleted.isLoaded = true;
    }
  }

  ngOnDestroy(): void {
    if (!this.exitWithButton) {
      sessionStorage.removeItem(INFANT_SESSION_STORAGE_KEY);
    }
  }

}
