import { SUCCESS_INFANT_SAVE_CONTAINER } from './../../common/constants/default-image-container-messages';
import { HOME_ROUTE, INFANT_CREATION_SEARCH_ROUTE } from './../../common/constants/routes.constants';
import { RouterMovementsMock } from './../../mocks/router.mock';
import { InfantServiceMock, infantBaseMock } from './../../mocks/infant.mock';
import { InfantService } from './../../services/infant/infant.service';
import { HttpClientModule } from '@angular/common/http';
import { RouterTestingModule } from '@angular/router/testing';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { PrimaryButtonModule } from '../../components/primary-button/primary-button.module';
import { DefaultImageContainerModule } from '../../components/default-image-container/default-image-container.module';
import { MaterialModule } from '../../material.module';
import { ReactiveFormsModule } from '@angular/forms';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { InfantDetailsComponent } from './infant-details.component';
import { BrowserDynamicTestingModule } from '@angular/platform-browser-dynamic/testing';
import { GenericModalComponent } from '../../components/generic-modal/generic-modal.component';
import { SecondaryButtonModule } from '../../components/secondary-button/secondary-button.module';
import { infantPostMock } from '../../mocks/infant.mock';
import { Router } from '@angular/router';

// tslint:disable:no-string-literal
describe('InfantDetailsComponent', () => {
  let component: InfantDetailsComponent;
  let fixture: ComponentFixture<InfantDetailsComponent>;
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [InfantDetailsComponent, GenericModalComponent],
      imports: [
        RouterTestingModule,
        BrowserAnimationsModule,
        ReactiveFormsModule,
        MaterialModule,
        DefaultImageContainerModule,
        PrimaryButtonModule,
        SecondaryButtonModule,
        HttpClientModule,
      ],
      providers: [
        { provide: Router, useClass: RouterMovementsMock },
        { provide: InfantService, useClass: InfantServiceMock },
      ],
    })
    .overrideModule(BrowserDynamicTestingModule, { set: { entryComponents: [GenericModalComponent] } })
    .compileComponents();
  }));

  describe('Normal behavior with rut', () => {
    beforeEach(() => {
      spyOn(sessionStorage, 'getItem').and.returnValue(JSON.stringify(infantPostMock));
      fixture = TestBed.createComponent(InfantDetailsComponent);
      component = fixture.componentInstance;
      fixture.detectChanges();
    });

    it('should create', () => {
      expect(component).toBeTruthy();
    });

    it('should be valid with empty description with rut in infant', () => {
      expect(component.infantCreationForm.valid).toBeTruthy();
    });

    it('should call location back', () => {
      const locationSpy = spyOn(component['location'], 'back').and.returnValue(undefined);
      expect(component.exitWithButton).toBeFalsy();
      component.goBack();
      expect(component.exitWithButton).toBeTruthy();
      expect(locationSpy).toHaveBeenCalledTimes(1);
    });

    it('should create an infant when infant service is call without errors', async () => {
        const modalSpy = spyOn(component['modalService'], 'openModal').and.returnValue({});
        await component.createInfant(component.infantCreationForm.value);
        expect(modalSpy).toHaveBeenCalledWith(SUCCESS_INFANT_SAVE_CONTAINER);
    });

    it('should not create an infant it its already created', async () => {
      const modalSpy = spyOn(component['modalService'], 'openModal').and.returnValue({});
      component.isInfantCreated = true;
      await component.createInfant(component.infantCreationForm.value);
      expect(modalSpy).toHaveBeenCalledTimes(0);
  });

    it('should not create an infant when infant service throw an exception', async () => {
        spyOn(component['infantService'], 'createInfant').and.returnValue(Promise.reject({ errorMessage: 'Error' }));
        const modalSpy = spyOn(component['modalService'], 'openModal').and.returnValue({});
        await component.createInfant(component.infantCreationForm.value);
        expect(modalSpy).toHaveBeenCalledWith(component.errorMessage);
        expect(component.isCreationCompleted.hasErrors).toBe(true);
    });

  });

  describe('Normal behavior without rut', () => {
    beforeEach(() => {
      spyOn(sessionStorage, 'getItem').and.returnValue(JSON.stringify(infantBaseMock));
      fixture = TestBed.createComponent(InfantDetailsComponent);
      component = fixture.componentInstance;
      fixture.detectChanges();
    });

    it('should be invalid with empty description without rut in infant', () => {
      expect(component.infantCreationForm.invalid).toBeTruthy();
    });
  });

  describe('No object in sessionStorage', () => {
    let spy;
    beforeEach(() => {
      spyOn(sessionStorage, 'getItem').and.returnValue(undefined);
      fixture = TestBed.createComponent(InfantDetailsComponent);
      component = fixture.componentInstance;
      spy = spyOn(component['router'], 'navigateByUrl');
      fixture.detectChanges();
    });

    it('should redirect to infant search', () => {
      // tslint:disable-next-line:no-string-literal
      expect(spy).toHaveBeenCalledWith(`${HOME_ROUTE}/${INFANT_CREATION_SEARCH_ROUTE}`);
    });

  });


  describe('On destroy with correct exit', () => {

    beforeEach(() => {
      spyOn(sessionStorage, 'getItem').and.returnValue(undefined);
      fixture = TestBed.createComponent(InfantDetailsComponent);
      component = fixture.componentInstance;
      fixture.detectChanges();
    });


    it('should not called session storage if exit is correct', () => {
      // tslint:disable-next-line:no-string-literal
      component.exitWithButton = true;
      const removeSpy = spyOn(sessionStorage, 'removeItem').and.callFake(() => {});
      component.ngOnDestroy();
      expect(removeSpy).toHaveBeenCalledTimes(0);
    });

  });

  describe('On destroy with no correct exit', () => {

    beforeEach(() => {
      spyOn(sessionStorage, 'getItem').and.returnValue(undefined);
      fixture = TestBed.createComponent(InfantDetailsComponent);
      component = fixture.componentInstance;
      fixture.detectChanges();
    });

    it('should called session storage if exit is not correct', () => {
      // tslint:disable-next-line:no-string-literal
      component.exitWithButton = false;
      const removeSpy = spyOn(sessionStorage, 'removeItem').and.callFake(() => {});
      component.ngOnDestroy();
      expect(removeSpy).toHaveBeenCalledTimes(1);
    });

  });

});
