import { MONTHS_NAMES } from './../../common/constants/default.constants';
import { EMPTY_GROUP_LIST_CONTAINER, EMPTY_ENROLLMENT_LIST_CONTAINER } from './../../common/constants/default-image-container-messages';
import { IAttendanceCodeTypes } from './../../common/interfaces/attendance-types.interface';
import { Subscription } from 'rxjs';
import {
  DEFAULT_ERROR_MESSAGE_CONTAINER,
} from '../../common/constants/default-image-container-messages';
import { IDataLoaded, IDefaultImageContainer } from '../../common/interfaces/default.interface';
import { Component, OnInit, ViewChild, OnDestroy } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';
import { IEnrollmentsByGroupResponse } from '../../common/interfaces/enrollments.interface';
import { ModalService } from '@services/modal/modal.service';
import { ISimpleGroup } from '../../common/interfaces/groups.interface';
import { GroupService } from '@services/group/group.service';
import { AttendanceService } from '../../services/attendance/attendance.service';
import { MatDatepicker } from '@angular/material';
import { EnrollmentService } from '../../services/enrollment/enrollment.service';
import Utils from '@utils/utils';
import { IDailyInfo } from '../../common/interfaces/attendance.interface';

@Component({
  selector: 'app-monthly-attendance',
  templateUrl: './monthly-attendance.component.html',
  styleUrls: ['./monthly-attendance.component.scss']
})
export class MonthlyAttendanceComponent implements OnInit, OnDestroy {

  enrollments: IEnrollmentsByGroupResponse[];
  isGroupsLoaded: IDataLoaded;
  isFileLoaded: IDataLoaded;
  areNewEnrollmentsLoaded: IDataLoaded;
  errorMessage: IDefaultImageContainer;
  daysInfo: IDailyInfo[];
  cautionMessage: IDefaultImageContainer;
  groups: ISimpleGroup[];
  filterForm: FormGroup;
  displayedColumns: string[];
  monthLabel: string;
  holidays: object;
  attendanceCodes: IAttendanceCodeTypes;
  subscription: Subscription;
  calendarMaxDate: Date;
  @ViewChild('picker', {static: false}) datePicker: MatDatepicker<any>;

  constructor(
    private formBuilder: FormBuilder,
    public readonly groupService: GroupService,
    private attendanceService: AttendanceService,
    public readonly modalService: ModalService,
    private enrollmentService: EnrollmentService,
  ) {
    const today = new Date();
    this.calendarMaxDate = new Date(today.getUTCFullYear(), today.getUTCMonth() + 1, 0);
    this.enrollments = [];
    this.daysInfo = [];
    this.displayedColumns = [];
    this.holidays = {};
    this.cautionMessage = null;
    this.errorMessage = DEFAULT_ERROR_MESSAGE_CONTAINER;
    this.isGroupsLoaded = {
      hasErrors: false,
      isLoaded: false,
    };
    this.areNewEnrollmentsLoaded = {
      hasErrors: false,
      isLoaded: false,
    };
    this.isFileLoaded = {
      hasErrors: false,
      isLoaded: true,
    };
    this.subscription = new Subscription();
  }

  ngOnInit() {
    this.getGroups()
    .then(() => {
      if (this.groups.length > 0) {
        this.filterForm = this.formBuilder.group({
          date: new FormControl(new Date(), Validators.compose([
            Validators.required,
          ])),
          group: new FormControl(this.groups[0].id, Validators.compose([
            Validators.required,
          ])),
        });
        this.getEnrollmentsByMonth(this.selectedDate.value, this.selectedGroupId);
        this.subscription.add(this.filterForm.valueChanges.subscribe(() => {
          // Do not update enrollments if filter form is invalid
          if (this.filterForm.invalid) return;

          const rawFilters = this.filterForm.getRawValue();

          if (rawFilters.date && rawFilters.group) {
            this.getEnrollmentsByMonth(rawFilters.date, rawFilters.group);
          }
        }));
      } else {
        this.updateCautionMessage();
      }
    });
  }

  get selectedDate() {
    return this.filterForm.controls.date;
  }

  get selectedGroupId() {
    return this.filterForm.controls.group.value as number;
  }

  public monthSelectedHandler(event: Date) {
    this.datePicker.close();
    const date = new Date(event);
    this.selectedDate.setValue(date);
  }

  public async getGroups() {
    this.isGroupsLoaded.isLoaded = false;
    this.isGroupsLoaded.hasErrors = false;
    this.groups = [];
    try {
      this.groups = await this.groupService.getGroupsByTeacher();
    } catch (err) {
      this.errorMessage.title = err.errorMessage;
      this.isGroupsLoaded.hasErrors = true;
      this.modalService.openModal(this.errorMessage);
    }
    this.isGroupsLoaded.isLoaded = true;
  }

  public async getEnrollmentsByMonth(date: Date, group: number) {
    this.areNewEnrollmentsLoaded.isLoaded = false;
    this.areNewEnrollmentsLoaded.hasErrors = false;
    const year = date.getUTCFullYear();
    const month = date.getUTCMonth() + 1;
    try {
      const enrollmentsByGroup = await this.enrollmentService.getEnrollmentsByGroupIdAndHalfDate(group, year, month);
      this.enrollments = enrollmentsByGroup.enrollments;
      this.attendanceCodes = enrollmentsByGroup.attendanceCodes;
      this.updateCurrentColumns(month, year);
      this.updateAttendances(date);
      this.updateMonthLabel(date);
      this.updateCautionMessage();
    } catch (err) {
      this.errorMessage.title = err.errorMessage;
      this.areNewEnrollmentsLoaded.hasErrors = true;
      this.modalService.openModal(this.errorMessage);
    }
    this.areNewEnrollmentsLoaded.isLoaded = true;
  }

  public async downloadExcelFile() {
    this.isFileLoaded.isLoaded = false;
    this.isFileLoaded.hasErrors = false;
    try {
      const month = this.selectedDate.value.getUTCMonth() + 1;
      const year = this.selectedDate.value.getUTCFullYear();
      const group = this.groups.find(g => g.id === this.selectedGroupId);
      await this.attendanceService.getExcelFile(month, year, group);
    } catch (err) {
      this.errorMessage.title = err.errorMessage;
      this.isFileLoaded.hasErrors = true;
      this.modalService.openModal(this.errorMessage);
    }
    this.isFileLoaded.isLoaded = true;
  }

  public updateCurrentColumns(month: number, year: number) {
    this.daysInfo = Utils.fillArrayWithMonthDays(month, year);
    this.displayedColumns = ['index', 'names'].concat(this.daysInfo.map(value => value.day));
  }

  public updateAttendances(date: Date) {
    this.holidays = {};
    this.enrollments.forEach((enrollment) => {
      const attendances = JSON.parse(enrollment.attendances[0].attendance as string);
      for (const attendance of Object.keys(attendances)) {
        const daily = new Date(date.getUTCFullYear(), date.getUTCMonth(), parseInt(attendance, 10));
        if (enrollment.retirementDate && Utils.compareDates(daily, new Date(enrollment.retirementDate))) {
          attendances[attendance] = 'R';
        } else if (attendances[attendance] === this.attendanceCodes.RAD_ATTENDANCE_CODE) {
          attendances[attendance] = 'P';
        } else if (attendances[attendance] === this.attendanceCodes.RAD_NO_ATTENDANCE_CODE) {
          attendances[attendance] = 'A';
        } else if (attendances[attendance] === this.attendanceCodes.RAD_HOLIDAY_CODE) {
          this.holidays[attendance] = 'F';
        }
      }
      enrollment.attendances[0].attendance = attendances;
    });
  }

  public updateCautionMessage() {
    this.cautionMessage = this.groups.length === 0 ? EMPTY_GROUP_LIST_CONTAINER :
    this.enrollments.length === 0 ? EMPTY_ENROLLMENT_LIST_CONTAINER : null;
  }

  get emptyContainer() {
    return this.isGroupsLoaded.isLoaded && this.areNewEnrollmentsLoaded.isLoaded &&
    !this.areNewEnrollmentsLoaded.hasErrors && ( this.groups.length === 0 || this.enrollments.length === 0 );
  }

  public updateMonthLabel(date: Date) {
    const year = date.getUTCFullYear();
    const month = MONTHS_NAMES[date.getUTCMonth()];
    this.monthLabel = `Asistencia mensual - ${month} ${year}`;
  }

  ngOnDestroy(): void {
    this.subscription.unsubscribe();
  }

}
