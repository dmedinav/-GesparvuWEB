import { EMPTY_GROUP_LIST_CONTAINER, EMPTY_ENROLLMENT_LIST_CONTAINER } from './../../common/constants/default-image-container-messages';
import { AttendanceService } from '@services/attendance/attendance.service';
import { GroupService } from '@services/group/group.service';
import { GroupServiceMock } from './../../mocks/groups.mocks';
import { AttendanceServiceMock, attendanceCodeTypesMock } from './../../mocks/attendance.mocks';
import { EnrollmentService } from '@services/enrollment/enrollment.service';
import { EnrollmentServiceMock, enrollmentByGroupAndMonthMock } from './../../mocks/enrollments.mocks';
import { MonthlyAttendanceComponent } from './monthly-attendance.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { CommonAppModule } from '../../common/common.module';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { DefaultImageContainerModule } from '../../components/default-image-container/default-image-container.module';
import { PrimaryButtonModule } from '../../components/primary-button/primary-button.module';
import { ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { GenericModalComponent } from '../../components/generic-modal/generic-modal.component';
import { BrowserDynamicTestingModule } from '@angular/platform-browser-dynamic/testing';
import { SexualityService } from '../../services/sexuality/sexuality.service';
import { SexualitiesServiceMock } from '../../mocks/sexualities.mocks';

// tslint:disable:no-string-literal
describe('MonthlyAttendanceComponent', () => {
  let component: MonthlyAttendanceComponent;
  let fixture: ComponentFixture<MonthlyAttendanceComponent>;

  beforeEach(async (() => {
    TestBed.configureTestingModule({
      declarations: [ MonthlyAttendanceComponent],
      imports: [
        BrowserAnimationsModule,
        ReactiveFormsModule,
        CommonAppModule,
        DefaultImageContainerModule,
        PrimaryButtonModule,
        HttpClientModule,
      ],
      providers: [
        { provide: EnrollmentService, useClass: EnrollmentServiceMock },
        { provide: AttendanceService, useClass: AttendanceServiceMock },
        { provide: GroupService, useClass: GroupServiceMock },
        { provide: SexualityService, useClass: SexualitiesServiceMock },
      ],
    })
    .overrideModule(BrowserDynamicTestingModule, { set: { entryComponents: [GenericModalComponent] } })
    .compileComponents();
  }));


  describe('Normal behavior', () => {
    beforeEach(() => {
      fixture = TestBed.createComponent(MonthlyAttendanceComponent);
      component = fixture.componentInstance;
      fixture.detectChanges();
    });

    it('should create with no data in filterForm', () => {
      const spy = spyOn(component, 'getEnrollmentsByMonth').and.callFake(() => {});
      fixture.whenStable().then(() => {
        component.filterForm.setValue({date: true, group: 1});
        setTimeout(() => { expect(spy).toHaveBeenCalledTimes(2); }, 0);
      });
    });

    it('should create with no groups', () => {
      const spy = spyOn(component, 'updateCautionMessage').and.returnValue({});
      spyOn(component['groupService'], 'getGroupsByTeacher').and.returnValue([]);
      fixture.whenStable().then(() => {
        setTimeout(() => { expect(spy).toHaveBeenCalledTimes(1); }, 0);
      });
    });

    it('should create', () => {
      expect(component).toBeTruthy();
    });

    it('should set the new date', () => {
      fixture.whenStable().then(() => {
        const date = new Date(2019, 1, 20);
        component.datePicker = jasmine.createSpyObj('MatDatepicker', ['close']);
        component.monthSelectedHandler(date);
        expect(component.selectedDate.value.toISOString()).toBe(date.toISOString());
        expect(component.datePicker.close).toHaveBeenCalled();
      });
    });

    it('should get new groups', async () => {
      expect(component.groups.length).toBe(0);
      await component.getGroups().then(() => {
        expect(component.groups.length).toBe(2);
        expect(component.isGroupsLoaded.isLoaded).toBeTruthy();
      });
    });

    it('should not get new groups if service throw an error', async () => {
      const modalSpy = spyOn(component['modalService'], 'openModal');
      spyOn(component.groupService, 'getGroupsByTeacher').and.returnValue(Promise.reject({}));
      expect(component.groups.length).toBe(0);
      await component.getGroups().catch(() => {
        expect(component.isGroupsLoaded.hasErrors).toBeTruthy();
        expect(component.isGroupsLoaded.isLoaded).toBeTruthy();
        expect(modalSpy).toHaveBeenCalled();
      });
    });

    it('should get enrollments', async () => {
      const date = new Date(2019, 1, 20);
      expect(component.enrollments.length).toBe(0);
      await component.getEnrollmentsByMonth(date, 1).then(() => {
        expect(component.enrollments.length).toBe(2);
        expect(component.areNewEnrollmentsLoaded.isLoaded).toBeTruthy();
      });
    });

    it('should not get new enrollments if service throw an error', async () => {
      const date = new Date(2019, 1, 20);
      const modalSpy = spyOn(component['modalService'], 'openModal');
      spyOn(component['enrollmentService'], 'getEnrollmentsByGroupIdAndHalfDate').and.returnValue(Promise.reject({}));
      expect(component.enrollments.length).toBe(0);
      await component.getEnrollmentsByMonth(date, 1).catch(() => {
        expect(component.areNewEnrollmentsLoaded.hasErrors).toBeTruthy();
        expect(component.areNewEnrollmentsLoaded.isLoaded).toBeTruthy();
        expect(modalSpy).toHaveBeenCalled();
      });
    });

    it('should set de displayed columns with the month days', async () => {
      component.updateCurrentColumns(2, 2019);
      expect(component.displayedColumns.length).toBe(30);
    });

    it('should change enrollments attendance based on attendanceCodes', async () => {
      component.enrollments = [enrollmentByGroupAndMonthMock];
      component.attendanceCodes = attendanceCodeTypesMock;
      const date = new Date(2019, 2, 1);
      component.updateAttendances(date);
      expect(component.enrollments[0].attendances[0].attendance[1]).toBe('P');
      expect(component.enrollments[0].attendances[0].attendance[2]).toBe('A');
      expect(component.holidays[4]).toBe('F');
      expect(component.enrollments[0].attendances[0].attendance[10]).toBe('R');
    });

  });

  describe('downloadExcelFile', () => {

    it('should call getExcelFile', () => {
      const spy = spyOn(component['attendanceService'], 'getExcelFile').and.returnValue(Promise.resolve({}));
      fixture.whenStable().then(async () => {
        component.filterForm.controls.date.setValue(new Date());
        component.filterForm.controls.group.setValue(254);
        await component.downloadExcelFile();
        expect(spy).toHaveBeenCalled();
        expect(component.isFileLoaded.hasErrors).toBeFalsy();
        expect(component.isFileLoaded.isLoaded).toBeTruthy();
      });
    });

    it('should call getExcelFile with error and open a modal', () => {
      const spy = spyOn(component['attendanceService'], 'getExcelFile').and.returnValue(Promise.reject({}));
      const modalSpy = spyOn(component['modalService'], 'openModal').and.returnValue({});
      fixture.whenStable().then(async () => {
        component.filterForm.controls.date.setValue(new Date());
        component.filterForm.controls.group.setValue(254);
        await component.downloadExcelFile();
        expect(spy).toHaveBeenCalled();
        expect(modalSpy).toHaveBeenCalled();
        expect(component.isFileLoaded.hasErrors).toBeTruthy();
        expect(component.isFileLoaded.isLoaded).toBeTruthy();
      });
    });

  });

  describe('get emptyContainer', () => {

    it('should return true (case 1)', () => {
      component.isGroupsLoaded.isLoaded = true;
      component.areNewEnrollmentsLoaded.isLoaded = true;
      component.areNewEnrollmentsLoaded.hasErrors = false;
      component.groups.length = 1;
      component.enrollments.length = 0;

      expect(component.emptyContainer).toBeTruthy();
    });

    it('should return true (case 2)', () => {
      component.isGroupsLoaded.isLoaded = true;
      component.areNewEnrollmentsLoaded.isLoaded = true;
      component.areNewEnrollmentsLoaded.hasErrors = false;
      component.groups.length = 0;
      component.enrollments.length = 1;

      expect(component.emptyContainer).toBeTruthy();
    });

    it('should return fasle', () => {
      component.isGroupsLoaded.isLoaded = true;
      component.areNewEnrollmentsLoaded.isLoaded = true;
      component.areNewEnrollmentsLoaded.hasErrors = true;
      component.groups.length = 0;
      component.enrollments.length = 0;

      expect(component.emptyContainer).toBeFalsy();
    });

  });

  describe('updateCautionMessage', () => {

    it('should set caution message for empty group', () => {
      component.groups.length = 0;
      component.updateCautionMessage();
      expect(component.cautionMessage).toBe(EMPTY_GROUP_LIST_CONTAINER);
    });

    it('should set caution message for empty enrollment list', () => {
      component.groups.length = 1;
      component.enrollments.length = 0;
      component.updateCautionMessage();
      expect(component.cautionMessage).toBe(EMPTY_ENROLLMENT_LIST_CONTAINER);
    });

    it('should set caution message for empty enrollment list', () => {
      component.groups.length = 1;
      component.enrollments.length = 1;
      component.updateCautionMessage();
      expect(component.cautionMessage).toBe(null);
    });

  });

  describe('updateMonthLabel', () => {

    it('should change month label with given date', () => {
      component.updateMonthLabel(new Date(2019, 0, 1));
      expect(component.monthLabel).toBe('Asistencia mensual - Enero 2019');

      component.updateMonthLabel(new Date(2019, 11, 1));
      expect(component.monthLabel).toBe('Asistencia mensual - Diciembre 2019');
    });

  });

});
