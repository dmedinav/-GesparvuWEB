import { CommonAppModule } from './../../common/common.module';
import { Routes, RouterModule } from '@angular/router';
import { NgModule } from '@angular/core';
import { PrimaryButtonModule } from '../../components/primary-button/primary-button.module';
import { MonthlyAttendanceComponent } from './monthly-attendance.component';

const routes: Routes = [
  {
    path: '',
    component: MonthlyAttendanceComponent,
  },
];

@NgModule({
  imports: [
    RouterModule.forChild(routes),
    PrimaryButtonModule,
    CommonAppModule,
  ],
  declarations: [
    MonthlyAttendanceComponent
  ],
})
export class MonthlyAttendanceModule { }
