import { SecondaryButtonModule } from './../../components/secondary-button/secondary-button.module';
import { CommonAppModule } from '../../common/common.module';
import { ReactiveFormsModule } from '@angular/forms';
import { Routes, RouterModule } from '@angular/router';
import { TransferDetailsComponent } from './transfer-details.component';
import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { PrimaryButtonModule } from '../../components/primary-button/primary-button.module';

const routes: Routes = [
  {
    path: '',
    component: TransferDetailsComponent,
  },
];

@NgModule({
  imports: [
    CommonModule,
    ReactiveFormsModule,
    RouterModule.forChild(routes),
    PrimaryButtonModule,
    SecondaryButtonModule,
    CommonAppModule,
  ],
  declarations: [
    TransferDetailsComponent
  ],
  exports: [
    TransferDetailsComponent
  ]
})
export class TransferDetailsModule { }
