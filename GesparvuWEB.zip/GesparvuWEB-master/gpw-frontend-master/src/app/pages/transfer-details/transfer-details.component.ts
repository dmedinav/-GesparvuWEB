import { Component, OnInit, OnDestroy } from '@angular/core';
import { FormGroup, FormBuilder } from '@angular/forms';
import { Location } from '@angular/common';
import { Router } from '@angular/router';
import Utils from '@utils/utils';
import { DEFAULT_ERROR_MESSAGE_CONTAINER, SUCCESS_TRANSFER_SAVE_CONTAINER } from './../../common/constants/default-image-container-messages';
import { HOME_ROUTE, TRANSFER_SEARCH_ROUTE } from './../../common/constants/routes.constants';
import { TRANSFER_SESSION_STORAGE_KEY, ENROLLMENT_SESSION_STORAGE_KEY, GA_CREATE_TRANSFER_ACTION, GA_CREATE_TRANSFER_LABEL } from '../../common/constants/default.constants';
import { IDataLoaded } from '../../common/interfaces/default.interface';
import { IDefaultImageContainer } from './../../common/interfaces/default.interface';
import { IEnrollmentsByGroupResponse } from 'app/common/interfaces/enrollments.interface';
import { ITransfer } from '../../common/interfaces/transfers.interface';
import { GoogleAnalyticsService } from '@services/google-analytics/google-analytics.service';
import { GroupService } from '@services/group/group.service';
import { ModalService } from '@services/modal/modal.service';
import { TransferService } from './../../services/transfer/transfer.service';

@Component({
  selector: 'app-transfers-details',
  templateUrl: './transfer-details.component.html',
  styleUrls: ['./transfer-details.component.scss']
})

export class TransferDetailsComponent implements OnInit, OnDestroy {

  transferCreationForm: FormGroup;
  transfer: ITransfer;
  enrollment: IEnrollmentsByGroupResponse;
  fullEnrollmentName: string;
  enrollmentRut: string;
  exitWithButton: boolean;
  isCreationCompleted: IDataLoaded;
  isTransferCreated: boolean;
  errorMessage: IDefaultImageContainer;
  groups: [];

  constructor(
    private router: Router,
    private formBuilder: FormBuilder,
    private transferService: TransferService,
    private location: Location,
    private modalService: ModalService,
    public gaService: GoogleAnalyticsService,
    public readonly groupService: GroupService,
  ) {
    this.fullEnrollmentName = '';
    this.enrollmentRut = '';
    this.exitWithButton = false;
    this.isTransferCreated = false;
    this.isCreationCompleted = {
      isLoaded: true,
      hasErrors: false,
    };
    this.errorMessage = DEFAULT_ERROR_MESSAGE_CONTAINER;
    this.groups = [];
  }

  ngOnInit() {
    const transferString = sessionStorage.getItem(TRANSFER_SESSION_STORAGE_KEY);
    const enrollmentString = sessionStorage.getItem(ENROLLMENT_SESSION_STORAGE_KEY);

    if (enrollmentString) {
      this.enrollment = JSON.parse(enrollmentString) as IEnrollmentsByGroupResponse;
      this.enrollmentRut = Utils.formatToRut(this.enrollment.infant.rut + this.enrollment.infant.rutDv);
      this.fullEnrollmentName = [
        this.enrollment.infant.names,
        this.enrollment.infant.fathersLastname,
        this.enrollment.infant.mothersLastname,
      ].join(' ');
    }

    if (transferString) {
      this.transfer = JSON.parse(transferString) as ITransfer;
      this.transferCreationForm = this.formBuilder.group(this.transfer);
    } else {
      this.router.navigateByUrl(`${HOME_ROUTE}/${TRANSFER_SEARCH_ROUTE}`);
    }
  }

  ngOnDestroy(): void {
    if (!this.exitWithButton) {
      sessionStorage.removeItem(TRANSFER_SESSION_STORAGE_KEY);
      sessionStorage.removeItem(ENROLLMENT_SESSION_STORAGE_KEY);
    }
  }

  public goBack() {
    this.exitWithButton = true;
    this.location.back();
  }

  public async createTransfer() {
    if (this.transferCreationForm.valid && !this.isTransferCreated) {
      this.isTransferCreated = true;
      this.isCreationCompleted.isLoaded = false;

      try {
        await this.transferService.createTransfer(this.transferCreationForm.value);
        this.modalService.openModal(SUCCESS_TRANSFER_SAVE_CONTAINER);
        sessionStorage.removeItem(TRANSFER_SESSION_STORAGE_KEY);
        sessionStorage.removeItem(ENROLLMENT_SESSION_STORAGE_KEY);

        // Send google analytics event
        this.gaService.sendInfantManagementEvent(GA_CREATE_TRANSFER_ACTION, GA_CREATE_TRANSFER_LABEL);
      } catch (err) {
        this.isTransferCreated = false;
        this.isCreationCompleted.hasErrors = true;
        this.errorMessage.title = err.errorMessage;
        this.modalService.openModal(this.errorMessage);
      }

      this.isCreationCompleted.isLoaded = true;
    }
  }
}
