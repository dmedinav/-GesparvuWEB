import { AuthService } from './../../services/auth/auth.service';
import { IUserInfo } from './../../common/interfaces/user-login.interface';
import { MatSidenav } from '@angular/material';
import { Component, ViewChild } from '@angular/core';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent {

  @ViewChild('sidenav', { static: false }) sidenav: MatSidenav;
  headerIcon: string;
  oldInnerWidth: number;
  userInfo: IUserInfo;

  constructor(private authService: AuthService) {
    this.oldInnerWidth = innerWidth;
    this.headerIcon = 'clear';
    this.userInfo = this.authService.getUserInfo();
  }

  toggleSidenav() {
    this.headerIcon = this.headerIcon === 'menu' ? 'clear' : 'menu';
    this.sidenav.toggle();
  }

  onResize() {
    if (this.oldInnerWidth !== innerWidth && this.headerIcon === 'menu') {
      this.toggleSidenav();
    }
    this.oldInnerWidth = innerWidth;
  }
}
