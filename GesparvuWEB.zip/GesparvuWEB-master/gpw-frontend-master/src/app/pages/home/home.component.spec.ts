import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MaterialModule } from '../../material.module';
import { TestBed, async, ComponentFixture } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { HomeComponent } from './home.component';
import { GesparvuHeaderModule } from '../../components/gesparvu-header/gesparvu-header.module';
import { SideBarModule } from '../../components/side-bar/side-bar.module';
import { delay } from 'q';
import { HttpClientModule } from '@angular/common/http';

describe('HomeComponent', () => {

  let component: HomeComponent;
  let fixture: ComponentFixture<HomeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        RouterTestingModule,
        GesparvuHeaderModule,
        BrowserAnimationsModule,
        SideBarModule,
        MaterialModule,
        HttpClientModule,
      ],
      declarations: [
        HomeComponent,
      ],
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HomeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should have the gesparvu header', () => {
    const compiled = fixture.debugElement.nativeElement;
    expect(compiled.querySelector('app-gesparvu-header').textContent).toBeTruthy();
  });

  xit('should have the material sidenav and toggle should works', async () => {
    let compiled = fixture.nativeElement;
    let style = getComputedStyle(compiled.querySelector('mat-sidenav')).getPropertyValue('visibility');
    expect(compiled.querySelector('mat-sidenav')).toBeTruthy();
    expect(style).toBe('visible');
    expect(component.headerIcon).toBe('clear');
    component.toggleSidenav();
    fixture.detectChanges();
    await delay(500);
    compiled = fixture.nativeElement;
    style = getComputedStyle(compiled.querySelector('mat-sidenav')).getPropertyValue('visibility');
    expect(style).toBe('hidden');
    expect(component.headerIcon).toBe('menu');
    component.toggleSidenav();
    expect(component.headerIcon).toBe('clear');
  });

  it('should set header icon to menu when is clear', async () => {
    component.headerIcon = 'clear';
    component.toggleSidenav();
    expect(component.headerIcon).toBe('menu');
  });

  it('should call resize function on resize event', () => {
    const resize = spyOn(component, 'onResize').and.callThrough();
    const toggleSidenav = spyOn(component, 'toggleSidenav').and.callThrough();
    dispatchEvent(new Event('resize'));
    expect(resize).toHaveBeenCalled();
    expect(toggleSidenav).toHaveBeenCalledTimes(0);

  });

  it('should call resize function on resize event with toggle on different width', () => {
    const resize = spyOn(component, 'onResize').and.callThrough();
    const toggleSidenav = spyOn(component, 'toggleSidenav').and.callThrough();
    component.oldInnerWidth = 400;
    component.headerIcon = 'menu';
    dispatchEvent(new Event('resize'));
    expect(resize).toHaveBeenCalled();
    expect(toggleSidenav).toHaveBeenCalled();
  });

});
