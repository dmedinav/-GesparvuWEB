import { AuthGuard } from './../../common/guards/auth.guard';
import { CommonAppModule } from './../../common/common.module';
import { SideBarModule } from './../../components/side-bar/side-bar.module';
import { GesparvuHeaderModule } from './../../components/gesparvu-header/gesparvu-header.module';
import {
  DAILY_ATTENDANCE_ROUTE,
  MOVEMENT_SEARCH_ROUTE,
  MOVEMENT_MAIN_ROUTE,
  EXCEPTIONS_ROUTE,
  MONTHLY_ATTENDANCE_ROUTE,
  INFANT_CREATION_SEARCH_ROUTE,
  INFANT_CREATION_DETAILS_ROUTE,
  TRANSFER_SEARCH_ROUTE,
  TRANSFER_MAIN_ROUTE
} from './../../common/constants/routes.constants';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './home.component';
import { NgModule } from '@angular/core';
import { SmallWidhtGuard } from '../../common/guards/small-width.guard';

const routes: Routes = [
  {
    path: '',
    component: HomeComponent,
    canActivate: [AuthGuard],
    children: [
      {
        path: DAILY_ATTENDANCE_ROUTE,
        loadChildren: '../daily-attendance-content/daily-attendance-content.module#DailyAttendanceContentModule',
      },
      {
        canActivate: [SmallWidhtGuard],
        path: MONTHLY_ATTENDANCE_ROUTE,
        loadChildren: '../monthly-attendance/monthly-attendance.module#MonthlyAttendanceModule',
      },
      {
        path: MOVEMENT_SEARCH_ROUTE,
        loadChildren: '../movement-search/movement-search.module#MovementSearchModule'
      },
      {
        path: `${MOVEMENT_MAIN_ROUTE}/:enrollment`,
        loadChildren: '../movement-assignation/movement-assignation.module#MovementAssignationModule'
      },
      {
        path: `${MOVEMENT_MAIN_ROUTE}/:enrollment/details`,
        loadChildren: '../movement-details/movement-details.module#MovementDetailsModule'
      },
      {
        path: TRANSFER_SEARCH_ROUTE,
        loadChildren: '../transfer-search/transfer-search.module#TransferSearchModule'
      },
      {
        path: `${TRANSFER_MAIN_ROUTE}/:enrollment`,
        loadChildren: '../transfer-assignation/transfer-assignation.module#TransferAssignationModule'
      },
      {
        path: `${TRANSFER_MAIN_ROUTE}/:enrollment/details`,
        loadChildren: '../transfer-details/transfer-details.module#TransferDetailsModule'
      },
      {
        canActivate: [SmallWidhtGuard],
        path: EXCEPTIONS_ROUTE,
        loadChildren: '../exceptions/exceptions.module#ExceptionsModule'
      },
      {
        path: INFANT_CREATION_SEARCH_ROUTE,
        loadChildren: '../infant-search/infant-search.module#InfantSearchModule'
      },
      {
        path: INFANT_CREATION_DETAILS_ROUTE,
        loadChildren: '../infant-details/infant-details.module#InfantDetailsModule'
      },
      {
        path: '**',
        redirectTo: DAILY_ATTENDANCE_ROUTE
      }
    ]
  },
];

@NgModule({
  imports: [
    RouterModule.forChild(routes),
    GesparvuHeaderModule,
    SideBarModule,
    CommonAppModule,
  ],
  declarations: [
    HomeComponent
  ],
  exports: [
    HomeComponent
  ]
})
export class HomeModule { }
