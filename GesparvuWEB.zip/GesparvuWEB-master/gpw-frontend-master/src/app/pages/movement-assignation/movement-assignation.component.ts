import Utils from '@utils/utils';
import { Component, OnInit } from '@angular/core';
import { Location } from '@angular/common';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { EnrollmentService } from '@services/enrollment/enrollment.service';
import { ModalService } from '@services/modal/modal.service';
import { MovementService } from '@services/movement/movement.service';
import { IDataLoaded, IDefaultImageContainer } from './../../common/interfaces/default.interface';
import { IEnrollmentsByGroupResponse } from './../../common/interfaces/enrollments.interface';
import { IMovementTypes, IMovement } from '../../common/interfaces/movements.interface';
import {
  DEFAULT_ERROR_MESSAGE_CONTAINER,
  DEFAULT_EMPTY_MESSAGE_CONTAINER,
} from './../../common/constants/default-image-container-messages';
import { HOME_ROUTE, MOVEMENT_MAIN_ROUTE } from 'app/common/constants/routes.constants';
import { MOVEMENT_SESSION_STORAGE_KEY, ENROLLMENT_SESSION_STORAGE_KEY } from 'app/common/constants/default.constants';

@Component({
  selector: 'app-movements-assignation',
  templateUrl: './movement-assignation.component.html',
  styleUrls: ['./movement-assignation.component.scss']
})
export class MovementAssignationComponent implements OnInit {

  movementTypes: IMovementTypes[];
  isDataLoaded: IDataLoaded;
  cautionMessage: IDefaultImageContainer;
  errorMessage: IDefaultImageContainer;
  enrollmendId: string;
  enrollment: IEnrollmentsByGroupResponse;
  movementCreationForm: FormGroup;
  fullEnrollmentName: string;
  enrollmentRut: string;
  movementCreationClicked: boolean;
  maxMovementDate: Date;
  minMovementDate: Date;
  newMovement: IMovement;
  movementInSessionStorage: boolean;
  deleteSessionStorage: boolean;

  constructor(
    private enrollmentService: EnrollmentService,
    private formBuilder: FormBuilder,
    private location: Location,
    private movementService: MovementService,
    private route: ActivatedRoute,
    public readonly modalService: ModalService,
    public router: Router,
  ) {
    this.cautionMessage = DEFAULT_EMPTY_MESSAGE_CONTAINER;
    this.errorMessage = DEFAULT_ERROR_MESSAGE_CONTAINER;
    this.enrollmendId = this.route.snapshot.paramMap.get('enrollment');
    this.isDataLoaded = {
      hasErrors: false,
      isLoaded: false,
    };

    // Set `minMovementDate` to be the first day of the previous month and
    // set `maxMovementDate` to be the last day of the curent month
    const today = new Date();
    this.minMovementDate = new Date(today.getUTCFullYear(), today.getUTCMonth() - 2, 1);
    this.maxMovementDate = new Date(today.getUTCFullYear(), today.getUTCMonth() + 1, 0);

    this.movementCreationClicked = false;
    this.fullEnrollmentName = '';
    this.enrollmentRut = '';
    this.movementTypes = [];
    this.movementInSessionStorage = false;
    this.deleteSessionStorage = true;
  }

  get movement() {
    return this.movementCreationForm.get('movement');
  }

  get retirementDate() {
    return this.movementCreationForm.get('retirementDate');
  }

  ngOnInit() {
    Promise.all([
      this.movementService.getMovementTypes(),
      this.enrollmentService.getEnrollmentById(this.enrollmendId),
    ])
    .then(([movementTypes, enrollment]) => {
      this.movementTypes = movementTypes;

      this.enrollment = enrollment;
      this.fullEnrollmentName = [
        this.enrollment.infant.names,
        this.enrollment.infant.fathersLastname,
        this.enrollment.infant.mothersLastname,
      ].join(' ').trim();
      this.enrollmentRut = Utils.formatToRut(this.enrollment.infant.rut + this.enrollment.infant.rutDv);

      // Set `minMovementDate` to be equal to enrollment's enrollment date
      // if `minMovementDate` is before to it
      const enrollmentDate = new Date(this.enrollment.enrollmentDate);
      if (this.minMovementDate.getTime() < enrollmentDate.setHours(0,0,0,0)) {
        this.minMovementDate = enrollmentDate;
      }

      this.movementCreationForm = this.formBuilder.group({
        enrollment: enrollment.id,
        retirementDate: new FormControl({value: new Date(), disabled: this.movementCreationClicked}, Validators.compose([
            Validators.required,
        ])),
        movement: new FormControl({value: '', disabled: this.movementCreationClicked}, Validators.compose([
          Validators.required,
        ])),
      });

      this.loadFromSessionStorage();
    })
    .catch((err) => {
      if (err.statusCode === 404) {
        this.cautionMessage.title = err.errorMessage;
      } else {
        this.errorMessage.title = err.errorMessage;
        this.modalService.openModal(this.errorMessage);
      }
      this.isDataLoaded.hasErrors = true;
    })
    .finally(() => {
      this.isDataLoaded.isLoaded = true;
    });
  }

  ngOnDestroy() {
    if (this.deleteSessionStorage) {
      sessionStorage.clear();
    }
  }

  public loadFromSessionStorage() {
    const sessionMovement = sessionStorage.getItem(MOVEMENT_SESSION_STORAGE_KEY);

    if (sessionMovement) {
      this.movementInSessionStorage = true;
      this.newMovement = JSON.parse(sessionMovement);
      this.simpleFillForm();
    }
  }

  public simpleFillForm() {
    Object.keys(this.movementCreationForm.controls).forEach(key => {
      this.movementCreationForm.controls[key].setValue(this.newMovement[key]);
    });
  }

  public goBack() {
    this.location.back();
  }

  public async createMovement() {
    if (!this.movementCreationForm.valid) return;

    this.newMovement = this.movementCreationForm.getRawValue();
    this.newMovement.movementDescription = this.movementTypes.find(m => m.id === this.newMovement.movement).description;

    sessionStorage.setItem(MOVEMENT_SESSION_STORAGE_KEY, JSON.stringify(this.newMovement));
    sessionStorage.setItem(ENROLLMENT_SESSION_STORAGE_KEY, JSON.stringify(this.enrollment));

    this.deleteSessionStorage = false;

    this.navigateToDetails();
  }

  public navigateToDetails() {
    this.router.navigateByUrl(`${HOME_ROUTE}/${MOVEMENT_MAIN_ROUTE}/${this.enrollmendId}/details`);
  }

}
