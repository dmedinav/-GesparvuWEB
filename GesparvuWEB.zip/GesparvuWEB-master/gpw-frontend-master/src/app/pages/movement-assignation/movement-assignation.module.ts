import { CommonAppModule } from './../../common/common.module';
import { Routes, RouterModule } from '@angular/router';
import { MovementAssignationComponent } from './movement-assignation.component';
import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { MatGridListModule } from '@angular/material';
import { PrimaryButtonModule } from '../../components/primary-button/primary-button.module';
import { SecondaryButtonModule } from '../../components/secondary-button/secondary-button.module';

const routes: Routes = [
  {
    path: '',
    component: MovementAssignationComponent,
  },
];


@NgModule({
  imports: [
    CommonModule,
    RouterModule.forChild(routes),
    MatGridListModule,
    PrimaryButtonModule,
    SecondaryButtonModule,
    CommonAppModule
  ],
  declarations: [
    MovementAssignationComponent
  ],
  exports: [
    MovementAssignationComponent
  ]
})
export class MovementAssignationModule { }
