import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MovementAssignationComponent } from './movement-assignation.component';
import { DefaultImageContainerModule } from '../../components/default-image-container/default-image-container.module';
import { MaterialModule } from '../../material.module';
import { PrimaryButtonModule } from '../../components/primary-button/primary-button.module';
import { SecondaryButtonModule } from '../../components/secondary-button/secondary-button.module';
import { ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { RouterTestingModule } from '@angular/router/testing';
import { GenericModalComponent } from '../../components/generic-modal/generic-modal.component';
import { BrowserDynamicTestingModule } from '@angular/platform-browser-dynamic/testing';
import { EnrollmentService } from '@services/enrollment/enrollment.service';
import { EnrollmentServiceMock } from '../../mocks/enrollments.mocks';
import { MovementService } from '@services/movement/movement.service';
import { MovementServiceMock } from '../../mocks/movement.mock';
import { BrowserAnimationsModule, NoopAnimationsModule } from '@angular/platform-browser/animations';
import { SUCCESS_MOVEMENT_SAVE_CONTAINER } from '../../common/constants/default-image-container-messages';

describe('MovementAssignationComponent', () => {
  let component: MovementAssignationComponent;
  let fixture: ComponentFixture<MovementAssignationComponent>;

  beforeEach(async (() => {
    TestBed.configureTestingModule({
      declarations: [ MovementAssignationComponent, GenericModalComponent ],
      imports: [
        ReactiveFormsModule,
        MaterialModule,
        DefaultImageContainerModule,
        PrimaryButtonModule,
        SecondaryButtonModule,
        HttpClientModule,
        RouterTestingModule,
        BrowserAnimationsModule,
        NoopAnimationsModule,
      ],
      providers: [
        { provide: EnrollmentService, useClass: EnrollmentServiceMock },
        { provide: MovementService, useClass: MovementServiceMock },
      ],
    })
    .overrideModule(BrowserDynamicTestingModule, { set: { entryComponents: [GenericModalComponent] } })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MovementAssignationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should not create and display a modal', () => {
    // tslint:disable-next-line: no-string-literal
    spyOn(component['movementService'], 'getMovementTypes').and.returnValue(Promise.reject({}));
    const modalSpy = spyOn(component.modalService, 'openModal');
    component.ngOnInit();

    fixture.whenStable().then(async () => {
      expect(modalSpy).toHaveBeenCalled();
      expect(component.isDataLoaded.hasErrors).toBeTruthy();
    });
  });

  it('should not create', () => {
    // tslint:disable-next-line: no-string-literal
    spyOn(component['movementService'], 'getMovementTypes').and.returnValue(Promise.reject( {statusCode: 404 }));
    const modalSpy = spyOn(component.modalService, 'openModal');
    component.ngOnInit();

    fixture.whenStable().then(async () => {
      expect(modalSpy).toHaveBeenCalledTimes(0);
      expect(component.isDataLoaded.hasErrors).toBeTruthy();
    });
  });

  it('should create a movement and display a modal', () => {
    fixture.whenStable().then(async () => {
      const modalSpy = spyOn(component.modalService, 'openModal');
      component.movementCreationForm.setValue({enrollment: 1, movement: 1});
      await component.createMovement({enrollment: 1, movement: 1});
      fixture.detectChanges();
      expect(modalSpy).toHaveBeenCalledWith(SUCCESS_MOVEMENT_SAVE_CONTAINER);
    });
  });

  it('should throw an error when create a movement and display a modal', () => {
    fixture.whenStable().then(async () => {
      const modalSpy = spyOn(component.modalService, 'openModal');
      component.movementCreationForm.setValue({enrollment: 1, movement: 1});
      await component.createMovement(null);
      expect(modalSpy).toHaveBeenCalled();
    });
  });

  it('should not create a movement', () => {
    fixture.whenStable().then(async () => {
      const modalSpy = spyOn(component.modalService, 'openModal');
      await component.createMovement({enrollment: 1, movement: 1});
      expect(modalSpy).toHaveBeenCalledTimes(0);
    });
  });

  it('should go back', () => {
    // tslint:disable-next-line: no-string-literal
    const locationSpy = spyOn(component['location'], 'back');
    component.goBack();
    expect(locationSpy).toHaveBeenCalled();
  });

});
