export interface ISimpleGroup {
  id: number;
  name: string;
}
