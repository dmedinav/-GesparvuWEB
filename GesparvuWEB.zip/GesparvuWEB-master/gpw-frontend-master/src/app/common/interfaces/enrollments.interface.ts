import { ISimpleGroup } from './groups.interface';
import { IAttendanceMonthlyObject } from './attendance.interface';
import { IInfant } from './infant.interface';

export interface IEnrollmentsByGroupResponse {
  attendances?: IAttendanceMonthlyObject[];
  infant: IInfant;
  id: number;
  enrollmentDate: Date;
  retirementDate?: Date;
  group?: ISimpleGroup;
}

export interface IEnrollmentsByTeacherResponse {
  infant: IInfant;
  id: number;
  enrollmentDate: Date;
}

export interface IEnrollmentsResponse {
  enrollments: IEnrollmentsByGroupResponse[];
  attendanceCodes?: any;
  isActiveMonth?: boolean;
}
