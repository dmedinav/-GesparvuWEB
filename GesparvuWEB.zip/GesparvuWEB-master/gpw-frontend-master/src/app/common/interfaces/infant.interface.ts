export interface IInfant {
  id: number;
  names: string;
  fathersLastname: string;
  mothersLastname: string;
  rut: number;
  rutDv: string;
  sexuality?: number;
  birthDate?: Date;
  normalized: boolean;
}

export interface ISexuality {
  id: number;
  description: string;
}

export interface IInfantCreation {
  rut: string;
  names: string;
  fathersLastname: string;
  mothersLastname?: string;
  birthDate?: Date;
  sexuality?: number;
  sexualityName?: string;
  group: number;
  groupName: string;
  isPresent: boolean;
  new: boolean;
  description?: string;
  enrollmentDate: Date;
  normalized?: boolean;
}
