import { IAttendanceMonthlyObject } from './attendance.interface';

export interface IAttendanceMonthlyObject {
  id: number;
  attendance: string|number;
}

export interface IAttendanceUpdateObject {
  attendances: IAttendanceMonthlyObject[];
}

export interface IDailyInfo {
  day: string;
  label: string;
}
