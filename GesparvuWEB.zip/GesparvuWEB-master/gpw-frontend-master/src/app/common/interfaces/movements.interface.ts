export interface IMovementTypes {
  id: number;
  description: string;
}

export interface IMovement {
  enrollment: number;
  movement: number;
  movementDescription: string;
  retirementDate: Date;
}
