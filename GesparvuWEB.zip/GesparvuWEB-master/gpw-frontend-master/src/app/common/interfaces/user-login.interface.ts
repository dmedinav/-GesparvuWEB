export interface IUserLogin {
  username: string;
  password: string;
}

export interface IUserInfo {
  email: string;
  rut: number;
  establishmentName: string;
  teacherName: string;
}
