export interface IDataLoaded {
  isLoaded: boolean;
  hasErrors: boolean;
}

export interface IDefaultErrorResponse {
  statusCode: number;
  errorMessage: string;
  code: number;
  extraData: string;
  path: string;
}

export interface IDefaultSuccessResponse {
  status: string;
}

export interface IDefaultSelection {
  id: number;
  description: string;
}

export interface IDefaultImageContainer {
  title: string;
  subtitle: string;
  iconClass: string;
}

