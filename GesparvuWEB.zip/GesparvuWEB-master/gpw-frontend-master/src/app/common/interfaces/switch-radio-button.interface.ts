export interface ISwitchRadioButton {
  text: string;
  value: number;
  colorClass: string;
}

export interface ISwitchRadioButtonOutput {
  id: string;
  value: string;
}
