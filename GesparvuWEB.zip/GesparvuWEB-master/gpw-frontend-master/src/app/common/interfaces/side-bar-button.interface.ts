export interface ISideBarButton {
  text: string;
  route: string;
  class: string;
  icon: string;
  selectedIcon: string;
  unselectedIcon: string;
}
