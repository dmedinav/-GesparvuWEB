export interface IGoogleAnalyticsEvent {
  action: string;
  category: string;
  label: string;
  value: number;
}
