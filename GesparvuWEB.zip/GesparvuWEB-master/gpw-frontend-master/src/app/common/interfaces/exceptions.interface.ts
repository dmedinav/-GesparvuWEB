export interface IExceptionType {
  id: number;
  description: string;
}

export interface IExceptionRequest {
  description: string;
  exceptionType: number;
  date: string;
  group: number;
}

export interface IExceptionCalendar {
  date: Date;
  description: string;
  isHoliday: boolean;
  irrevocable?: boolean;
}

export interface IExceptionCalendarDayDetails {
  eventClass: string;
  eventDescription: string;
  monthName: string;
  weekDay: string;
  day: number;
}

