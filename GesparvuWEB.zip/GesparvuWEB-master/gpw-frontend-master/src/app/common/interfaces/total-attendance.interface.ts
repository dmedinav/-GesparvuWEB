export interface ITotalAttendance {
  attendance: number;
  noAttendance: number;
  total: number;
}
