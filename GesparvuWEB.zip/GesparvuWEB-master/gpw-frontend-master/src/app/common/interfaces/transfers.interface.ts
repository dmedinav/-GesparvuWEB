export interface ITransfer {
  enrollment: number;
  newGroup: number;
  newGroupName: string;
  transferDate: Date;
  isPresent: boolean;
}
