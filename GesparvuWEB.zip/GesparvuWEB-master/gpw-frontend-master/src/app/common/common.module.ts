import { DefaultImageContainerModule } from './../components/default-image-container/default-image-container.module';
import { ReactiveFormsModule } from '@angular/forms';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MaterialModule } from '../material.module';
import { GenericModalModule } from '../components/generic-modal/generic-modal.module';

@NgModule({
  imports: [
    CommonModule,
    MaterialModule,
    ReactiveFormsModule,
    GenericModalModule,
    DefaultImageContainerModule
  ],
  exports: [
    DefaultImageContainerModule,
    ReactiveFormsModule,
    MaterialModule,
    CommonModule,
  ]
})
export class CommonAppModule {}
