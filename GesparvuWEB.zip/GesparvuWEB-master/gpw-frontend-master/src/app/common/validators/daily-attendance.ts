import { IAttendanceMonthlyObject } from './../interfaces/attendance.interface';
import { IAttendanceCodeTypes } from '../interfaces/attendance-types.interface';
import { AbstractControl } from '@angular/forms';

export const validateDailyAttendance = (attendanceCodes: IAttendanceCodeTypes, today: string) => {
  return (control: AbstractControl) => {
    const attendances = control.value as IAttendanceMonthlyObject[];
    for (const element of attendances) {
      const attendanceValue = element.attendance[today];
      if (attendanceValue !== attendanceCodes.RAD_ATTENDANCE_CODE &&
        attendanceValue !== attendanceCodes.RAD_NO_ATTENDANCE_CODE
      ) {
        return {
          isError: true
        };
      }
    }
    return null;
  };
};
