import { AbstractControl } from '@angular/forms';
import Utils from '../utils/utils';

export function validateRut(c: AbstractControl) {

  if (!c.value) {
    return {
      isError: true
    };
  }
  let rut = Utils.formatToRut(c.value);
  rut = rut.replace(/[.-]/g, '');
  const body = rut.slice(0, -1);
  let checkDigit = rut.slice(-1).toUpperCase();

  if (body.length < 7) {
    return {
      isError: true
    };
  }
  let addition = 0;
  let multiple = 2;
  let index = 0;
  for (let i = 1; i <= body.length; i++) {

    index = multiple * parseInt(rut.charAt(body.length - i), 10);
    addition = addition + index;

    if (multiple < 7) {
      multiple = multiple + 1;
    } else {
      multiple = 2;
    }

  }
  const expectedCheckDigit = 11 - (addition % 11);
  checkDigit = (checkDigit === 'K') ? '10' : checkDigit;
  checkDigit = (checkDigit === '0') ? '11' : checkDigit;

  if (expectedCheckDigit !== parseInt(checkDigit, 10)) {
    return {
      isError: true
    };
  }

  return null;
}
