import { NoAuthGuard } from './no-auth.guard';
import { ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { HOME_ROUTE } from '../constants/routes.constants';

let noAuthGuard: NoAuthGuard = null;
const next: ActivatedRouteSnapshot = null;
const state: RouterStateSnapshot = null;

let isAuthenticatedSpy: jasmine.Spy;
let navigateByUrlSpy: jasmine.Spy;

describe('NoAuthGuard', () => {
  beforeEach(() => {
    const authService = jasmine.createSpyObj('AuthService', ['isAuthenticated']);
    const router = jasmine.createSpyObj('Router', ['navigateByUrl']);
    isAuthenticatedSpy = authService.isAuthenticated;
    navigateByUrlSpy = router.navigateByUrl.and.returnValue();

    noAuthGuard = new NoAuthGuard(authService, router);
  });

  it('should be created', () => {
    expect(noAuthGuard).toBeTruthy();
  });

  it('should return true', () => {
    // tslint:disable-next-line: no-string-literal
    isAuthenticatedSpy.and.returnValue(false);
    expect(noAuthGuard.canActivate(next, state)).toBeTruthy();
  });

  it('should return false and navigateByUrl should be called with login path ', () => {
    // tslint:disable-next-line: no-string-literal
    isAuthenticatedSpy.and.returnValue(true);
    noAuthGuard.canActivate(next, state);

    expect(noAuthGuard.canActivate(next, state)).toBeFalsy();
    expect(navigateByUrlSpy).toHaveBeenCalledWith(`${HOME_ROUTE}`);
  });

});
