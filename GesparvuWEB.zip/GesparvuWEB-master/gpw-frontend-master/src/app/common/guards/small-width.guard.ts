import { HOME_ROUTE } from './../constants/routes.constants';
import { SCREEN_WIDTH } from './../constants/screen-width';
import { Observable } from 'rxjs';
import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class SmallWidhtGuard implements CanActivate {

  constructor(private router: Router) {}

  canActivate(
    next: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): Observable<boolean> | Promise<boolean> | boolean {
      if (innerWidth < SCREEN_WIDTH.DESKTOP) {
        this.router.navigateByUrl(HOME_ROUTE);
        return false;
      }
      return true;
  }
}
