import { AuthGuard } from './auth.guard';
import { ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { LOGIN_ROUTE } from '../constants/routes.constants';

let authGuard: AuthGuard = null;
const next: ActivatedRouteSnapshot = null;
const state: RouterStateSnapshot = null;

let isAuthenticatedSpy: jasmine.Spy;
let navigateByUrlSpy: jasmine.Spy;

describe('AuthGuard', () => {
  beforeEach(() => {
    const authService = jasmine.createSpyObj('AuthService', ['isAuthenticated']);
    const router = jasmine.createSpyObj('Router', ['navigateByUrl']);
    isAuthenticatedSpy = authService.isAuthenticated;
    navigateByUrlSpy = router.navigateByUrl.and.returnValue();

    authGuard = new AuthGuard(authService, router);
  });

  it('should be created', () => {
    expect(authGuard).toBeTruthy();
  });

  it('should return true', () => {
    // tslint:disable-next-line: no-string-literal
    isAuthenticatedSpy.and.returnValue(true);
    expect(authGuard.canActivate(next, state)).toBeTruthy();
  });

  it('should return false and navigateByUrl should be called with login path ', () => {
    // tslint:disable-next-line: no-string-literal
    isAuthenticatedSpy.and.returnValue(false);
    authGuard.canActivate(next, state);

    expect(authGuard.canActivate(next, state)).toBeFalsy();
    expect(navigateByUrlSpy).toHaveBeenCalledWith(`/${LOGIN_ROUTE}`);
  });

});
