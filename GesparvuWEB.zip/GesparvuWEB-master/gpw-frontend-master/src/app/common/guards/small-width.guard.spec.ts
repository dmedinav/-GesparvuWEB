import { SCREEN_WIDTH } from './../constants/screen-width';
import { SmallWidhtGuard } from './small-width.guard';
import { ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { HOME_ROUTE } from '../constants/routes.constants';

let smallWidhtGuard: SmallWidhtGuard = null;
const next: ActivatedRouteSnapshot = null;
const state: RouterStateSnapshot = null;

let navigateByUrlSpy: jasmine.Spy;

describe('SmallWidhtGuard', () => {
  beforeEach(() => {
    const authService = jasmine.createSpyObj('AuthService', ['isAuthenticated']);
    const router = jasmine.createSpyObj('Router', ['navigateByUrl']);
    navigateByUrlSpy = router.navigateByUrl.and.returnValue();
    smallWidhtGuard = new SmallWidhtGuard(router);
  });

  it('should be created', () => {
    expect(smallWidhtGuard).toBeTruthy();
  });

  describe('Normal width', () => {
    it('should return true', () => {
      (window as any).innerWidth = SCREEN_WIDTH.DESKTOP + 100;
      // tslint:disable-next-line: no-string-literal
      expect(smallWidhtGuard.canActivate(next, state)).toBeTruthy();
    });
  });

  describe('Mobile width', () => {
    it('should return false and navigateByUrl should be called with login path ', () => {
      // tslint:disable-next-line: no-string-literal
      (window as any).innerWidth = SCREEN_WIDTH.MOBILE;
      expect(smallWidhtGuard.canActivate(next, state)).toBeFalsy();
      expect(navigateByUrlSpy).toHaveBeenCalledWith(`${HOME_ROUTE}`);
    });
  });




});
