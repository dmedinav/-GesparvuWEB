export const SCREEN_WIDTH = {
  DESKTOP: 1023,
  TABLET: 769,
  MOBILE: 481,
};
