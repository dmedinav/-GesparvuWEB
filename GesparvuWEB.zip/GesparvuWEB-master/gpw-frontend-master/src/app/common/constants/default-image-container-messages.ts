import { IDefaultImageContainer } from '../interfaces/default.interface';

export const EMPTY_ENROLLMENT_LIST_CONTAINER = {
  title: 'Este nivel o grupo no tiene párvulos.',
  subtitle: 'Quizás quieras añadir un párvulo para comenzar.',
  iconClass: 'illu-empty-state',
} as IDefaultImageContainer;

export const EMPTY_GROUP_LIST_CONTAINER = {
  title: 'No tienes grupos asignados.',
  subtitle: 'Quizás quieras comunicarte con la mesa de ayuda.',
  iconClass: 'illu-empty-state',
} as IDefaultImageContainer;

export const EMPTY_ENROLLMENT_SEARCH_CONTAINER = {
  title: 'Párvulo no existente en los registros',
  subtitle: 'Ups! No hemos encontrado a ningún párvulo según tus criterios. Inténtalo nuevamente.',
  iconClass: 'illu-no-found',
} as IDefaultImageContainer;

export const NO_INFANT_SEARCH_CONTAINER = {
  title: 'RUN no existente en los registros',
  subtitle: 'Ups! No hemos encontrado a ningún párvulo según tus criterios. Inténtalo nuevamente.',
  iconClass: 'illu-no-found',
} as IDefaultImageContainer;

export const NOT_WORKING_DAY_CONTAINER = {
  title: 'Este es un día no trabajado.',
  subtitle: 'Quizás quieras intentar con otro día.',
  iconClass: 'illu-empty-state',
}as IDefaultImageContainer;

export const SUCCESS_ATTENDANCE_SAVE_CONTAINER = {
  title: '¡Asistencia guardada exitosamente!',
  subtitle: '',
  iconClass: 'illu-success-save',
} as IDefaultImageContainer;

export const SUCCESS_DEFAULT_SAVE_CONTAINER = {
  title: '¡Cambios guardados exitosamente!',
  subtitle: '',
  iconClass: 'illu-success-save',
} as IDefaultImageContainer;

export const SUCCESS_INFANT_SAVE_CONTAINER = {
  title: '¡Solicitud de ingreso realizada exitosamente!',
  subtitle: '',
  iconClass: 'illu-calendar-success',
} as IDefaultImageContainer;

export const SUCCESS_MOVEMENT_SAVE_CONTAINER = {
  title: '¡Retiro de párvulo realizado exitosamente!',
  subtitle: '',
  iconClass: 'illu-movement-success',
} as IDefaultImageContainer;

export const SUCCESS_TRANSFER_SAVE_CONTAINER = {
  title: '¡Cambio de grupo de párvulo realizado exitosamente!',
  subtitle: '',
  iconClass: 'illu-movement-success',
} as IDefaultImageContainer;

export const DEFAULT_ERROR_MESSAGE_CONTAINER = {
  title: '',
  subtitle: '',
  iconClass: 'illu-no-connection',
} as IDefaultImageContainer;

export const DEFAULT_EMPTY_MESSAGE_CONTAINER = {
  title: '',
  subtitle: '',
  iconClass: 'illu-empty-state',
} as IDefaultImageContainer;
