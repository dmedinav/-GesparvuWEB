export const MONTHS_NAMES = [
  'Enero',
  'Febrero',
  'Marzo',
  'Abril',
  'Mayo',
  'Junio',
  'Julio',
  'Agosto',
  'Septiembre',
  'Octubre',
  'Noviembre',
  'Diciembre'
];

export const DAY_NAMES = [
  'Domingo',
  'Lunes',
  'Martes',
  'Miércoles',
  'Jueves',
  'Viernes',
  'Sábado',
];

export const SHORT_DAY_NAMES = [
  'Dom',
  'Lun',
  'Mar',
  'Mié',
  'Jue',
  'Vie',
  'Sáb',
];

export const ENROLLMENT_COLUMNS = ['index', 'rut', 'names', 'actions'];

export const ENROLLMENT_SEARCH_COLUMNS = ['rut', 'names', 'group', 'actions'];

// tslint:disable-next-line: max-line-length
export const DEFAULT_ERROR_MESSAGE = 'Ha ocurrido un error. Por favor revise su conexión y vuelva a intentarlo más tarde. En caso que el problema persista, contacte a la mesa de ayuda.';

export const DEFAULT_UNAUTHORIZED_ERROR_MESSAGE = 'Su sesión expiró. Por favor, vuelva a iniciar sesión';

export const DEFAULT_EXCEPTION_CALENDAR_CLASS = 'exceptions-date';

export const DEFAULT_HOLIDAY_CALENDAR_CLASS = 'holidays-date';

export const DEFAULT_EVENT_CLASS = 'default-event';

export const DEFAULT_HOLIDAY_EVENT_CLASS = 'holiday-event';

export const DEFAULT_EXCEPTION_EVENT_CLASS = 'exception-event';

export const DEFAULT_EVENT_DESCRIPTION = 'Sin eventos';

export const NO_RUT_INFANT = 'Solicitud de IPE pendiente';

export const INFANT_SESSION_STORAGE_KEY = 'infant';

export const TRANSFER_SESSION_STORAGE_KEY = 'transfer';

export const ENROLLMENT_SESSION_STORAGE_KEY = 'enrollment';

export const MOVEMENT_SESSION_STORAGE_KEY = 'movement';

export const GA_MEASUREMENT_ID = 'UA-144878071-1';

export const GA_ATTENDANCE_MANAGEMENT_CATEGORY = 'attendance_management';

export const GA_INFANT_MANAGEMENT_CATEGORY = 'infant_management';

export const GA_CREATE_ATTENDANCE_ACTION = 'create_attendance';

export const GA_CREATE_EXCEPTION_ACTION = 'create_exception';

export const GA_CREATE_ENROLLMENT_ACTION = 'create_enrollment';

export const GA_CREATE_MOVEMENT_ACTION = 'delete_enrollment';

export const GA_CREATE_TRANSFER_ACTION = 'update_enrollment_group';

export const GA_CREATE_ATTENDANCE_LABEL = 'Guardar asistencia diaria';

export const GA_CREATE_EXCEPTION_LABEL = 'Crear día no trabajado';

export const GA_CREATE_ENROLLMENT_LABEL = 'Solicitar ingreso de párvulo';

export const GA_CREATE_MOVEMENT_LABEL = 'Solicitar retiro de párvulo';

export const GA_CREATE_TRANSFER_LABEL = 'Solicitar cambio de grupo de párvulo';
