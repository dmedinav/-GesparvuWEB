export const EMPTY_DAY_DETAILS = {
  day: 0,
  weekDay: '',
  eventClass: '',
  eventDescription: '',
  monthName: '',
};
