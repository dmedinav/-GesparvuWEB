export const HOME_ROUTE = 'home';

export const LOGIN_ROUTE = 'login';

export const DAILY_ATTENDANCE_ROUTE = 'daily-attendance';

export const MOVEMENT_MAIN_ROUTE = 'movements';

export const MOVEMENT_SEARCH_ROUTE = `${MOVEMENT_MAIN_ROUTE}/search`;

export const TRANSFER_MAIN_ROUTE = 'transfers';

export const TRANSFER_SEARCH_ROUTE = `${TRANSFER_MAIN_ROUTE}/search`;

export const INFANT_CREATION_MAIN_ROUTE = 'infants';

export const INFANT_CREATION_SEARCH_ROUTE = `${INFANT_CREATION_MAIN_ROUTE}/search`;

export const INFANT_CREATION_DETAILS_ROUTE = `${INFANT_CREATION_MAIN_ROUTE}/details`;

export const MONTHLY_ATTENDANCE_ROUTE = 'monthly-attendance';

export const EXCEPTIONS_ROUTE = 'exceptions';

export const SIDE_BAR_ROUTES_BUTTONS = [
    {
      text: 'Asistencia diaria',
      route: `${HOME_ROUTE}/${DAILY_ATTENDANCE_ROUTE}`,
      class: '',
      icon: 'inactive-attendance',
      selectedIcon: 'active-attendance',
      unselectedIcon: 'inactive-attendance',
      removeClass: '',
    },
    {
      text: 'Asistencia mensual',
      route: `${HOME_ROUTE}/${MONTHLY_ATTENDANCE_ROUTE}`,
      class: '',
      icon: 'inactive-month',
      selectedIcon: 'active-month',
      unselectedIcon: 'inactive-month',
      removeClass: 'remove',
    },
    {
      text: 'Retiro o traslado de párvulo',
      route: `${HOME_ROUTE}/${MOVEMENT_SEARCH_ROUTE}`,
      class: '',
      icon: 'inactive-movement',
      selectedIcon: 'active-movement',
      unselectedIcon: 'inactive-movement',
      removeClass: '',
    },
    {
      text: 'Cambio de grupo',
      route: `${HOME_ROUTE}/${TRANSFER_SEARCH_ROUTE}`,
      class: '',
      icon: 'inactive-movement',
      selectedIcon: 'active-transfer',
      unselectedIcon: 'inactive-transfer',
      removeClass: '',
    },
    {
      text: 'Días no trabajados',
      route: `${HOME_ROUTE}/${EXCEPTIONS_ROUTE}`,
      class: '',
      icon: 'inactive-calendar',
      selectedIcon: 'active-calendar',
      unselectedIcon: 'inactive-calendar',
      removeClass: 'remove',
    },
    {
      text: 'Ingresar un párvulo',
      route: `${HOME_ROUTE}/${INFANT_CREATION_SEARCH_ROUTE}`,
      class: '',
      icon: 'inactive-enrollment-creation',
      selectedIcon: 'active-enrollment-creation',
      unselectedIcon: 'inactive-enrollment-creation',
      removeClass: '',
    },
];
