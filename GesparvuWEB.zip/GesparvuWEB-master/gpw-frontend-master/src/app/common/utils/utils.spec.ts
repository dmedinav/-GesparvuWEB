import { TestBed } from '@angular/core/testing';
import Utils from './utils';

describe('Utils', () => {
  beforeEach(() => TestBed.configureTestingModule({
    providers: [
        Utils,
      ]
   }));

  it('should be created', () => {
    const service: Utils = TestBed.get(Utils);
    expect(service).toBeTruthy();
  });

  it('should get days in month', () => {
    expect(Utils.getDaysInMonth(new Date(2019, 6, 0))).toBe(30);
  });

  it('should create an array', () => {
    const size = 5;
    expect(Utils.createArrayByNumber(size).length).toBe(size);
  });

  it('should identify if month and year are the currents', () => {
    const date = new Date();
    expect(Utils.isCurrentMonthAndYear(date.getUTCMonth() + 1, date.getUTCFullYear())).toBeTruthy();
  });

  it('should the key of the specified value', () => {
    const mockObject = {
      key: 'value',
      otherKey: 'newValue'
    };
    expect(Utils.getKeyByValue(mockObject, 'value')).toBe('key');
  });

  it('should return a formatted rut', () => {
    const unformattedRut = '260885979';
    expect(Utils.formatToRut(unformattedRut)).toBe('26.088.597-9');
  });

  it('should return a number if value is starts with 0', () => {
    const unformattedRut = '01';
    expect(Utils.formatToRut(unformattedRut)).toBe('1');
  });

  it('should return a same string if value is not a number', () => {
    const unformattedRut = '';
    expect(Utils.formatToRut(unformattedRut)).toBe('');
  });

  it('should not return a formatted rut if first char is not a number', () => {
    const unformattedRut = 'Alejandro';
    expect(Utils.formatToRutAndName(unformattedRut)).toBe('Alejandro');
  });

  it('should return a formatted rut if first char is not a number', () => {
    const unformattedRut = '260885979';
    expect(Utils.formatToRutAndName(unformattedRut)).toBe('26.088.597-9');
  });

  it('should return a string without accents mark', () => {
    const name = 'María';
    expect(Utils.removeAccentsOfString(name)).toBe('Maria');
  });

  it('should return 28 days in february 2019 with 1 day as friday', () => {
    const monthlyInformation = Utils.fillArrayWithMonthDays(2, 2019);
    expect(monthlyInformation.length).toBe(28);
    expect(monthlyInformation[0].label).toBe('Vie');
  });

});
