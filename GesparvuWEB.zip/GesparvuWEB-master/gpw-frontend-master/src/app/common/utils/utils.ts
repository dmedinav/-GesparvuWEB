import { SHORT_DAY_NAMES } from './../constants/default.constants';
import { IDailyInfo } from '../../common/interfaces/attendance.interface';
import { AbstractControl } from '@angular/forms';

export default class Utils {
  static getDaysInMonth(date: Date) {
    return new Date(date.getUTCFullYear(), date.getUTCMonth() + 1, 0).getDate();
  }

  static createArrayByNumber(count: number) {
    return Array(count)
      .fill(0)
      .map((x, i) => i);
  }

  static isCurrentMonthAndYear(month: number, year: number) {
    const current = new Date();
    return (
      year === current.getUTCFullYear() && month === current.getUTCMonth() + 1
    );
  }

  static getKeyByValue(object: object, value: any) {
    return Object.keys(object).find(key => object[key] === value);
  }

  static formatToRut(value: string) {
    const currentValue = value.replace(/^0+/, '').trim();
    if (currentValue !== '' && currentValue.length > 1) {
      const noDots = currentValue.replace(/\./g, '');
      const cleanValueNumber = noDots.replace(/-/g, '');
      const cleanValue = cleanValueNumber.toString();
      const beginning = cleanValue.substring(0, cleanValue.length - 1);
      let letra = '';
      let rut = '';
      let j = 1;
      for (let i = beginning.length - 1; i >= 0; i--) {
        letra = beginning.charAt(i);
        rut = letra + rut;
        if (j % 3 === 0 && j <= beginning.length - 1) {
          rut = '.' + rut;
        }
        j++;
      }
      const checkDigit = cleanValue.substring(cleanValue.length - 1);
      rut = rut + '-' + checkDigit;
      return rut;
    } else {
      if (isNaN(parseInt(currentValue, 10))) {
        return '';
      }
      return currentValue;
    }
  }

  static formatToRutAndName(value: string) {
    const cleanedValue = value.trim();

    if ((!cleanedValue || isNaN(parseInt(cleanedValue[0], 10))) && cleanedValue[0] !== '-') {
      return value;
    }
    return this.formatToRut(value);
  }

  static compareDates(firstDate: Date, secondDate: Date) {
    return firstDate.getUTCDate() === secondDate.getUTCDate() &&
      firstDate.getUTCMonth() === secondDate.getUTCMonth() &&
      firstDate.getUTCFullYear() === secondDate.getUTCFullYear();
  }

  static disableFields(controls: AbstractControl[]) {
    for (const control of controls) {
      control.disable();
    }
  }

  static fillArrayWithMonthDays(month: number, year: number) {
    const days = new Date(year, month, 0).getDate();
    const daysInMonth = Array.from({length: days}, (v, k) => String(k + 1));
    const monthlyInformation: IDailyInfo[] = [];
    daysInMonth.forEach(day => {
      const dayLabel = new Date(year, month - 1, parseInt(day, 10));
      monthlyInformation.push({
        day,
        label: SHORT_DAY_NAMES[dayLabel.getUTCDay()],
      });
    });
    return monthlyInformation;
  }

  static removeAccentsOfString(text: string) {
    return text.normalize('NFD').replace(/[\u0300-\u036f]/g, '');
  }

}
