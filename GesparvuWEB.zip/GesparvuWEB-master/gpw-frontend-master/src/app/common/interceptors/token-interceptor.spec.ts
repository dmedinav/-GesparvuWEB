import { DEFAULT_UNAUTHORIZED_ERROR_MESSAGE, DEFAULT_ERROR_MESSAGE } from './../constants/default.constants';
import { async } from '@angular/core/testing';
import { AuthService } from './../../services/auth/auth.service';
import { TokenInterceptor } from './token-interceptor';
import { HttpHandler, HttpRequest } from '@angular/common/http';
import { of, throwError } from 'rxjs';

let authService = null;
let interceptorProvider: TokenInterceptor = null;
let handler: HttpHandler = null;
let http = null;
let router = null;

describe('TokenInterceptor', () => {

  const token = 'tokenTest';
  beforeEach(() => {
    http = jasmine.createSpyObj('http', ['get', 'post', 'put', 'delete', 'update', 'patch']);
    router = jasmine.createSpyObj('router', ['navigateByUrl']);
    authService = new AuthService(http);
    interceptorProvider = new TokenInterceptor(authService, router);
    handler = jasmine.createSpyObj('HttpHandler', ['handle']);
  });

  it('should be created', () => {
    expect(interceptorProvider).toBeTruthy();
  });

  it('should set the token in request', async(() => {
    let request = new HttpRequest('GET', 'url');
    const handle = handler.handle as jasmine.Spy;
    handle.and.callFake(() => of({}));
    const getTokenSpy = spyOn(authService as any, 'getToken').and.returnValue(token);
    interceptorProvider.intercept(request, handler);
    request = request.clone({
      setHeaders: {
        Authorization: `Bearer ${token}`,
      }
    });
    expect(getTokenSpy).toHaveBeenCalledTimes(1);
    expect(handle).toHaveBeenCalledWith(request);
  }));

  it('should catch errors and signOut should be called with error 401', async(() => {
    let request = new HttpRequest('GET', 'url');
    const handle = handler.handle as jasmine.Spy;
    const error = { status: 401, error: { errorMessage: 'Test', statusCode: 401 } };
    handle.and.callFake(() => throwError(error));
    spyOn(authService as any, 'getToken').and.returnValue(token);
    const signOut = spyOn(authService as any, 'signOut').and.callFake(() => of({}));
    const result = interceptorProvider.intercept(request, handler);
    request = request.clone({
      setHeaders: {
        Authorization: `Bearer ${token}`,
      }
    });
    result.subscribe(
      () => { },
      (res) => {
        expect(res.error.errorMessage).toBe('Test');
        expect(signOut).toHaveBeenCalledTimes(1);
        expect(handle).toHaveBeenCalledWith(request);
      }
    );
  }));

  it('should catch errors and signOut should be called with error 401 and Error in response', async(() => {
    let request = new HttpRequest('GET', 'url');
    const handle = handler.handle as jasmine.Spy;
    const error = { status: 401, error: '{ "errorMessage": "Error", "statusCode": 401 }' };
    handle.and.callFake(() => throwError(error));
    spyOn(authService as any, 'getToken').and.returnValue(token);
    const signOut = spyOn(authService as any, 'signOut').and.callFake(() => of({}));
    const result = interceptorProvider.intercept(request, handler);
    request = request.clone({
      setHeaders: {
        Authorization: `Bearer ${token}`,
      }
    });
    result.subscribe(
      () => { },
      (res) => {
        expect(res.error.errorMessage).toBe('Error');
        expect(signOut).toHaveBeenCalledTimes(1);
        expect(handle).toHaveBeenCalledWith(request);
      }
    );
  }));

  it('should catch errors and signOut should be called with error 401 and default unauthorized message in response', async(() => {
    let request = new HttpRequest('GET', 'url');
    const handle = handler.handle as jasmine.Spy;
    const error = { status: 401, error: '{ "statusCode": 401 }' };
    handle.and.callFake(() => throwError(error));
    spyOn(authService as any, 'getToken').and.returnValue(token);
    const signOut = spyOn(authService as any, 'signOut').and.callFake(() => of({}));
    const result = interceptorProvider.intercept(request, handler);
    request = request.clone({
      setHeaders: {
        Authorization: `Bearer ${token}`,
      }
    });
    result.subscribe(
      () => { },
      (res) => {
        expect(res.error.errorMessage).toBe(DEFAULT_UNAUTHORIZED_ERROR_MESSAGE);
        expect(signOut).toHaveBeenCalledTimes(1);
        expect(handle).toHaveBeenCalledWith(request);
      }
    );
  }));

  it('should catch errors and signOut should be called with error 401 and default error message in response', async(() => {
    let request = new HttpRequest('GET', 'url');
    const handle = handler.handle as jasmine.Spy;
    const error = { status: 401 };
    handle.and.callFake(() => throwError(error));
    spyOn(authService as any, 'getToken').and.returnValue(token);
    const signOut = spyOn(authService as any, 'signOut').and.callFake(() => of({}));
    const result = interceptorProvider.intercept(request, handler);
    request = request.clone({
      setHeaders: {
        Authorization: `Bearer ${token}`,
      }
    });
    result.subscribe(
      () => { },
      (res) => {
        expect(res.error.errorMessage).toBe(DEFAULT_ERROR_MESSAGE);
        expect(signOut).toHaveBeenCalledTimes(1);
        expect(handle).toHaveBeenCalledWith(request);
      }
    );
  }));

  it('should catch errors and signOut should not be called with error different from 400', async(() => {
    let request = new HttpRequest('GET', 'url');
    const handle = handler.handle as jasmine.Spy;
    const error = { status: 400, error: { errorMessage: 'Test', statusCode: 400 } };
    handle.and.callFake(() => throwError(error));
    spyOn(authService as any, 'getToken').and.returnValue(token);
    const signOut = spyOn(authService as any, 'signOut').and.callFake(() => of({}));
    const result = interceptorProvider.intercept(request, handler);
    request = request.clone({
      setHeaders: {
        Authorization: `Bearer ${token}`,
      }
    });
    result.subscribe(
      () => { },
      () => {
        expect(signOut).toHaveBeenCalledTimes(0);
        expect(handle).toHaveBeenCalledWith(request);
      }
    );
  }));

  it('should catch errors and signOut should not be called with error different from 400 and errorMessage should be default', async(() => {
    let request = new HttpRequest('GET', 'url');
    const handle = handler.handle as jasmine.Spy;
    const error = { status: 400, error: { statusCode: 400 } };
    handle.and.callFake(() => throwError(error));
    spyOn(authService as any, 'getToken').and.returnValue(token);
    const signOut = spyOn(authService as any, 'signOut').and.callFake(() => of({}));
    const result = interceptorProvider.intercept(request, handler);
    request = request.clone({
      setHeaders: {
        Authorization: `Bearer ${token}`,
      }
    });
    result.subscribe(
      () => { },
      (res) => {
        expect(res.error.errorMessage).toBe(DEFAULT_ERROR_MESSAGE);
        expect(signOut).toHaveBeenCalledTimes(0);
        expect(handle).toHaveBeenCalledWith(request);
      }
    );
  }));

});
