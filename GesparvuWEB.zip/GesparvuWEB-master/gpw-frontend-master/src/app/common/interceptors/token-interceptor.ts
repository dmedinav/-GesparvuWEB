import { DEFAULT_ERROR_MESSAGE } from '../../common/constants/default.constants';
import { DEFAULT_UNAUTHORIZED_ERROR_MESSAGE } from './../constants/default.constants';
import { LOGIN_ROUTE } from './../constants/routes.constants';
import { Observable, throwError } from 'rxjs';
import { Injectable } from '@angular/core';
import {
  HttpRequest,
  HttpHandler,
  HttpEvent,
  HttpInterceptor,
} from '@angular/common/http';
import { catchError } from 'rxjs/operators';
import { AuthService } from '../../services/auth/auth.service';
import { Router } from '@angular/router';

@Injectable()
export class TokenInterceptor implements HttpInterceptor {

  constructor(public authService: AuthService, public router: Router) { }

  intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    request = request.clone({
      setHeaders: {
        Authorization: `Bearer ${this.authService.getToken()}`
      }
    });
    return next.handle(request).pipe(
      catchError((err) => {
        err.error = err.error ?
          (typeof (err.error) !== 'object' ? JSON.parse(err.error) : err.error) :
          { errorMessage: DEFAULT_ERROR_MESSAGE };
        if (err.status === 401) {
          err.error.errorMessage = !err.error.errorMessage || typeof (err.error.errorMessage) !== 'string' ?
            DEFAULT_UNAUTHORIZED_ERROR_MESSAGE : err.error.errorMessage;
          this.authService.signOut();
          this.router.navigateByUrl(LOGIN_ROUTE);
        } else {
          err.error.errorMessage = !err.error.errorMessage || typeof (err.error.errorMessage) !== 'string' ?
            DEFAULT_ERROR_MESSAGE : err.error.errorMessage;
        }
        console.log('Error: ', err.error);
        return throwError(err);
      })
    );
  }
}
