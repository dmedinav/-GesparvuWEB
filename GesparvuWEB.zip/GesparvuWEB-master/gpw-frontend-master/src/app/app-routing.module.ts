import { LOGIN_ROUTE, HOME_ROUTE } from './common/constants/routes.constants';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

const routes: Routes = [
  {
    path: LOGIN_ROUTE,
    loadChildren: './pages/login/login.module#LoginModule',
  },
  {
    path: HOME_ROUTE,
    loadChildren: './pages/home/home.module#HomeModule',
  },
  {
    path: '**',
    redirectTo: LOGIN_ROUTE
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
