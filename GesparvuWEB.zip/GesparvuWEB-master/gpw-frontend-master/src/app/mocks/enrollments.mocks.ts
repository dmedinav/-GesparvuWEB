import { IEnrollmentsByGroupResponse, IEnrollmentsResponse } from '../common/interfaces/enrollments.interface';
import { FormBuilder } from '@angular/forms';
import { IAttendanceCodeTypes } from '../common/interfaces/attendance-types.interface';

export const enrollmentByGroupAndHalfDateQueryMock = {
  year: '2019',
  month: '1'
};

export const enrollmentByGroupAndCompleteDateQueryMock = {
  year: '2019',
  month: '1',
  day: '1'
};

export const enrollmentsMock: Array<IEnrollmentsByGroupResponse> = [{
  attendances: [{
    attendance: '{"1":1,"2":99,"3":0,"4":2}',
    id: 1
  }],
  enrollmentDate: null,
  id: 1,
  infant: {
    id: 1,
    rut: 11111111,
    rutDv: '1',
    fathersLastname: '',
    mothersLastname: '',
    names: '',
    normalized: true
  }
}];

export const enrollmentsWithGroupMock: Array<IEnrollmentsByGroupResponse> = [{
  attendances: [{
    attendance: '{"1":1,"2":99,"3":0,"4":2}',
    id: 1
  }],
  enrollmentDate: null,
  id: 1,
  infant: {
    id: 1,
    rut: 11111111,
    rutDv: '1',
    fathersLastname: '',
    mothersLastname: '',
    names: '',
    normalized: true
  },
  group: {
    id: 254,
    name: 'A',
  },
}];

const formBuilder = new FormBuilder();

export const attendanceFormMock = formBuilder.group({
  attendances: formBuilder.array([])
});

export const enrollmentByGroupAndDateMock = {
  id: 1,
  attendances: [
    {id: 1, attendance: 1},
  ],
  infant: {id: 1, names: 'names', fathersLastname: '', mothersLastname: '', rut: 11111111, rutDv: '1' },
  enrollmentDate: new Date(),
} as IEnrollmentsByGroupResponse;

export const enrollmentByGroupAndMonthMock = {
  id: 1,
  attendances: [
    {id: 1, attendance:
      // tslint:disable:quotemark
      // tslint:disable-next-line:max-line-length
      "{\"1\":1,\"2\":2,\"3\":-1,\"4\":-1,\"5\":1,\"6\":1,\"7\":-1,\"8\":2,\"9\":-1,\"10\":-1,\"11\":-1,\"12\":0,\"13\":-1,\"14\":1,\"15\":0,\"16\":0,\"17\":-1,\"18\":-1,\"19\":0,\"20\":0,\"21\":2,\"22\":0,\"23\":0,\"24\":-1,\"25\":-1,\"26\":0,\"27\":0,\"28\":0,\"29\":0,\"30\":2,\"31\":-1}",
    }],
  infant: {id: 1, names: 'names', fathersLastname: '', mothersLastname: '', rut: 11111111, rutDv: '1' },
  enrollmentDate: new Date(),
  retirementDate: new Date(2019, 2, 10),
} as IEnrollmentsByGroupResponse;


export const secondEnrollmentByGroupAndDateMock = {
  id: 2,
  attendances: [
    {id: 2, attendance: 0},
  ],
  infant: {id: 2, names: 'names', fathersLastname: '', mothersLastname: '', rut: 11111111, rutDv: '1' },
  enrollmentDate: new Date(),
} as IEnrollmentsByGroupResponse;


export const attendanceCodesMock = {
  RAD_DEFAULT_CODE: 0,
  RAD_ATTENDANCE_CODE: 1,
  RAD_NO_ATTENDANCE_CODE: 2,
  RAD_HOLIDAY_CODE: -1,
  RAD_NO_ENROLLMENT_CODE: -3,
  RAD_INVALID_DAY_CODE: 99
} as IAttendanceCodeTypes;


export class EnrollmentServiceMock {

  public async getEnrollmentByGroupId() {
    return await Promise.resolve([]);
  }

  public async getEnrollmentById() {
    return await Promise.resolve(enrollmentsWithGroupMock[0]);
  }

  public async getEnrollmentByGroupIdAndDate() {
    return await Promise.resolve([]);
  }

  public async getEnrollmentsByGroupIdAndCompleteDate(group: number, year: number, month: number, day: number) {
    if (group == null) {
      return Promise.reject({});
    }
    return await Promise.resolve({
      isActiveMonth: true,
      attendanceCodes: {
        RAD_DEFAULT_CODE: 0,
        RAD_ATTENDANCE_CODE: 1,
        RAD_NO_ATTENDANCE_CODE: 2,
        RAD_HOLIDAY_CODE: -1,
        RAD_NO_ENROLLMENT_CODE: -3,
        RAD_INVALID_DAY_CODE: 99
      } as IAttendanceCodeTypes,
      enrollments: [enrollmentByGroupAndDateMock, secondEnrollmentByGroupAndDateMock],
    } as IEnrollmentsResponse );
  }

  public async getEnrollmentsByGroupIdAndHalfDate(group: number, year: number, month: number) {
    return Promise.resolve({
      isActiveMonth: true,
      attendanceCodes: attendanceCodesMock,
      enrollments: [enrollmentByGroupAndDateMock, secondEnrollmentByGroupAndDateMock],
    } as IEnrollmentsResponse );
  }

  public async getEnrollmentsByFilter(filter) {
    if (filter === 'error') {
      return await Promise.reject({});
    } else if (filter === 'empty') {
      return await Promise.resolve({enrollments: []});
    } else {
      return await Promise.resolve({enrollments: enrollmentsWithGroupMock});
    }
  }
}
