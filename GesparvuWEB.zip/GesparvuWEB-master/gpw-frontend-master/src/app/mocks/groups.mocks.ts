export const groupsMock = [
  {
    name: 'A',
    id: 254
  },
  {
    name: 'B',
    id: 255
  }
];

export class GroupServiceMock {

  public async getGroupsByTeacher() {
    return await Promise.resolve(groupsMock);
  }
}
export class GroupServiceEmptyMock {

  public async getGroupsByTeacher() {
    return await Promise.resolve([]);
  }
}
export class GroupServiceRejectMock {

  public async getGroupsByTeacher() {
    return await Promise.reject({ errorMessage: 'Error' });
  }
}
