import { IExceptionCalendar } from './../common/interfaces/exceptions.interface';

export const calendarInformationMock = [
  {
    description: 'Description Test',
    date: new Date('2019-01-01T00:00:00'),
    isHoliday: false,
    irrevocable: false
  },
  {
    description: 'Description Test',
    date: new Date('2019-01-02T00:00:00'),
    isHoliday: true,
    irrevocable: true,
  }
] as IExceptionCalendar[];

export const firsDayDetailsMocks = {
  day: 1,
  weekDay: 'Martes',
  eventClass: 'exception-event',
  eventDescription: 'Description Test',
  monthName: 'Enero'
};
