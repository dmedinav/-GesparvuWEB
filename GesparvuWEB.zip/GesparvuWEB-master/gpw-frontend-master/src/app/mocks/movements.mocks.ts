import { IMovement } from '../common/interfaces/movements.interface';

export const movementPostMock = {
  movement: 1,
  enrollment: 2
} as IMovement;

