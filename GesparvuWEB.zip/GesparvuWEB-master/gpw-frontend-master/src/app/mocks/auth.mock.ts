import { IUserLogin } from '../common/interfaces/user-login.interface';
export class AuthServiceMock {
  public async signIn() {
    return await Promise.resolve({});
  }
}

export const userLoginMock = {
  username: 'username',
  password: 'password',
} as IUserLogin;
