export class SexualitiesServiceMock {
    public async getSexualities() {
      return await Promise.resolve({});
    }
}
