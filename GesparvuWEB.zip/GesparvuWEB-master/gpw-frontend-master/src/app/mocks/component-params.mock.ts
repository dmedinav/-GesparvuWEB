import { ISwitchRadioButtonOutput, ISwitchRadioButton } from '../common/interfaces/switch-radio-button.interface';
import { IDefaultImageContainer } from '../common/interfaces/default.interface';

export const switchRadioButtonOutputMockAttendance: ISwitchRadioButtonOutput = { id: '1', value: '1' };
export const switchRadioButtonOutputMockNoAttendance: ISwitchRadioButtonOutput = { id: '1', value: '2' };
export const switchRadioButtonOutputMockError: ISwitchRadioButtonOutput = { id: 'switchName', value: '1' };

export const switchRadioButtonMock: ISwitchRadioButton = { colorClass: 'warning', text: 'text', value: 1 };

export const defaultImageContainerMock: IDefaultImageContainer = {
  title: 'Este es un día no trabajado.',
  subtitle: 'Quizás quieras intentar con otro día.',
  iconClass: 'illu-empty-state',
};
