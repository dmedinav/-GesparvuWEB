import { IAttendanceUpdateObject } from './../common/interfaces/attendance.interface';

export const attendancePostMock = {
  attendances: [
    {
      id: 1,
      attendance: '{"1": 1}'
    }
  ]
} as IAttendanceUpdateObject;

export class AttendanceServiceMock {

  public async updateAttendanceObject(attendance) {
    if (attendance !== undefined) {
      return await Promise.resolve([]);
    } else {
      return await Promise.reject([]);
    }
  }

  public async getExcelFile() {
    return await Promise.resolve([]);
  }
}

export const attendanceCodeTypesMock = {
  RAD_DEFAULT_CODE: 0,
  RAD_ATTENDANCE_CODE: 1,
  RAD_NO_ATTENDANCE_CODE: 2,
  RAD_HOLIDAY_CODE: -1,
  RAD_NO_ENROLLMENT_CODE: -3,
  RAD_INVALID_DAY_CODE: 99,
};
