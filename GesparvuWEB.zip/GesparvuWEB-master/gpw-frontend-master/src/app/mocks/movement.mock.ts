import { IMovement } from '../common/interfaces/movements.interface';

export class MovementServiceMock {

    public async getMovementTypes() {
      return await Promise.resolve([]);
    }

    public async createMovement(movement: IMovement) {
      if (movement === null) {
        return await Promise.reject({});
      }
      return await Promise.resolve({});
    }
}
