import { NavigationEnd, NavigationStart } from '@angular/router';
import { Observable } from 'rxjs';
import { HOME_ROUTE } from './../common/constants/routes.constants';
import { ISideBarButton } from '../common/interfaces/side-bar-button.interface';
import { DAILY_ATTENDANCE_ROUTE } from '../common/constants/routes.constants';

export class RouterMovementsMock {
  public ns = new NavigationStart(0, 'http://localhost:4200/' + HOME_ROUTE);
  public ne = new NavigationEnd(0, 'http://localhost:4200/' + HOME_ROUTE, '/' + DAILY_ATTENDANCE_ROUTE);
  public events = new Observable(observer => {
    observer.next(this.ns);
    observer.next(this.ne);
    observer.complete();
  });
  public url = `${HOME_ROUTE}/${DAILY_ATTENDANCE_ROUTE}`;
  public navigateByUrl(route: string) { }
  public navigate(route: string) { }
}

export const sideBarButtonMock = {
  text: 'string',
  route: DAILY_ATTENDANCE_ROUTE,
  class: 'string',
  icon: 'string',
  selectedIcon: 'string',
  unselectedIcon: 'string',
} as ISideBarButton;
