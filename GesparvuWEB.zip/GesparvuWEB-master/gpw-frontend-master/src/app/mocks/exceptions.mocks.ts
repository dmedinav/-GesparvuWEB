import { calendarInformationMock } from './calendar.mock';
import { IExceptionRequest } from '../common/interfaces/exceptions.interface';


export const exceptionPostMock = {
  description: 'Description Test',
  exceptionType: 1,
  date: '2019-01-01T00:00:00',
  group: 1,
} as IExceptionRequest;

export const exceptionTypes = [
  {
    id: 1,
    description: 'Tipo 1'
  },
  {
    id: 2,
    description: 'Tipo 2'
  },
];

export class ExceptionServiceMock {

  public async getAllExceptionTypes() {
    return await Promise.resolve(exceptionTypes);
  }

  public async createException() {
    return await Promise.resolve([]);
  }

  public async getCalendarInformation() {
    return await Promise.resolve(calendarInformationMock);
  }
}

