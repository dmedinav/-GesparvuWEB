import { IInfantCreation, IInfant } from './../common/interfaces/infant.interface';
import { ENROLLMENT_NOT_FOUND } from '../common/constants/response-codes.constants';

export const simpleInfantMock = {
   fathersLastname: 'father',
   mothersLastname: 'mother',
   names: 'names',
   birthDate: new Date('2019-01-01T00:00:00'),
   enrollmentDate: new Date('2019-01-01T00:00:00'),
   rut: 11111111,
   rutDv: '1',
   id: 1,
   sexuality: 1,
   normalized: true,
} as IInfant;

export const infantBaseMock = {
   fathersLastname: 'father',
   mothersLastname: 'mother',
   names: 'names',
   birthDate: new Date('2019-01-01T00:00:00'),
   enrollmentDate: new Date('2019-01-01T00:00:00'),
   sexuality: 1,
   sexualityName: 'Femenino',
   description: '',
   group: 1,
   groupName: 'Test group',
   isPresent: true,
   new: true,
} as IInfantCreation;

export const infantWithRutMock = {
   ...infantBaseMock,
   new: true,
   rut: '1111111-1',
} as IInfantCreation;

export const infantPostMock = {
   ...infantBaseMock,
   rut: '1111111-1',
} as IInfantCreation;

export const infantNotNewMock = {
   ...infantBaseMock,
   new: false,
   rut: '1111111-1',
} as IInfantCreation;

export class InfantServiceMock {

   public async getSimInfantByRut(rut?: string) {
      if (rut === '66666666-6') {
         return await Promise.reject({});
      }
      if (rut === '77777777-7') {
         return await Promise.reject({code: ENROLLMENT_NOT_FOUND});
      }
      return await Promise.resolve({});
   }

   public async createInfant() {
      return await Promise.resolve([]);
   }

}
