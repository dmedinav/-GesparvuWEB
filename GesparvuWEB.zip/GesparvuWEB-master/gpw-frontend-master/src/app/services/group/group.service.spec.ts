import { DEFAULT_ERROR_MESSAGE } from '../../common/constants/default.constants';
import { GroupService } from './group.service';
import { environment } from '@env/environment';
import { throwError, of } from 'rxjs';

let http = null;
let groupService: GroupService = null;
let getSpy: jasmine.Spy;

describe('GroupService', () => {
  beforeEach(() => {
    http = jasmine.createSpyObj('http', ['get', 'post', 'put', 'delete', 'update', 'patch']);
    getSpy = http.get;
    groupService = new GroupService(http);
  });

  it('should be created', () => {
    expect(groupService).toBeTruthy();
  });

  describe('getGroupsByTeacher tests', () => {

    it('should catch exceptions with no name error', () => {
    const serviceUrl = environment.JUNJI_RAD_API_URL + '/groups';
    getSpy.and.throwError('Error').and.callFake(() => throwError({error: { errorMessage: 'Error' } }));
    groupService.getGroupsByTeacher().then(
        () => { },
        (res) => {
            expect(res.errorMessage).toBe('Error');
            expect(getSpy).toHaveBeenCalledWith(serviceUrl);
        });
    });

    it('should return promise with request', async () => {
      const serviceUrl = environment.JUNJI_RAD_API_URL + '/groups';
      getSpy.and.callFake(() => of({}));
      const result = await groupService.getGroupsByTeacher();
      expect(result).toBeDefined();
      expect(getSpy).toHaveBeenCalledWith(serviceUrl);
    });

  });

});
