import { IDefaultErrorResponse } from '../../common/interfaces/default.interface';
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from '@env/environment';
import { ISimpleGroup } from '../../common/interfaces/groups.interface';

@Injectable({
  providedIn: 'root'
})
export class GroupService {

  constructor(private http: HttpClient) { }

  public async getGroupsByTeacher(): Promise<ISimpleGroup[]> {
    const url = environment.JUNJI_RAD_API_URL + '/groups';
    return this.http.get(url).toPromise()
      .then((res) => res as ISimpleGroup[])
      .catch((err) => { throw err.error as IDefaultErrorResponse; });
  }

}
