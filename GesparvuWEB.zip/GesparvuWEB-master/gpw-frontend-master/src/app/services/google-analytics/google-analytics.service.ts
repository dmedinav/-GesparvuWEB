import { Injectable } from '@angular/core';
import { GA_MEASUREMENT_ID, GA_ATTENDANCE_MANAGEMENT_CATEGORY, GA_INFANT_MANAGEMENT_CATEGORY } from 'app/common/constants/default.constants';
import { IGoogleAnalyticsEvent } from 'app/common/interfaces/google-analytics.interface';

@Injectable({
  providedIn: 'root'
})
export class GoogleAnalyticsService {

  public sendPageview(pagePath: string) {
    (<any>window).gtag('config', GA_MEASUREMENT_ID, {'page_path': pagePath});
  }

  public sendEvent(event: IGoogleAnalyticsEvent) {
    (<any>window).gtag('event', event.action, {
      'event_category': event.category,
      'event_label': event.label,
      'value': event.value
    });
  }

  public sendAttendanceManagementEvent(action: string, label: string) {
    this.sendEvent({
      action,
      category: GA_ATTENDANCE_MANAGEMENT_CATEGORY,
      label,
      value: 1
    });
  }

  public sendInfantManagementEvent(action: string, label: string) {
    this.sendEvent({
      action,
      category: GA_INFANT_MANAGEMENT_CATEGORY,
      label,
      value: 1
    });
  }
}
