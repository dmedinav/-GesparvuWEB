import { IUserLogin } from './../../common/interfaces/user-login.interface';
import { IDefaultErrorResponse } from '../../common/interfaces/default.interface';
import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { environment } from '@env/environment';
import * as jwt_decode from 'jwt-decode';
import Utils from '../../common/utils/utils';

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  postHeaders: HttpHeaders;

  constructor(private http: HttpClient) {
    this.postHeaders = new HttpHeaders({
      'Content-Type':  'application/json',
    });
  }

  public decodeTokenAsString(token: string): string {
    try {
      return JSON.stringify(jwt_decode(token));
    } catch (err) {
      return null;
    }
  }

  public setUserInfo() {
    const token = this.getToken();
    const userInfo = this.decodeTokenAsString(token);
    localStorage.setItem('userInfo', userInfo);
  }

  public setToken(token: string): void {
    localStorage.setItem('token', token);
  }

  public getToken(): string {
    return localStorage.getItem('token');
  }

  public getUserInfo() {
    return JSON.parse(localStorage.getItem('userInfo'));
  }

  public isAuthenticated(): boolean {
    return localStorage.getItem('token') !== null;
  }

  public async signIn(userInfo: IUserLogin): Promise<any> {
    const url = environment.JUNJI_RAD_API_URL + '/auth/login';
    userInfo.username = Utils.removeAccentsOfString(userInfo.username).toLowerCase();
    return this.http.post(url, userInfo, { responseType: 'text', headers: this.postHeaders }, ).toPromise()
    .then((res) => { this.setToken(res); this.setUserInfo(); })
    .catch((err) => { throw err.error as IDefaultErrorResponse; });
  }

  public signOut() {
    localStorage.clear();
  }

}
