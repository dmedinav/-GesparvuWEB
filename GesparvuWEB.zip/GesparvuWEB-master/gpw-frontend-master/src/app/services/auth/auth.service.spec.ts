import { AuthService } from './auth.service';
import { throwError, of } from 'rxjs';

let http = null;
let authService: AuthService = null;
let postSpy: jasmine.Spy;

describe('AuthService', () => {

  beforeEach(() => {
    http = jasmine.createSpyObj('http', ['get', 'post', 'put', 'delete', 'update', 'patch']);
    postSpy = http.post.and.returnValue();
    authService = new AuthService(http);
  });

  it('should be created', () => {
    expect(authService).toBeTruthy();
  });

  it('should set token', () => {
    const setTokenSpy = spyOn(authService, 'setToken');
    postSpy.and.callFake(() => of({}));
    authService.signIn({ username: 'username', password: 'password' }).then(() => {
      expect(setTokenSpy).toHaveBeenCalled();
    });
  });

  it('should not set token', () => {
    const setTokenSpy = spyOn(authService, 'setToken');
    postSpy.and.throwError('Error').and.callFake(() => throwError({error: {errorMessage: ''}}));
    authService.signIn({ username: 'username', password: 'password' }).catch(() => {
      expect(setTokenSpy).toHaveBeenCalledTimes(0);
    });
  });

  it('should not set token (with null non string error)', () => {
    const setTokenSpy = spyOn(authService, 'setToken');
    postSpy.and.throwError('Error').and.callFake(() => throwError({error: {errorMessage: 1}}));
    authService.signIn({ username: 'username', password: 'password' }).catch(() => {
      expect(setTokenSpy).toHaveBeenCalledTimes(0);
    });
  });

  it('should not set token (with null error)', () => {
    const setTokenSpy = spyOn(authService, 'setToken');
    postSpy.and.throwError('Error').and.callFake(() => throwError({error: null}));
    authService.signIn({ username: 'username', password: 'password' }).catch(() => {
      expect(setTokenSpy).toHaveBeenCalledTimes(0);
    });
  });

  it('should call clear', () => {
    const spy = spyOn(localStorage, 'clear').and.callThrough();
    authService.signOut();
    expect(spy).toHaveBeenCalled();
  });

  it('should call setItem', () => {
    const spy = spyOn(localStorage, 'setItem').and.callThrough();
    authService.setToken('');
    expect(spy).toHaveBeenCalled();
  });

  it('should call getItem and return true', () => {
    const spy = spyOn(localStorage, 'getItem').and.returnValue(true);
    expect(authService.isAuthenticated()).toBeTruthy();
    expect(spy).toHaveBeenCalled();
  });

  it('should call getItem and return false', () => {
    const spy = spyOn(localStorage, 'getItem').and.returnValue(null);
    expect(authService.isAuthenticated()).toBeFalsy();
    expect(spy).toHaveBeenCalled();
  });

  it('should call getItem', () => {
    const spy = spyOn(localStorage, 'getItem').and.callThrough();
    authService.getToken();
    expect(spy).toHaveBeenCalled();
  });

  it('should call getItem and return an object', () => {
    const spy = spyOn(localStorage, 'getItem').and.returnValue('{"rut": 2}');
    const returned = authService.getUserInfo();
    expect(spy).toHaveBeenCalled();
    expect(typeof(returned)).toBe('object');
  });

});
