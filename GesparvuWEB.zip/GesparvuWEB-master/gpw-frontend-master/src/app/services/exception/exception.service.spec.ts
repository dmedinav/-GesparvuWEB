import { exceptionPostMock } from './../../mocks/exceptions.mocks';
import { ExceptionService } from './exception.service';
import { environment } from '@env/environment';
import { throwError, of } from 'rxjs';

let http = null;
let exceptionService: ExceptionService = null;
let getSpy: jasmine.Spy;
let postSpy: jasmine.Spy;

describe('ExceptionService', () => {
  beforeEach(() => {
    http = jasmine.createSpyObj('http', ['get', 'post', 'put', 'delete', 'update', 'patch']);
    getSpy = http.get;
    postSpy = http.post;
    exceptionService = new ExceptionService(http);
  });

  it('should be created', () => {
    expect(exceptionService).toBeTruthy();
  });

  describe('getAllExceptionType tests', () => {

    it('should catch exceptions', () => {
      const serviceUrl = environment.JUNJI_RAD_API_URL + '/exception-types';
      getSpy.and.throwError('Error').and.callFake(() => throwError({error: 'Error'}));
      exceptionService.getAllExceptionTypes().then(
        () => { },
        (res) => {
          expect(res).toBeDefined();
          expect(getSpy).toHaveBeenCalledWith(serviceUrl);
        });
    });

    it('should return promise with request', async () => {
      const serviceUrl = environment.JUNJI_RAD_API_URL + '/exception-types';
      getSpy.and.callFake(() => of({}));
      const result = await exceptionService.getAllExceptionTypes();
      expect(result).toBeDefined();
      expect(getSpy).toHaveBeenCalledWith(serviceUrl);
    });

  });

  describe('createException tests', () => {

    it('should catch exceptions', () => {
      const requestData = null;
      const serviceUrl = environment.JUNJI_RAD_API_URL + '/exceptions';
      postSpy.and.throwError('Error').and.callFake(() => throwError({error: 'Error'}));
      exceptionService.createException(null).then(
        () => { },
        (res) => {
          expect(res).toBeDefined();
          expect(postSpy).toHaveBeenCalledWith(serviceUrl, requestData, { headers: exceptionService.postHeaders });
        });
      });

    it('should return promise with request', async () => {
      const serviceUrl = environment.JUNJI_RAD_API_URL + '/exceptions';
      postSpy.and.callFake(() => of({}));
      const result = await exceptionService.createException(exceptionPostMock);
      expect(result).toBeDefined();
      expect(postSpy).toHaveBeenCalledWith(serviceUrl, exceptionPostMock, { headers: exceptionService.postHeaders });
    });

  });

  describe('getCalendarInformation tests', () => {

    it('should catch exceptions', () => {
      const serviceUrl = environment.JUNJI_RAD_API_URL + '/exceptions/calendar';
      getSpy.and.throwError('Error').and.callFake(() => throwError({error: 'Error'}));
      exceptionService.getCalendarInformation(1, 2019, 1).then(
        () => { },
        (res) => {
          expect(res).toBeDefined();
          expect(getSpy).toHaveBeenCalledWith(serviceUrl, { params: { month: '1', year: '2019', group: '1' }});
        });
    });

    it('should return promise with request', async () => {
      const serviceUrl = environment.JUNJI_RAD_API_URL + '/exceptions/calendar';
      getSpy.and.callFake(() => of([{data: new Date()}]));
      const result = await exceptionService.getCalendarInformation(1, 2019, 1);
      expect(result).toBeDefined();
      expect(getSpy).toHaveBeenCalledWith(serviceUrl, { params: { month: '1', year: '2019', group: '1' }});
    });

  });

});
