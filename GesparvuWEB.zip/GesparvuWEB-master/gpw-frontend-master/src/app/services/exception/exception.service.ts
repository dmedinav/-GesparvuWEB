import { IDefaultErrorResponse, IDefaultSuccessResponse } from './../../common/interfaces/default.interface';
import { IExceptionType, IExceptionRequest, IExceptionCalendar } from './../../common/interfaces/exceptions.interface';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from '@env/environment';

@Injectable({
  providedIn: 'root'
})
export class ExceptionService {

  postHeaders: HttpHeaders;
  constructor(private http: HttpClient) {
    this.postHeaders = new HttpHeaders({
      'Content-Type':  'application/json',
    });
  }

  public async getAllExceptionTypes(): Promise<IExceptionType[]> {
    const url = environment.JUNJI_RAD_API_URL + '/exception-types';
    return this.http.get(url).toPromise()
    .then((res) => res as IExceptionType[])
    .catch((err) => { throw err.error as IDefaultErrorResponse; });
  }

  public async createException(exception: IExceptionRequest): Promise<any> {
    const url = environment.JUNJI_RAD_API_URL + '/exceptions';
    return this.http.post(url, exception, { headers: this.postHeaders }).toPromise()
    .then((res) => res as IDefaultSuccessResponse)
    .catch((err) => { throw err.error as IDefaultErrorResponse; });
  }

  public async getCalendarInformation(group: number, year: number, month: number): Promise<IExceptionCalendar[]> {
    const queryParams = {
      month: month.toString(),
      year: year.toString(),
      group: group.toString(),
    };
    const url = environment.JUNJI_RAD_API_URL + '/exceptions/calendar';
    return this.http.get(url, { params: queryParams }).toPromise()
    .then((res) => {
      for (const r of res as IExceptionCalendar[]) {
        r.date = new Date(r.date);
      }
      return res as IExceptionCalendar[];
    })
    .catch((err) => { throw err.error as IDefaultErrorResponse; });
  }

}
