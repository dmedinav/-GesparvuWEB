import { ModalService } from './modal.service';
import { IDefaultImageContainer } from '../../common/interfaces/default.interface';

let modalService: ModalService = null;
let dialog = null;
let openSpy: jasmine.Spy;

describe('ModalService', () => {

  const imageContainer: IDefaultImageContainer = {iconClass: '', title: 'title', subtitle: 'subtitle'};

  beforeEach(() => {
    dialog = jasmine.createSpyObj('dialog', ['open']);
    openSpy = dialog.open;
    modalService = new ModalService(dialog);
  });

  it('should be created', () => {
    expect(modalService).toBeTruthy();
  });

  it('should open a modal', () => {
    const modalSpy = spyOn(modalService, 'openModal').and.callThrough();
    modalService.openModal(imageContainer);
    expect(modalSpy).toHaveBeenCalledWith(imageContainer);
  });

  it('should open a modal with width and height', () => {
    const modalSpy = spyOn(modalService, 'openModal').and.callThrough();
    modalService.openModal(imageContainer, '500px', '500px');
    expect(modalSpy).toHaveBeenCalledWith(imageContainer, '500px', '500px');
  });

});
