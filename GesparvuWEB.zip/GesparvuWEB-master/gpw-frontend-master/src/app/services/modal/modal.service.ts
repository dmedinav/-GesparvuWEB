import { MatDialog } from '@angular/material';
import { GenericModalComponent } from './../../components/generic-modal/generic-modal.component';
import { IDefaultImageContainer } from './../../common/interfaces/default.interface';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ModalService {

  constructor(private dialog: MatDialog) { }

  public openModal(data: IDefaultImageContainer, width: string = '424px', height: string = 'auto'): void {
    this.dialog.open(GenericModalComponent, { width, height, data });
  }

}
