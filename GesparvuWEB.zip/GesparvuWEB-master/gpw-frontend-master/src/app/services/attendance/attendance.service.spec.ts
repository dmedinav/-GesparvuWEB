import { DEFAULT_ERROR_MESSAGE } from './../../common/constants/default.constants';
import { attendancePostMock } from './../../mocks/attendance.mocks';
import { AttendanceService } from './attendance.service';
import { throwError, of } from 'rxjs';
import { environment } from '@env/environment';
import * as FileSaver from 'file-saver';

let http = null;
let attendanceService: AttendanceService = null;
let putSpy: jasmine.Spy;
let getSpy: jasmine.Spy;
let saveSpy: jasmine.Spy;

describe('AttendanceService', () => {
  beforeEach(() => {
    http = jasmine.createSpyObj('http', ['get', 'post', 'put', 'delete', 'update', 'patch']);
    getSpy = http.get;
    putSpy = http.put;
    attendanceService = new AttendanceService(http);
  });

  it('should be created', () => {
    expect(attendanceService).toBeTruthy();
  });

  it('should catch exceptions and use the errorMessage if it comes with one', () => {
    const requestData = null;
    const serviceUrl = environment.JUNJI_RAD_API_URL + '/attendances';
    putSpy.and.throwError('Error').and.callFake(() => throwError({error: { errorMessage: 'Error' } }));
    attendanceService.updateAttendanceObject(null).then(
      () => { },
      (res) => {
        expect(res.errorMessage).toBe('Error');
        expect(putSpy).toHaveBeenCalledWith(serviceUrl, requestData, { headers: attendanceService.postHeaders });
      });
  });

  it('should return promise with request', async () => {
    const serviceUrl = environment.JUNJI_RAD_API_URL + '/attendances';
    putSpy.and.callFake(() => of({}));
    const result = await attendanceService.updateAttendanceObject(attendancePostMock);
    expect(result).toBeDefined();
    expect(putSpy).toHaveBeenCalledWith(serviceUrl, attendancePostMock, { headers: attendanceService.postHeaders });
  });

  it('should return promise with excel', async () => {
    const serviceUrl = environment.JUNJI_RAD_API_URL + '/attendances/monthly/file';
    saveSpy = spyOn(FileSaver, 'saveAs').and.returnValue({});
    getSpy.and.callFake(() => of({}));
    await attendanceService.getExcelFile(3, 2019, {id: 254, name: 'A'});
    expect(getSpy).toHaveBeenCalledWith(serviceUrl, {responseType: 'blob', params: {year: '2019', month: '3', group: '254'} });
    expect(saveSpy).toHaveBeenCalledTimes(1);
  });

  it('should catch exceptions and use the errorMessage if excel service fails', async () => {
    const serviceUrl = environment.JUNJI_RAD_API_URL + '/attendances/monthly/file';
    saveSpy = spyOn(FileSaver, 'saveAs').and.returnValue({});
    getSpy.and.callFake(() => throwError({error: { errorMessage: 'Error' } }));
    attendanceService.getExcelFile(3, 2019, {id: 254, name: 'A'})
    .then(
      () => { },
      (res) => {
        expect(getSpy).toHaveBeenCalledWith(serviceUrl, {responseType: 'blob', params: {year: '2019', month: '3', group: '254'} });
        expect(saveSpy).toHaveBeenCalledTimes(0);
        expect(res.errorMessage).toBe('Error');
      }
    );
  });

});
