import { IDefaultErrorResponse, IDefaultSuccessResponse } from './../../common/interfaces/default.interface';
import { IAttendanceUpdateObject } from './../../common/interfaces/attendance.interface';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from '@env/environment';
import * as FileSaver from 'file-saver';
import { ISimpleGroup } from '../../common/interfaces/groups.interface';

@Injectable({
  providedIn: 'root'
})
export class AttendanceService {

  postHeaders: HttpHeaders;
  constructor(private http: HttpClient) {
    this.postHeaders = new HttpHeaders({
      'Content-Type':  'application/json',
    });
  }

  public async updateAttendanceObject(attendances: IAttendanceUpdateObject): Promise<any> {
    const url = environment.JUNJI_RAD_API_URL + '/attendances';
    return this.http.put(url, attendances, { headers: this.postHeaders }).toPromise()
    .then((res) => res as IDefaultSuccessResponse)
    .catch((err) => { throw err.error as IDefaultErrorResponse; });
  }

  public async getExcelFile(month: number, year: number, group: ISimpleGroup): Promise<any> {
    const queryParams = {
      year: year.toString(),
      month: month.toString(),
      group: group.id.toString(),
    };
    const url = environment.JUNJI_RAD_API_URL + '/attendances/monthly/file';
    return this.http.get(url, {responseType: 'blob', params: queryParams}).toPromise()
    .then((res) => {
      FileSaver.saveAs(res, 'Asistencia ' + month + '-' + year + ' Grupo ' + group.name + '.xlsx');
    })
    .catch((err) => { throw err.error as IDefaultErrorResponse; });
  }

}
