import { IDefaultSuccessResponse } from './../../common/interfaces/default.interface';
import { IDefaultErrorResponse } from '../../common/interfaces/default.interface';
import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { environment } from '@env/environment';
import { ITransfer } from '../../common/interfaces/transfers.interface';

@Injectable({
  providedIn: 'root'
})
export class TransferService {

  postHeaders: HttpHeaders;
  constructor(private http: HttpClient) {
    this.postHeaders = new HttpHeaders({
      'Content-Type':  'application/json',
    });
  }

  public async createTransfer(transfer: ITransfer): Promise<any> {
    const url = environment.JUNJI_RAD_API_URL + '/movements/transfer';
    return this.http.post(url, transfer, { headers: this.postHeaders }).toPromise()
      .then((res) => res as IDefaultSuccessResponse)
      .catch((err) => { throw err.error as IDefaultErrorResponse; });
  }
}
