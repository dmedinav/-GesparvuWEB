import { IDefaultErrorResponse } from './../../common/interfaces/default.interface';
import { IEnrollmentsResponse, IEnrollmentsByGroupResponse } from './../../common/interfaces/enrollments.interface';
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from '@env/environment';

@Injectable({
  providedIn: 'root'
})
export class EnrollmentService {

  constructor(private http: HttpClient) { }

  public async getEnrollmentsByGroupId(groupId: number): Promise<IEnrollmentsResponse> {
    const url = environment.JUNJI_RAD_API_URL + '/enrollments/group/' + groupId.toString();
    return this.http.get(url).toPromise()
    .then((res) => res as IEnrollmentsResponse)
    .catch((err) => { throw err.error as IDefaultErrorResponse; });
  }

  public async getEnrollmentsByGroupIdAndHalfDate(groupId: number, year: number, month: number): Promise<IEnrollmentsResponse> {
    const queryParams = {
      year: year.toString(),
      month: month.toString(),
    };
    const url = environment.JUNJI_RAD_API_URL + '/enrollments/group/' + groupId.toString();
    return this.http.get(url, { params: queryParams } ).toPromise()
    .then((res) => res as IEnrollmentsResponse)
    .catch((err) => { throw err.error as IDefaultErrorResponse; });
  }

  public async getEnrollmentsByGroupIdAndCompleteDate(
    groupId: number,
    year: number,
    month: number,
    day: number
  ): Promise<IEnrollmentsResponse> {
    const queryParams = {
      year: year.toString(),
      month: month.toString(),
      day: day.toString(),
    };
    const url = environment.JUNJI_RAD_API_URL + '/enrollments/group/' + groupId.toString();
    return this.http.get(url, { params: queryParams } ).toPromise()
    .then((res) => res as IEnrollmentsResponse)
    .catch((err) => { throw err.error as IDefaultErrorResponse; });
  }

  public async getEnrollmentsByFilter(
    filter: string,
  ): Promise<IEnrollmentsResponse> {
    const queryParams = {
      filter,
    };
    const url = environment.JUNJI_RAD_API_URL + '/enrollments';
    return this.http.get(url, { params: queryParams } ).toPromise()
    .then((res) => res as IEnrollmentsResponse)
    .catch((err) => { throw err.error as IDefaultErrorResponse; });
  }

  public async getEnrollmentById(
    enrollmentId: string,
  ): Promise<IEnrollmentsByGroupResponse> {
    const url = environment.JUNJI_RAD_API_URL + '/enrollments/' + enrollmentId;
    return this.http.get(url).toPromise()
    .then((res) => res as IEnrollmentsByGroupResponse)
    .catch((err) => { throw err.error as IDefaultErrorResponse; });
  }

}
