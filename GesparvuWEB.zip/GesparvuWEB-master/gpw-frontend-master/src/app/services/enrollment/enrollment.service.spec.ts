import {
  enrollmentByGroupAndCompleteDateQueryMock,
  enrollmentByGroupAndHalfDateQueryMock
} from './../../mocks/enrollments.mocks';
import { environment } from '@env/environment';
import { EnrollmentService } from './enrollment.service';
import { throwError, of } from 'rxjs';

let http = null;
let enrollmentService: EnrollmentService = null;
let getSpy: jasmine.Spy;

describe('EnrollmentService', () => {
  beforeEach(() => {
    http = jasmine.createSpyObj('http', ['get', 'post', 'put', 'delete', 'update', 'patch']);
    getSpy = http.get;
    enrollmentService = new EnrollmentService(http);
  });

  it('should be created', () => {
    expect(enrollmentService).toBeTruthy();
  });

  describe('getEnrollmentsByGroupId', () => {
    it('should catch exceptions', () => {
      const serviceUrl = environment.JUNJI_RAD_API_URL + '/enrollments/group/1';
      getSpy.and.throwError('Error').and.callFake(() => throwError({error: 'Error'}));
      enrollmentService.getEnrollmentsByGroupId(1).then(
        () => { },
        (res) => {
          expect(res).toBeDefined();
          expect(getSpy).toHaveBeenCalledWith(serviceUrl);
        });
    });

    it('should return promise with request', async () => {
      const serviceUrl = environment.JUNJI_RAD_API_URL + '/enrollments/group/1';
      getSpy.and.callFake(() => of({}));
      const result = await enrollmentService.getEnrollmentsByGroupId(1);
      expect(result).toBeDefined();
      expect(getSpy).toHaveBeenCalledWith(serviceUrl);
    });

    it('should catch exceptions with no name error', () => {
      const serviceUrl = environment.JUNJI_RAD_API_URL + '/enrollments/group/1';
      getSpy.and.throwError('Error').and.callFake(() => throwError({error: { errorMessage: 'Error' } }));
      enrollmentService.getEnrollmentsByGroupId(1).then(
        () => { },
        (res) => {
          expect(res.errorMessage).toBe('Error');
          expect(getSpy).toHaveBeenCalledWith(serviceUrl);
        });
    });

  });

  describe('getEnrollmentsByGroupIdAndHalfDate', () => {

    it('should return promise with request', async () => {
      const serviceUrl = environment.JUNJI_RAD_API_URL + '/enrollments/group/1';
      getSpy.and.callFake(() => of({}));
      const result = await enrollmentService.getEnrollmentsByGroupIdAndHalfDate(1, 2019, 1);
      expect(result).toBeDefined();
      expect(getSpy).toHaveBeenCalledWith(serviceUrl, { params: enrollmentByGroupAndHalfDateQueryMock });
    });

    it('should catch exceptions with no name error', () => {
      const serviceUrl = environment.JUNJI_RAD_API_URL + '/enrollments/group/1';
      getSpy.and.throwError('Error').and.callFake(() => throwError({error: { errorMessage: 'Error' } }));
      enrollmentService.getEnrollmentsByGroupIdAndHalfDate(1, 2019, 1).then(
        () => { },
        (res) => {
          expect(res.errorMessage).toBe('Error');
          expect(getSpy).toHaveBeenCalledWith(serviceUrl, { params: enrollmentByGroupAndHalfDateQueryMock });
        });
    });
  });

  describe('getEnrollmentsByGroupIdAndCompleteDate', () => {

    it('should catch exceptions with no name error', () => {
      const serviceUrl = environment.JUNJI_RAD_API_URL + '/enrollments/group/1';
      getSpy.and.throwError('Error').and.callFake(() => throwError({error: { errorMessage: 'Error' } }));
      enrollmentService.getEnrollmentsByGroupIdAndCompleteDate(1, 2019, 1, 1).then(
        () => { },
        (res) => {
          expect(res.errorMessage).toBe('Error');
          expect(getSpy).toHaveBeenCalledWith(serviceUrl, { params: enrollmentByGroupAndCompleteDateQueryMock });
        });
    });

    it('should return promise with request', async () => {
      const serviceUrl = environment.JUNJI_RAD_API_URL + '/enrollments/group/1';
      getSpy.and.callFake(() => of({}));
      const result = await enrollmentService.getEnrollmentsByGroupIdAndCompleteDate(1, 2019, 1, 1);
      expect(result).toBeDefined();
      expect(getSpy).toHaveBeenCalledWith(serviceUrl, { params: enrollmentByGroupAndCompleteDateQueryMock });
    });

  });

  describe('getEnrollmentsByFilter', () => {

    it('should catch exceptions with no name error', () => {
      const filter = 'filter';
      const serviceUrl = environment.JUNJI_RAD_API_URL + '/enrollments';
      getSpy.and.throwError('Error').and.callFake(() => throwError({error: { errorMessage: 'Error' } }));
      enrollmentService.getEnrollmentsByFilter(filter).then(
        () => { },
        (res) => {
          expect(res.errorMessage).toBe('Error');
          expect(getSpy).toHaveBeenCalledWith(serviceUrl, { params: {filter} });
        });
    });

    it('should return promise with request', async () => {
      const filter = 'filter';
      const serviceUrl = environment.JUNJI_RAD_API_URL + '/enrollments';
      getSpy.and.callFake(() => of({}));
      const result = await enrollmentService.getEnrollmentsByFilter(filter);
      expect(result).toBeDefined();
      expect(getSpy).toHaveBeenCalledWith(serviceUrl, { params: {filter} });
    });
  });

  describe('getEnrollmentById', () => {

    it('should return promise with request', async () => {
      const serviceUrl = environment.JUNJI_RAD_API_URL + '/enrollments/1';
      getSpy.and.callFake(() => of({}));
      const result = await enrollmentService.getEnrollmentById('1');
      expect(result).toBeDefined();
      expect(getSpy).toHaveBeenCalledWith(serviceUrl);
    });

    it('should catch exceptions with no name error', () => {
      const serviceUrl = environment.JUNJI_RAD_API_URL + '/enrollments/1';
      getSpy.and.throwError('Error').and.callFake(() => throwError({error: { errorMessage: 'Error' } }));
      enrollmentService.getEnrollmentById('1').then(
        () => { },
        (res) => {
          expect(res.errorMessage).toBe('Error');
          expect(getSpy).toHaveBeenCalledWith(serviceUrl);
        });
    });

  });

});
