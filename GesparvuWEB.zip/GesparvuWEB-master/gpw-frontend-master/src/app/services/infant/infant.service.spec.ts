import { environment } from '@env/environment';
import { throwError, of } from 'rxjs';
import { InfantService } from './infant.service';
import { infantPostMock } from '../../mocks/infant.mock';

let http = null;
let infantService: InfantService = null;
let getSpy: jasmine.Spy;
let postSpy: jasmine.Spy;

describe('InfantService', () => {
  beforeEach(() => {
    http = jasmine.createSpyObj('http', ['get', 'post', 'put', 'delete', 'update', 'patch']);
    getSpy = http.get;
    postSpy = http.post;
    infantService = new InfantService(http);
  });

  it('should be created', () => {
    expect(infantService).toBeTruthy();
  });

  describe('createInfant', () => {

    it('should catch infants', () => {
      const requestData = null;
      const serviceUrl = environment.JUNJI_RAD_API_URL + '/infants';
      postSpy.and.throwError('Error').and.callFake(() => throwError({ error: 'Error' }));
      infantService.createInfant(null).then(
        () => { },
        (res) => {
          expect(res).toBeDefined();
          expect(postSpy).toHaveBeenCalledWith(serviceUrl, requestData, { headers: infantService.postHeaders });
        });
    });

    it('should return promise with request', async () => {
      const serviceUrl = environment.JUNJI_RAD_API_URL + '/infants';
      postSpy.and.callFake(() => of({}));
      const result = await infantService.createInfant(infantPostMock);
      expect(result).toBeDefined();
      expect(postSpy).toHaveBeenCalledWith(serviceUrl, infantPostMock, { headers: infantService.postHeaders });
    });

  });

  describe('getInfant', () => {

    it('should return promise with request', async () => {
      const serviceUrl = environment.JUNJI_RAD_API_URL + '/infants/sim/11111111-1';
      getSpy.and.callFake(() => of({}));
      const result = await infantService.getSimInfantByRut('11111111-1');
      expect(result).toBeDefined();
      expect(getSpy).toHaveBeenCalledWith(serviceUrl);
    });

    it('should catch infants with no name error', () => {
      const serviceUrl = environment.JUNJI_RAD_API_URL + '/infants/sim/11111111-1';
      getSpy.and.throwError('Error').and.callFake(() => throwError({ error: { errorMessage: 'Error' } }));
      infantService.getSimInfantByRut('11111111-1').then(
        () => { },
        (res) => {
          expect(res.errorMessage).toBe('Error');
          expect(getSpy).toHaveBeenCalledWith(serviceUrl);
        });
    });

  });

});
