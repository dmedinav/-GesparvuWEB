import { IInfantCreation } from './../../common/interfaces/infant.interface';
import { IDefaultErrorResponse, IDefaultSuccessResponse } from './../../common/interfaces/default.interface';
import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { environment } from '@env/environment';
import { IInfant } from '../../common/interfaces/infant.interface';

@Injectable({
  providedIn: 'root'
})
export class InfantService {

  postHeaders: HttpHeaders;
  constructor(private http: HttpClient) {
    this.postHeaders = new HttpHeaders({
      'Content-Type': 'application/json',
    });
  }

  public async getSimInfantByRut(rut: string): Promise<IInfant> {
    const url = environment.JUNJI_RAD_API_URL + '/infants/sim/' + rut;
    return this.http.get(url).toPromise()
      .then((res) => res as IInfant)
      .catch((err) => { throw err.error as IDefaultErrorResponse; });
  }

  public async createInfant(infant: IInfantCreation): Promise<any> {
    const url = environment.JUNJI_RAD_API_URL + '/infants';
    return this.http.post(url, infant, { headers: this.postHeaders }).toPromise()
      .then((res) => res as IDefaultSuccessResponse)
      .catch((err) => { throw err.error as IDefaultErrorResponse; });
  }

}
