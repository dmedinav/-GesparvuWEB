import { environment } from '@env/environment';
import { throwError, of } from 'rxjs';
import { SexualityService } from './sexuality.service';

let http = null;
let sexualityService: SexualityService = null;
let getSpy: jasmine.Spy;
let postSpy: jasmine.Spy;

describe('SexualityService', () => {
  beforeEach(() => {
    http = jasmine.createSpyObj('http', ['get', 'post', 'put', 'delete', 'update', 'patch']);
    getSpy = http.get;
    postSpy = http.post;
    sexualityService = new SexualityService(http);
  });

  it('should be created', () => {
    expect(sexualityService).toBeTruthy();
  });

  describe('getSexualities', () => {

    it('should return promise with request', async () => {
      const serviceUrl = environment.JUNJI_RAD_API_URL + '/sexualities';
      getSpy.and.callFake(() => of({}));
      const result = await sexualityService.getSexualities();
      expect(result).toBeDefined();
      expect(getSpy).toHaveBeenCalledWith(serviceUrl);
    });

    it('should catch sexualites with no name error', () => {
      const serviceUrl = environment.JUNJI_RAD_API_URL + '/sexualities';
      getSpy.and.throwError('Error').and.callFake(() => throwError({ error: { errorMessage: 'Error' } }));
      sexualityService.getSexualities().then(
        () => { },
        (res) => {
          expect(res.errorMessage).toBe('Error');
          expect(getSpy).toHaveBeenCalledWith(serviceUrl);
        });
    });

  });

});
