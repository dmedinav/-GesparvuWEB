import { IDefaultErrorResponse } from './../../common/interfaces/default.interface';
import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { environment } from '@env/environment';
import { ISexuality } from '../../common/interfaces/infant.interface';

@Injectable({
  providedIn: 'root'
})
export class SexualityService {

  postHeaders: HttpHeaders;
  constructor(private http: HttpClient) {
    this.postHeaders = new HttpHeaders({
      'Content-Type': 'application/json',
    });
  }

  public async getSexualities(): Promise<ISexuality[]> {
    const url = environment.JUNJI_RAD_API_URL + '/sexualities';
    return this.http.get(url).toPromise()
      .then((res) => res as ISexuality[])
      .catch((err) => { throw err.error as IDefaultErrorResponse; });
  }

}
