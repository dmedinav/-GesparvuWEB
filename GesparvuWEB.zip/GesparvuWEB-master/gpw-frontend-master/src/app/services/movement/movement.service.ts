import { IDefaultSuccessResponse } from './../../common/interfaces/default.interface';
import { IMovement } from './../../common/interfaces/movements.interface';
import { IDefaultErrorResponse } from '../../common/interfaces/default.interface';
import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { environment } from '@env/environment';
import { IMovementTypes } from '../../common/interfaces/movements.interface';

@Injectable({
  providedIn: 'root'
})
export class MovementService {

  postHeaders: HttpHeaders;
  constructor(private http: HttpClient) {
    this.postHeaders = new HttpHeaders({
      'Content-Type':  'application/json',
    });
  }

  public async getMovementTypes(): Promise<IMovementTypes[]> {
    const url = environment.JUNJI_RAD_API_URL + '/movements/types';
    return this.http.get(url).toPromise()
    .then((res) => res as IMovementTypes[])
    .catch((err) => { throw err.error as IDefaultErrorResponse; });
  }

  public async createMovement(movement: IMovement): Promise<any> {
    const url = environment.JUNJI_RAD_API_URL + '/movements/withdraw';
    return this.http.post(url, movement, { headers: this.postHeaders }).toPromise()
    .then((res) => res as IDefaultSuccessResponse)
    .catch((err) => { throw err.error as IDefaultErrorResponse; });
  }

}
