import { movementPostMock } from './../../mocks/movements.mocks';
import { MovementService } from './movement.service';
import { environment } from '@env/environment';
import { throwError, of } from 'rxjs';
import { DEFAULT_ERROR_MESSAGE } from '../../common/constants/default.constants';

let http = null;
let movementService: MovementService = null;
let getSpy: jasmine.Spy;
let postSpy: jasmine.Spy;

describe('MovementService', () => {
  beforeEach(() => {
    http = jasmine.createSpyObj('http', ['get', 'post', 'put', 'delete', 'update', 'patch']);
    getSpy = http.get;
    postSpy = http.post;
    movementService = new MovementService(http);
  });

  it('should be created', () => {
    expect(movementService).toBeTruthy();
  });

  describe('getMovementTypes tests', () => {

    it('should catch exceptions', () => {
      const serviceUrl = environment.JUNJI_RAD_API_URL + '/movements/types';
      getSpy.and.throwError('Error').and.callFake(() => throwError({error: { errorMessage: 'Error' }}));
      movementService.getMovementTypes().then(
        () => { },
        (res) => {
          expect(res.errorMessage).toBe('Error');
          expect(getSpy).toHaveBeenCalledWith(serviceUrl);
        });
    });

    it('should return promise with request', async () => {
      const serviceUrl = environment.JUNJI_RAD_API_URL + '/movements/types';
      getSpy.and.callFake(() => of({}));
      const result = await movementService.getMovementTypes();
      expect(result).toBeDefined();
      expect(getSpy).toHaveBeenCalledWith(serviceUrl);
    });

  });

  describe('createMovement tests', () => {

    it('should catch exceptions', () => {
      const requestData = null;
      const serviceUrl = environment.JUNJI_RAD_API_URL + '/movements/withdraw';
      postSpy.and.throwError('Error').and.callFake(() => throwError({error: { errorMessage: 'Error' }}));
      movementService.createMovement(null).then(
        () => { },
        (res) => {
          expect(res.errorMessage).toBe('Error');
          expect(postSpy).toHaveBeenCalledWith(serviceUrl, requestData, { headers: movementService.postHeaders });
        });
    });

    it('should return promise with request', async () => {
      const serviceUrl = environment.JUNJI_RAD_API_URL + '/movements/withdraw';
      postSpy.and.callFake(() => of({}));
      const result = await movementService.createMovement(movementPostMock);
      expect(result).toBeDefined();
      expect(postSpy).toHaveBeenCalledWith(serviceUrl, movementPostMock, { headers: movementService.postHeaders });
    });

  });

});
