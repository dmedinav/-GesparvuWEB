import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { SwitchRadioButtonComponent } from './switch-radio-button.component';
import { switchRadioButtonMock, switchRadioButtonOutputMockError } from '../../mocks/component-params.mock';

describe('SwitchRadioButtonComponent', () => {
  let component: SwitchRadioButtonComponent;
  let fixture: ComponentFixture<SwitchRadioButtonComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SwitchRadioButtonComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SwitchRadioButtonComponent);
    component = fixture.componentInstance;
    component.buttonLeft = switchRadioButtonMock;
    component.buttonRight = switchRadioButtonMock;
    component.switchName = 'switchName';
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should emit a ISwitchRadioButtonOutput with correct properties', () => {
    const input = fixture.nativeElement.querySelector('#switchNameleft');
    component.changeValue.subscribe(p => {
      expect(p).toEqual(switchRadioButtonOutputMockError);
    });
    component.handleChange(input);
  });

});
