import { SwitchRadioButtonComponent } from './switch-radio-button.component';
import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { MaterialModule } from '../../material.module';

@NgModule({
  imports: [
    CommonModule,
    MaterialModule,
  ],
  declarations: [
    SwitchRadioButtonComponent
  ],
  exports: [
    SwitchRadioButtonComponent
  ]
})
export class SwitchRadioButtonModule { }
