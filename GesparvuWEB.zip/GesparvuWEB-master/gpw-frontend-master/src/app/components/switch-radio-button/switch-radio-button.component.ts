import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { ISwitchRadioButton, ISwitchRadioButtonOutput } from '../../common/interfaces/switch-radio-button.interface';

@Component({
  selector: 'app-switch-radio-button',
  templateUrl: './switch-radio-button.component.html',
  styleUrls: ['./switch-radio-button.component.scss']
})
export class SwitchRadioButtonComponent implements OnInit {

  @Input() buttonLeft: ISwitchRadioButton;
  @Input() buttonRight: ISwitchRadioButton;
  @Input() switchName: string;
  @Input() checkedValue: string;

  @Output() changeValue: EventEmitter<ISwitchRadioButtonOutput>;

  constructor() {
    this.changeValue = new EventEmitter();
  }

  ngOnInit() {
  }

  handleChange(HTMLinput: any) {
    this.changeValue.emit({id: HTMLinput.name, value: HTMLinput.value});
  }

}
