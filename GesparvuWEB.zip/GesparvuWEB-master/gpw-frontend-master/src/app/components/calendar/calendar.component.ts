import { EMPTY_DAY_DETAILS } from './../../common/constants/calendar.constants';
import {
  DEFAULT_HOLIDAY_CALENDAR_CLASS,
  DEFAULT_EXCEPTION_CALENDAR_CLASS,
  DEFAULT_HOLIDAY_EVENT_CLASS,
  DEFAULT_EXCEPTION_EVENT_CLASS,
  DEFAULT_EVENT_CLASS,
  DEFAULT_EVENT_DESCRIPTION,
  DAY_NAMES,
  MONTHS_NAMES
} from './../../common/constants/default.constants';
import { IExceptionCalendarDayDetails, IExceptionCalendar } from './../../common/interfaces/exceptions.interface';
import { Component, Input, Output, EventEmitter, OnInit, AfterViewInit } from '@angular/core';
import { MatCalendarCellCssClasses } from '@angular/material';
import Utils from '@utils/utils';
import { Subject } from 'rxjs';

@Component({
  selector: 'app-calendar',
  templateUrl: './calendar.component.html',
  styleUrls: ['./calendar.component.scss']
})
export class CalendarComponent implements OnInit, AfterViewInit {

  currentTooltip: any;
  dayDetails: IExceptionCalendarDayDetails;
  calendarInformation: IExceptionCalendar[];
  @Input() selectedDate: Date;
  @Input()
  set calendar(calendar: IExceptionCalendar[]) {
    this.calendarInformation = calendar;
    this.updateDayDetails();
    this.updateDayStyles();
  }
  @Input() resetTooltip: Subject<boolean>;
  @Output() updateDate: EventEmitter<Date>;
  @Output() updateMonth: EventEmitter<Date>;

  constructor() {
    this.dayDetails = EMPTY_DAY_DETAILS;
    this.updateDate = new EventEmitter();
    this.updateMonth = new EventEmitter();
  }

  ngOnInit() {
    this.resetTooltip.subscribe(() => {
      this.resetCurrentTooltip();
    });
  }

  ngAfterViewInit(): void {
    const calendarHeader = document.querySelectorAll('mat-calendar-header')[0];
    const periodButton = calendarHeader.querySelectorAll('button')[0];
    periodButton.disabled = true;
  }

  public onSelect(event) {
    this.selectedDate = event;
    this.updateDayDetails();
    this.updateDayStyles();
    this.updateDate.emit(event);
  }

  public changeMonth(quantity: number) {
    const newDate = new Date(this.selectedDate.getTime());
    newDate.setMonth(newDate.getUTCMonth() + quantity);
    this.updateMonth.emit(newDate);
  }

  public dateClass() {
    return (date: Date): MatCalendarCellCssClasses => {
      return this.getCalendarOrEventClass(date, false);
    };
  }

  public getCalendarOrEventClass(date: Date, isEvent: boolean) {
    let returnedClass = isEvent ? DEFAULT_EVENT_CLASS : '';
    this.calendarInformation.forEach((calendarDay) => {
      if (Utils.compareDates(calendarDay.date, date)) {
        if (calendarDay.isHoliday) {
          returnedClass = isEvent ? DEFAULT_HOLIDAY_EVENT_CLASS : DEFAULT_HOLIDAY_CALENDAR_CLASS;
        } else {
          returnedClass = isEvent ? DEFAULT_EXCEPTION_EVENT_CLASS : DEFAULT_EXCEPTION_CALENDAR_CLASS;
        }
      }
    });
    return returnedClass;
  }

  public getEventDescription(date: Date) {
    const calendarDay = this.calendarInformation.find((e => Utils.compareDates(e.date, date)));
    return !calendarDay ? DEFAULT_EVENT_DESCRIPTION : calendarDay.description;
  }

  public updateDayDetails() {
    this.dayDetails.eventClass = this.getCalendarOrEventClass(this.selectedDate, true);
    this.dayDetails.eventDescription = this.getEventDescription(this.selectedDate);
    this.dayDetails.day = this.selectedDate.getUTCDate();
    this.dayDetails.weekDay = DAY_NAMES[this.selectedDate.getUTCDay()];
    this.dayDetails.monthName = MONTHS_NAMES[this.selectedDate.getUTCMonth()];
  }

  public resetCurrentTooltip() {
    if (this.currentTooltip) {
      const div = this.currentTooltip.querySelectorAll('div')[0];
      div.classList.remove('tooltip');
      const spans = this.currentTooltip.querySelectorAll('span');
      if (spans.length > 0) {
        spans.forEach(span => {
          div.removeChild(span);
        });
      }
      this.currentTooltip = undefined;
    }
  }

  public createEventContainer(div: any) {
    const span = document.createElement('span');
    const eventLabel = document.createElement('div');
    const dateLabel = document.createElement('div');
    div.classList.add('tooltip');
    span.classList.add('tooltiptext');
    dateLabel.classList.add('date-label');
    dateLabel.classList.add(this.dayDetails.eventClass);
    eventLabel.classList.add('ellipsis');
    eventLabel.classList.add('event-label');
    dateLabel.innerHTML = `${this.dayDetails.weekDay}, ${this.dayDetails.day} de ${this.dayDetails.monthName}`;
    eventLabel.innerHTML = this.dayDetails.eventDescription;
    span.appendChild(dateLabel);
    span.appendChild(eventLabel);
    div.appendChild(span);
  }

  public updateDayStyles() {
    const calendarContent = document.querySelectorAll('.mat-calendar-content');
    const days: any = calendarContent.length > 0 ? calendarContent[0].querySelectorAll('.mat-calendar-body-cell') : [];
    const dayOfCurrentMonth = new Date(this.selectedDate.getUTCFullYear(), this.selectedDate.getUTCMonth(), 1);
    this.resetCurrentTooltip();
    for (const day of days) {
      if (Utils.compareDates(this.selectedDate, dayOfCurrentMonth)) {
        this.currentTooltip = day;
        const div = day.querySelectorAll('div')[0];
        this.createEventContainer(div);
        break;
      }
      dayOfCurrentMonth.setDate(dayOfCurrentMonth.getUTCDate() + 1);
    }
  }
}
