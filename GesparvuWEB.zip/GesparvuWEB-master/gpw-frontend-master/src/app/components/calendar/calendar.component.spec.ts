import { firsDayDetailsMocks } from './../../mocks/calendar.mock';
import {
  DEFAULT_EVENT_CLASS,
  DEFAULT_HOLIDAY_EVENT_CLASS,
  DEFAULT_EXCEPTION_EVENT_CLASS,
  DEFAULT_EXCEPTION_CALENDAR_CLASS,
  DEFAULT_HOLIDAY_CALENDAR_CLASS,
  DEFAULT_EVENT_DESCRIPTION
} from './../../common/constants/default.constants';
import { EMPTY_DAY_DETAILS } from '../../common/constants/calendar.constants';
import { MaterialModule } from './../../material.module';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CalendarComponent } from './calendar.component';
import { calendarInformationMock } from '../../mocks/calendar.mock';
import { Subject } from 'rxjs';

describe('CalendarComponent', () => {
  let component: CalendarComponent;
  let fixture: ComponentFixture<CalendarComponent>;
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CalendarComponent ],
      imports: [
        MaterialModule,
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CalendarComponent);
    component = fixture.componentInstance;
    component.resetTooltip = new Subject();
    component.selectedDate = new Date('2019-01-01T00:00:00');
    component.calendar = calendarInformationMock;
    component.dayDetails = EMPTY_DAY_DETAILS;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should change selectedDate and emit value when OnSelect is called', () => {
    const updateSpy = spyOn(component.updateDate, 'emit').and.returnValue(true);
    const expected = new Date('2019-02-02T00:00:00');
    expect(updateSpy).toHaveBeenCalledTimes(0);
    expect(component.selectedDate).toEqual(new Date('2019-01-01T00:00:00'));
    component.onSelect(expected);
    expect(component.selectedDate).toEqual(expected);
    expect(updateSpy).toHaveBeenCalledTimes(1);
  });

  it('should change selectedDate by one month and emit value when changeMonth is called', () => {
    const updateSpy = spyOn(component.updateMonth, 'emit').and.returnValue(true);
    const expected = new Date('2019-02-01T00:00:00');
    expect(updateSpy).toHaveBeenCalledTimes(0);
    expect(component.selectedDate).toEqual(new Date('2019-01-01T00:00:00'));
    component.changeMonth(1);
    expect(updateSpy).toHaveBeenCalledWith(expected);
  });

  it('should return empty class when getCalendarOrEventClass is called and isEvent is false', () => {
    const date = new Date('2019-01-20T00:00:00');
    expect(component.getCalendarOrEventClass(date, false)).toBe('');
  });

  it('should return default event class when getCalendarOrEventClass is called and isEvent is true', () => {
    const date = new Date('2019-01-20T00:00:00');
    expect(component.getCalendarOrEventClass(date, true)).toBe(DEFAULT_EVENT_CLASS);
  });

  it('should return exception calendar class when getCalendarOrEventClass is called and isEvent is false', () => {
    const date = new Date('2019-01-01T00:00:00');
    expect(component.getCalendarOrEventClass(date, false)).toBe(DEFAULT_EXCEPTION_CALENDAR_CLASS);
  });

  it('should return exception event class when getCalendarOrEventClass is called and isEvent is true', () => {
    const date = new Date('2019-01-01T00:00:00');
    expect(component.getCalendarOrEventClass(date, true)).toBe(DEFAULT_EXCEPTION_EVENT_CLASS);
  });

  it('should return holiday calendar class when getCalendarOrEventClass is called and isEvent is false', () => {
    const date = new Date('2019-01-02T00:00:00');
    expect(component.getCalendarOrEventClass(date, false)).toBe(DEFAULT_HOLIDAY_CALENDAR_CLASS);
  });

  it('should return holiday event class when getCalendarOrEventClass is called and isEvent is true', () => {
    const date = new Date('2019-01-02T00:00:00');
    expect(component.getCalendarOrEventClass(date, true)).toBe(DEFAULT_HOLIDAY_EVENT_CLASS);
  });

  it('should return holiday event class when getCalendarOrEventClass is called and isEvent is true', () => {
    const date = new Date('2019-01-02T00:00:00');
    expect(component.getCalendarOrEventClass(date, true)).toBe(DEFAULT_HOLIDAY_EVENT_CLASS);
  });

  it('should return default description when no day is found and getEventDescription is called', () => {
    const date = new Date('2019-01-20T00:00:00');
    expect(component.getEventDescription(date)).toBe(DEFAULT_EVENT_DESCRIPTION);
  });

  it('should return calendar description when day is found and getEventDescription is called', () => {
    const date = new Date('2019-01-01T00:00:00');
    expect(component.getEventDescription(date) === DEFAULT_EVENT_DESCRIPTION).toBe(false);
  });

  it('should fill dayDetails object when updateDayDetails is called', () => {
    expect(component.dayDetails).toBe(EMPTY_DAY_DETAILS);
    component.updateDayDetails();
    expect(JSON.stringify(component.dayDetails)).toBe(JSON.stringify(firsDayDetailsMocks));
  });

  it('should reset tooltip', () => {
    component.updateDayStyles();
    fixture.detectChanges();
    expect(component.currentTooltip).toBeDefined();
    component.resetCurrentTooltip();
    fixture.detectChanges();
    expect(component.currentTooltip).toBeUndefined();
  });

  it('should not loop span if not present in current tooltip', () => {
    const td = document.createElement('td');
    const div = document.createElement('div');
    td.appendChild(div);
    component.currentTooltip = td;
    fixture.detectChanges();
    component.resetCurrentTooltip();
    fixture.detectChanges();
    expect(component.currentTooltip).toBeUndefined();
  });

  it('should create a tooltip when createEventContainer is called', () => {
    const div = document.createElement('div');
    const tooltip = fixture.nativeElement.querySelector('.tooltip');
    expect(tooltip).toBeNull();
    component.createEventContainer(div);
    fixture.detectChanges();
    expect(tooltip).toBeDefined();
  });

  it('should create a tooltip when updateDayStyles is called', () => {
    const tooltip = fixture.nativeElement.querySelector('.tooltip');
    expect(tooltip).toBeNull();
    component.updateDayStyles();
    fixture.detectChanges();
    expect(tooltip).toBeDefined();
  });

  it('should reset the tooltip when observable has new value', () => {
    component.updateDayStyles();
    fixture.detectChanges();
    expect(component.currentTooltip).toBeDefined();
    component.resetTooltip.next(true);
    fixture.detectChanges();
    expect(component.currentTooltip).toBeUndefined();
  });

});
