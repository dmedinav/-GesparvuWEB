import { SideBarButtonComponent } from './side-bar-button.component';
import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { MaterialModule } from '../../material.module';

@NgModule({
  imports: [
    CommonModule,
    MaterialModule,
  ],
  declarations: [
    SideBarButtonComponent
  ],
  exports: [
    SideBarButtonComponent
  ]
})
export class SideBarButtonModule { }
