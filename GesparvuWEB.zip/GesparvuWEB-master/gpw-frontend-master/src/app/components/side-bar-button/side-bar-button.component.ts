import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-side-bar-button',
  templateUrl: './side-bar-button.component.html',
  styleUrls: ['./side-bar-button.component.scss']
})

export class SideBarButtonComponent implements OnInit {

  @Input() buttonText: string;
  @Input() buttonIcon: string;
  @Input() buttonClass: string;
  @Input() removeButtonClass: string;

  constructor() {}

  ngOnInit() {
  }
}
