import { DefaultImageContainerComponent } from './default-image-container.component';
import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { MaterialModule } from '../../material.module';

@NgModule({
  imports: [
    CommonModule,
    MaterialModule,
  ],
  declarations: [
    DefaultImageContainerComponent
  ],
  exports: [
    DefaultImageContainerComponent
  ]
})
export class DefaultImageContainerModule { }
