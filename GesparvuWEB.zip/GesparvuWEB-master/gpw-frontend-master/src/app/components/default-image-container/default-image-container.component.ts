import { IDefaultImageContainer } from './../../common/interfaces/default.interface';
import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-default-image-container',
  templateUrl: './default-image-container.component.html',
  styleUrls: ['./default-image-container.component.scss']
})
export class DefaultImageContainerComponent implements OnInit {

  @Input() containerInfo: IDefaultImageContainer;
  @Input() className: string;

  constructor() { }

  ngOnInit() { }

}
