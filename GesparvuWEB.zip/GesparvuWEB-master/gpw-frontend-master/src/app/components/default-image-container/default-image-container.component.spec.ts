import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { DefaultImageContainerComponent } from './default-image-container.component';
import { defaultImageContainerMock } from '../../mocks/component-params.mock';

describe('DefaultImageContainerComponent', () => {
  let component: DefaultImageContainerComponent;
  let fixture: ComponentFixture<DefaultImageContainerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DefaultImageContainerComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DefaultImageContainerComponent);
    component = fixture.componentInstance;
    component.containerInfo = defaultImageContainerMock;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
