import { IDefaultImageContainer } from './../../common/interfaces/default.interface';
import { Component, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';

@Component({
  selector: 'app-generic-modal',
  templateUrl: './generic-modal.component.html',
  styleUrls: ['./generic-modal.component.scss']
})
export class GenericModalComponent {

  modalData: IDefaultImageContainer;

  constructor(
    public dialogRef: MatDialogRef<any>,
    @Inject(MAT_DIALOG_DATA) public data: IDefaultImageContainer) {
      this.modalData = data;
    }

  closeModal(): void {
    this.dialogRef.close();
  }

}
