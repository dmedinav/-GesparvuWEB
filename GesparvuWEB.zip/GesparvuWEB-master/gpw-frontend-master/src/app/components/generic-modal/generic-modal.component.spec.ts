import { MaterialModule } from '../../material.module';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { GenericModalComponent } from './generic-modal.component';
import { SecondaryButtonModule } from '../secondary-button/secondary-button.module';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';

let matDialogRef = null;
let closeSpy: jasmine.Spy;

describe('GenericModalComponent', () => {
  let component: GenericModalComponent;
  let fixture: ComponentFixture<GenericModalComponent>;

  matDialogRef = jasmine.createSpyObj('MatDialogRef', ['close']);
  closeSpy = matDialogRef.close;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [GenericModalComponent],
      imports: [
        SecondaryButtonModule,
        MaterialModule
      ],
      providers: [
        { provide: MAT_DIALOG_DATA, useValue: {} },
        { provide: MatDialogRef, useValue: matDialogRef }
      ],
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GenericModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should close dialogRef', () => {
    component.closeModal();
    expect(closeSpy).toHaveBeenCalled();
  });
});
