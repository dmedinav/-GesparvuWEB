import { PrimaryButtonComponent } from './primary-button.component';
import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { MaterialModule } from '../../material.module';

@NgModule({
  imports: [
    CommonModule,
    MaterialModule,
  ],
  declarations: [
    PrimaryButtonComponent
  ],
  exports: [
    PrimaryButtonComponent
  ]
})
export class PrimaryButtonModule { }
