import { LOGIN_ROUTE } from './../../common/constants/routes.constants';
import { AuthService } from '@services/auth/auth.service';
import { Subscription } from 'rxjs';
import { SIDE_BAR_ROUTES_BUTTONS } from '../../common/constants/routes.constants';
import { Component, OnInit, Output, OnDestroy, Input } from '@angular/core';
import { Router, NavigationEnd } from '@angular/router';
import { ISideBarButton } from '../../common/interfaces/side-bar-button.interface';
import { EventEmitter } from '@angular/core';
import { SCREEN_WIDTH } from '../../common/constants/screen-width';
import { IUserInfo } from '../../common/interfaces/user-login.interface';

@Component({
  selector: 'app-side-bar',
  templateUrl: './side-bar.component.html',
  styleUrls: ['./side-bar.component.scss']
})
export class SideBarComponent implements OnInit, OnDestroy {

  @Output() menuToggle: EventEmitter<void>;
  @Input() userInfo: IUserInfo;
  buttons: ISideBarButton[];
  subscription: Subscription;
  lastMainRoute: string;

  constructor(public router: Router, private authService: AuthService) {
    this.menuToggle = new EventEmitter();
    this.buttons = JSON.parse(JSON.stringify(SIDE_BAR_ROUTES_BUTTONS));
    this.subscription = new Subscription();
    this.lastMainRoute = '';
  }

  ngOnInit() {
    this.subscription = this.router.events.subscribe((event: NavigationEnd) => {
      if (event instanceof NavigationEnd) { this.setCurrentButton(event.urlAfterRedirects); }
    });
    this.setCurrentButton(this.router.url, true);
  }

  public setCurrentButton(url: string, firstLoad: boolean = false) {
    url = url.substr(1).split('/')[1];
    for (const button of this.buttons) {
      const mainButtonRoute = button.route.substr(1).split('/')[1];
      if (mainButtonRoute === url) {
        button.class = 'selected';
        button.icon = button.selectedIcon;
        if (window.innerWidth <= SCREEN_WIDTH.TABLET && this.lastMainRoute !== url) {
          if (firstLoad) {
            setTimeout(() => { this.menuToggle.emit(); }, 0);
          } else {
            this.menuToggle.emit();
          }
        }
        this.lastMainRoute = url;
      } else {
        button.class = '';
        button.icon = button.unselectedIcon;
      }
    }
  }

  public navigateTo(button: ISideBarButton) {
    this.router.navigate([button.route]);
  }

  public signOut() {
    this.authService.signOut();
    this.router.navigateByUrl(LOGIN_ROUTE);
  }

  ngOnDestroy(): void {
    this.subscription.unsubscribe();
  }

}
