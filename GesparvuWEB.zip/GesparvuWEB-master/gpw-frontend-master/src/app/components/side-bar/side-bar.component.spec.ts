import { HttpClientModule } from '@angular/common/http';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { SideBarComponent } from './side-bar.component';
import { MaterialModule } from '../../material.module';
import { SideBarButtonModule } from '../side-bar-button/side-bar-button.module';
import { SecondaryButtonModule } from '../secondary-button/secondary-button.module';
import { Router, ActivatedRoute, convertToParamMap } from '@angular/router';
import { RouterMovementsMock, sideBarButtonMock } from '../..//mocks/router.mock';
import { DAILY_ATTENDANCE_ROUTE, LOGIN_ROUTE } from '../../common/constants/routes.constants';
import { SCREEN_WIDTH } from '../../common/constants/screen-width';

describe('SideBarComponent', () => {
  let component: SideBarComponent;
  let fixture: ComponentFixture<SideBarComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SideBarComponent ],
      imports: [
        MaterialModule,
        SideBarButtonModule,
        SecondaryButtonModule,
        HttpClientModule,
      ],
      providers: [
        { provide: ActivatedRoute, useValue: { snapshot: { } } },
        { provide: Router, useClass: RouterMovementsMock },
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    TestBed.get(ActivatedRoute).snapshot = { paramMap: convertToParamMap( { group: '3', year: 2019, month: 1 } ) };
    fixture = TestBed.createComponent(SideBarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should navigate to button route', () => {
    const spy = spyOn(component.router, 'navigate');
    component.navigateTo(sideBarButtonMock);
    expect(spy).toHaveBeenCalledWith([DAILY_ATTENDANCE_ROUTE]);
  });

  it('should navigate to button route and toogle the menu', () => {
    const spy = spyOn(component.router, 'navigate');
    (window as any).innerWidth = SCREEN_WIDTH.MOBILE;
    component.navigateTo(sideBarButtonMock);
    expect(spy).toHaveBeenCalledWith([DAILY_ATTENDANCE_ROUTE]);
  });

  it('should not set current button', () => {
    expect(component.buttons.filter(b => b.class === 'selected').length).toBe(1);
    const selectedButton = component.buttons.find(b => b.class === 'selected');
    component.buttons[0].route = 'routeMock';
    component.setCurrentButton(DAILY_ATTENDANCE_ROUTE);
    expect(component.buttons.filter(b => b.class === 'selected').length).toBe(1);
    expect(component.buttons.find(b => b.class === 'selected')).toBe(selectedButton);
  });

  it('should call navigateByUrl with login route', () => {
    // tslint:disable-next-line: no-string-literal
    const spy = spyOn(component['router'], 'navigateByUrl').and.returnValue(true);
    component.signOut();
    expect(spy).toHaveBeenCalledWith(LOGIN_ROUTE);
  });

});
