import { SideBarComponent } from './side-bar.component';
import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { SideBarButtonModule } from '../side-bar-button/side-bar-button.module';
import { SecondaryButtonModule } from '../secondary-button/secondary-button.module';
import { MaterialModule } from '../../material.module';

@NgModule({
  imports: [
    CommonModule,
    SideBarButtonModule,
    MaterialModule,
    SecondaryButtonModule,
  ],
  declarations: [
    SideBarComponent
  ],
  exports: [
    SideBarComponent
  ]
})
export class SideBarModule { }
