import { SecondaryButtonComponent } from './secondary-button.component';
import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { MaterialModule } from '../../material.module';

@NgModule({
  imports: [
    CommonModule,
    MaterialModule,
  ],
  declarations: [
    SecondaryButtonComponent
  ],
  exports: [
    SecondaryButtonComponent
  ]
})
export class SecondaryButtonModule { }
