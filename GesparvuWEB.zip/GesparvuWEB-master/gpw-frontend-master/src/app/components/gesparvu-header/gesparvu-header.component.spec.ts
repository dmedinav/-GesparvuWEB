import { HttpClientModule } from '@angular/common/http';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { GesparvuHeaderComponent } from './gesparvu-header.component';
import { SecondaryButtonModule } from '../secondary-button/secondary-button.module';
import { MaterialModule } from '../../material.module';
import { RouterTestingModule } from '@angular/router/testing';
import { LOGIN_ROUTE } from '../../common/constants/routes.constants';

describe('GesparvuHeaderComponent', () => {
  let component: GesparvuHeaderComponent;
  let fixture: ComponentFixture<GesparvuHeaderComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [
        GesparvuHeaderComponent,
      ],
      imports: [
        SecondaryButtonModule,
        MaterialModule,
        RouterTestingModule,
        HttpClientModule,
      ]
    })
    .compileComponents();
    fixture = TestBed.createComponent(GesparvuHeaderComponent);
    component = fixture.componentInstance;
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should have the logo classes', () => {
    let div = fixture.nativeElement.querySelector('.junji-logo');
    expect(div).toBeDefined();
    div = fixture.nativeElement.querySelector('.gesparvu-logo');
    expect(div).toBeDefined();
  });

  it('should toggle sidenav', () => {
    const a = fixture.nativeElement.querySelector('.noselect');
    const spy = spyOn(component.menuToggle, 'emit').and.callThrough();
    a.click();
    expect(spy).toHaveBeenCalled();
  });

  it('should call navigateByUrl with login route', () => {
    // tslint:disable-next-line: no-string-literal
    const spy = spyOn(component['router'], 'navigateByUrl').and.returnValue(true);
    component.signOut();
    expect(spy).toHaveBeenCalledWith(LOGIN_ROUTE);
  });

});
