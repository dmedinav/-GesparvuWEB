import { IUserInfo } from './../../common/interfaces/user-login.interface';
import { LOGIN_ROUTE } from './../../common/constants/routes.constants';
import { AuthService } from './../../services/auth/auth.service';
import { Component, OnInit, Output, Input } from '@angular/core';
import { EventEmitter } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-gesparvu-header',
  templateUrl: './gesparvu-header.component.html',
  styleUrls: ['./gesparvu-header.component.scss']
})
export class GesparvuHeaderComponent implements OnInit {

  @Output() menuToggle: EventEmitter<void>;
  @Input() headerIcon: string;
  @Input() userInfo: IUserInfo;

  constructor(private authService: AuthService, private router: Router) {
    this.menuToggle = new EventEmitter();
    this.headerIcon = 'clear';
  }

  ngOnInit() {
  }

  public toggleSidenav() {
    this.menuToggle.emit();
  }

  public signOut() {
    this.authService.signOut();
    this.router.navigateByUrl(LOGIN_ROUTE);
  }

}
