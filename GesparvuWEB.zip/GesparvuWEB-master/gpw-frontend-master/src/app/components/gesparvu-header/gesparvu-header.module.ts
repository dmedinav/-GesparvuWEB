import { GesparvuHeaderComponent } from './gesparvu-header.component';
import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { SecondaryButtonModule } from '../secondary-button/secondary-button.module';
import { MaterialModule } from '../../material.module';

@NgModule({
  imports: [
    CommonModule,
    SecondaryButtonModule,
    MaterialModule,
  ],
  declarations: [
    GesparvuHeaderComponent
  ],
  exports: [
    GesparvuHeaderComponent
  ]
})
export class GesparvuHeaderModule { }
