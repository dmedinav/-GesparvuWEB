import { Component, OnInit, Renderer2, Inject } from '@angular/core';
import { DOCUMENT } from '@angular/common';
import { Router, NavigationEnd } from '@angular/router';
import { GA_MEASUREMENT_ID } from 'app/common/constants/default.constants';
import { GoogleAnalyticsService } from './services/google-analytics/google-analytics.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
})

export class AppComponent implements OnInit {
  constructor(
    private _renderer2: Renderer2,
    private router: Router,
    public gaService: GoogleAnalyticsService,
    @Inject(DOCUMENT) private _document: Document
  ) {
    this.router.events.subscribe(event => {
      if (event instanceof NavigationEnd) {
        this.gaService.sendPageview(event.urlAfterRedirects);
      }
    });
  }

  public ngOnInit() {
    // Create `script` element for google tag manager source code
    const googleTagManagerSourceScript = this._renderer2.createElement('script');
    googleTagManagerSourceScript.type = 'text/javascript';
    googleTagManagerSourceScript.async = true;
    googleTagManagerSourceScript.src = `https://www.googletagmanager.com/gtag/js?id=${GA_MEASUREMENT_ID}`;

    // Create `script` element for declaration of gtag function for google analytics measurement
    const gtagDeclarationScript = this._renderer2.createElement('script');
    gtagDeclarationScript.type = 'text/javascript';
    gtagDeclarationScript.text = `
      window.dataLayer = window.dataLayer || [];
      function gtag(){dataLayer.push(arguments);}
      gtag('js', new Date());
    `;

    // Add them `body` element
    this._renderer2.appendChild(this._document.body, googleTagManagerSourceScript);
    this._renderer2.appendChild(this._document.body, gtagDeclarationScript);
 }
}
