
 
## Description

  

This project contains all the endpoints for the JUNJI-RAD webapp

  

## Initial setup
### Setup on dockerized environment
This project uses a custom setup in a specific docker instance. You can check
that setup on the `Dockerfile` on the root.

### Local setup for development
If you're running the project on your local environment and not on the previously set up docker instance, you need to do some few extra steps.

#### Requirements
* Postgres SQL (Recommended version: 10.x)
* nvm (Setup instructions [here](https://medium.com/@nbanzyme/easy-way-to-install-nvm-on-ubuntu-18-04-2cfb19ee5391))

#### 1. Create development DB
```
    $ sudo -u postgres psql
    postgres=# drop database "gesparvu-dev";
    postgres=# create database "gesparvu-dev";
    postgres=# create user junji with password 'junjipwd';
    postgres=# grant all privileges on database "gesparvu-dev" to junji;
```

#### 2. Create `.env` file on the root
You can copy the example file `.env.example`, changing its extension.

#### 3. Run environment file
```
    $ source .env
```

Now you are ready to proceed with the installation!

## Installation

  

```bash

$ npm install

```

  

## Running the app

  

```bash

# development

$ npm run start

  

# watch mode

$ npm run start:dev

  

# production mode

$ npm run start:prod

```

  

## Test

  

```bash

# unit tests

$ npm run test

  

# e2e tests

$ npm run test:e2e

  

# test coverage

$ npm run test:cov

```