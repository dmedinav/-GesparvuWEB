# Change Log
All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](http://keepachangelog.com/)
and this project adheres to [Semantic Versioning](http://semver.org/).

## 0.6.0 - 2019-08-13

### Added
- Service for monthly attendance.
- Services for period logic.
- Update Excel export logic.
- Services for enrollment creation.
- Unit test for new services.

## 0.5.0 - 2019-07-26

### Added
- Service for calendar information.
- Services for export monthly attendance in excel.
- Excel fill logic.
- Unit test for new services (except excel fill).


## 0.4.0 - 2019-07-15

### Added
- Service for movement types.
- Service for enrollment search.
- Service for movement creation.
- LDAP Authentication.
- Guard for all endpoints.

### Changed
- Error handling.
- Logging service.

## 0.3.0 - 2019-06-25

### Added
- Service for daily enrollment with attendance.
- Unit test for new services.
- Add log service for unhandled exceptions.

## 0.2.0 - 2019-06-14

### Added
- Service for exception type.
- Unit test in newly created elements.
- Synchronize attendance code with database table.
- Interceptors for attendance code injection.
- Service for exception creation.
- Functions for holidays by group.
- Holiday, Exception, Attendance Type and Exception Type entity creation.

## 0.1.0 - 2019-06-04

### Added
- Unit test in services, providers and controllers
- Validation, pipes and DTOs for necessary endpoints.
- Service for update SIGE dictionary in attendance table.
- Service for enrollments by group id, including its attendances.
- Service for establishments and groups by county id. 
- Services for regions, provinces and counties.
- Project base and setup.