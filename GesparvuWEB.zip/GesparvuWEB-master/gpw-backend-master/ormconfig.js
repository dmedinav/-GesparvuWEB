const defaultConnection = {
    name: 'default',
    type: 'postgres',
    host: process.env.JUNJI_RAD_POSTGRES_HOST || '127.0.0.1',
    port: Number(process.env.JUNJI_RAD_POSTGRES_PORT || 5432),
    username: process.env.JUNJI_RAD_POSTGRES_USER,
    password: process.env.JUNJI_RAD_POSTGRES_PASSWORD,
    database: process.env.JUNJI_RAD_POSTGRES_DBNAME || 'gesparvu-dev',
    migrations: [
      `${process.env.ORM_MIGRATIONS_FOLDER}/database/migrations/*.ts`,
    ],
    cli: {
        migrationsDir: 'src/database/migrations',
    },
    entities: [
      `${process.env.ORM_MIGRATIONS_FOLDER}/**/*.entity{.ts,.js}`,
    ],
    synchronize: false,
    migrationsRun: true,
    ssl: true,
  }
  
const migrationConnection = {
...defaultConnection,
migrations: [`${process.env.ORM_MIGRATIONS_FOLDER}/**/database/migrations/*.ts`],
entities: [`${process.env.ORM_MIGRATIONS_FOLDER}/**/*.entity{.ts,.js}`],
name: 'migration',
}
  
module.exports = [defaultConnection, migrationConnection];
  