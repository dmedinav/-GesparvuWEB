import { ExceptionCreationDto } from './dto/exception.dto';
import { ExceptionProvider } from './exception.provider';
import { Controller, Post, Body, UseGuards, Get, Query } from '@nestjs/common';
import { AuthGuard } from '@nestjs/passport';
import { ExceptionCalendarDto } from './dto/exception-calendar.dto';

@Controller('exceptions')
export class ExceptionController {

  constructor(private exceptionProvider: ExceptionProvider) { }

  @UseGuards(AuthGuard('jwt'))
  @Post()
  public createException(@Body() request: ExceptionCreationDto): Promise<any> {
    return this.exceptionProvider.createException(request);
  }

  @UseGuards(AuthGuard('jwt'))
  @Get('/calendar')
  public getExceptionsCalendar(@Query() queryParams: ExceptionCalendarDto): any {
    return this.exceptionProvider.getExceptionsCalendar(
      queryParams.month,
      queryParams.year,
      queryParams.group,
    );
  }
}
