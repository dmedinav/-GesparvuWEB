import { AttendanceModule } from './../attendance/attendance.module';
import { AttendanceTypeModule } from './../../database/entities/attendanceType/attendance-type.module';
import { HolidayModule } from './../../database/entities/holiday/holiday.module';
import { ExceptionProvider } from './exception.provider';
import { Exception } from '../../database/entities/exception/exception.entity';
import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { ExceptionService } from '../../database/entities/exception/exception.service';
import { ExceptionController } from './exception.controller';
import { TransactionService } from '../../database/transaction/transaction.service';
import { AuthModule } from '../auth/auth.module';
import { GroupService } from '../../database/entities/group/group.service';
import { PeriodModule } from '../../database/entities/period/period.module';

@Module({
  imports: [TypeOrmModule.forFeature([Exception]), HolidayModule, AttendanceTypeModule, AttendanceModule, AuthModule, PeriodModule],
  exports: [ExceptionService],
  controllers: [ExceptionController],
  providers: [ExceptionService, ExceptionProvider, TransactionService, GroupService],
})
export class ExceptionModule { }
