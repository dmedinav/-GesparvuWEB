import { exceptionCreationDtoMock, getExceptionsParamsDtoMock } from '../../common/mocks/exception';
import { DEFAULT_SUCCESSFUL_POST_RESPONSE } from './../../common/constants/response-messages';
import { Test, TestingModule } from '@nestjs/testing';
import { ExceptionController } from './exception.controller';
import { ExceptionProvider } from './exception.provider';

describe('Exception Controller', () => {
  let controller: ExceptionController;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [ExceptionController],
      providers: [
        {
          provide: ExceptionProvider, useValue: {
            createException: () => undefined,
            getExceptionsCalendar: () => undefined,
          },
        },
      ],
    }).compile();

    controller = module.get<ExceptionController>(ExceptionController);
  });

  it('should be defined', () => {
    expect(controller).toBeDefined();
  });

  it('createException should return an object when is requested.', async () => {
    // tslint:disable-next-line:no-string-literal
    spyOn(controller['exceptionProvider'], 'createException').and.returnValue(Promise.resolve(DEFAULT_SUCCESSFUL_POST_RESPONSE));
    expect(await controller.createException(exceptionCreationDtoMock)).toEqual(DEFAULT_SUCCESSFUL_POST_RESPONSE);
  });

  it('getExceptionsCalendar should return an array of CalendarException', async () => {
    // tslint:disable-next-line:no-string-literal
    spyOn(controller['exceptionProvider'], 'getExceptionsCalendar').and.returnValue(Promise.resolve([]));
    expect(await controller.getExceptionsCalendar(getExceptionsParamsDtoMock)).toEqual([]);
  });

});
