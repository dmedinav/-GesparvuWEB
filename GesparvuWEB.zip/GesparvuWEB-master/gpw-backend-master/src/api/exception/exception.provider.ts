import { AttendanceType } from './../../database/entities/attendanceType/attendance-type.entity';
import { Attendance } from './../../database/entities/attendance/attendance.entity';
import { IRREVOCABLE_HOLIDAY_MESSAGE, RETRIEVING_ERROR_MESSAGE, DEFAULT_SUCCESSFUL_POST_RESPONSE } from './../../common/constants/response-messages';
import { AttendanceInformationDto } from './../attendance/dto/attendance-creation.dto';
import { AttendanceService } from './../../database/entities/attendance/attendance.service';
import { AttendanceTypeService } from './../../database/entities/attendanceType/attendance-type.service';
import { Exception } from './../../database/entities/exception/exception.entity';
import { ExceptionCreationDto } from './dto/exception.dto';
import { Holiday } from './../../database/entities/holiday/holiday.entity';
import { EXCEPTION_CREATION_ORDER, IRREVOCABLE_DESCRIPTION } from './../../common/constants/exceptions';
import { HolidayService } from './../../database/entities/holiday/holiday.service';
import { ExceptionService } from './../../database/entities/exception/exception.service';
import { Injectable } from '@nestjs/common';
import Utils from '../../common/utils/utils';
import { IRREVOCABLE_HOLIDAY } from '../../common/constants/response-codes';
import { BadRequestException } from '../../common/exceptionFilters/custom-exceptions';
import { TransactionService } from '../../database/transaction/transaction.service';
import { IQueryTransaction } from '../../common/interfaces/query-transaction.interface';
import { IExceptionCalendar } from '../../common/interfaces/exception-calendar.interface';

@Injectable()
export class ExceptionProvider {

  constructor(
    private readonly exceptionService: ExceptionService,
    private readonly holidayService: HolidayService,
    private readonly attendanceTypeService: AttendanceTypeService,
    private readonly attendanceService: AttendanceService,
    private readonly transactionService: TransactionService,
  ) { }

  public async createException(request: ExceptionCreationDto) {
    const { date, group, exceptionType, description } = request;
    const exception = { date, group, exceptionType, description, country: false } as unknown as Exception;
    const realDate = new Date(date);
    const month = realDate.getUTCMonth() + 1;
    const year = realDate.getUTCFullYear();
    return Promise.all([
      this.attendanceTypeService.getAttendanceTypesForExceptionType(exceptionType),
      this.attendanceService.getAttendancesForGroupInDate(group, month, year),
      this.holidayService.getHolidaysForGroupInDate(request.group, realDate),
    ])
      .then(async ([attendanceType, attendances, holidays]) => {
        if (attendanceType && attendances && holidays) {
          this.validateIrrevocableHoliday(holidays);
          const queryArray = this.updateAttendanceObject(attendances, attendanceType, realDate);
          queryArray.push(this.exceptionService.createException(exception) as unknown as IQueryTransaction);
          await this.transactionService.executeTransaction(queryArray);
          return DEFAULT_SUCCESSFUL_POST_RESPONSE;
        }
        throw new BadRequestException(undefined, RETRIEVING_ERROR_MESSAGE);
      });
  }

  public async getExceptionsCalendar(month: number, year: number, group: number): Promise<IExceptionCalendar[]> {
    let exceptions: IExceptionCalendar[] = await this.exceptionService.getExceptionsByMonthAndGroup(month, year, group);
    const holidays: IExceptionCalendar[] = await this.holidayService.getHolidaysByMonthAndGroup(month, year, group);

    exceptions = this.removeOverridedExceptions(exceptions);
    return this.removeOverridedExceptionsHolidays(exceptions, this.addIrrevocableDescription(holidays));
  }

  public addIrrevocableDescription(exceptions: IExceptionCalendar[]) {
    for (const exception of exceptions) {
      if (exception.irrevocable) {
        exception.description += IRREVOCABLE_DESCRIPTION;
      }
    }
    return exceptions;
  }

  public removeOverridedExceptionsHolidays(exceptions: IExceptionCalendar[], holidays: IExceptionCalendar[]): IExceptionCalendar[] {
    const unique: IExceptionCalendar[] = [];
    let isSameDay = false;
    for (const exception of exceptions) {
      isSameDay = false;
      for (const holiday of holidays) {
        if (exception.date.getUTCDate() === holiday.date.getUTCDate()) {
          isSameDay = true;
          if (holiday.irrevocable) {
            unique.push(holiday);
          } else {
            unique.push(exception);
          }
          holidays = holidays.filter(h => h !== holiday);
        } else if (holiday.date.getUTCDate() < exception.date.getUTCDate()) {
          unique.push(holiday);
          holidays = holidays.filter(h => h !== holiday);
        } else {
          break;
        }
      }
      if (!isSameDay) {
        unique.push(exception);
      }
    }

    return unique.concat(holidays);
  }

  public removeOverridedExceptions(exceptions: IExceptionCalendar[]): IExceptionCalendar[] {
    const unique: IExceptionCalendar[] = [];
    exceptions.sort((a, b) => (a.timestamp < b.timestamp) ? 1 : -1);
    for (const exception of exceptions) {
      const listedExeption = unique.find(e => e.date.getUTCDate() === exception.date.getUTCDate());
      if (!listedExeption) { unique.push(exception); }
    }
    unique.sort((a, b) => (a.date > b.date) ? 1 : -1);
    return unique;
  }

  public validateIrrevocableHoliday(holidays: Holiday[]) {
    for (const element of EXCEPTION_CREATION_ORDER) {
      const innerHolidays: Holiday[] = Utils.findObjectsInObjectArray(holidays, element);
      if (innerHolidays.length > 0) {
        const innerHoliday: Holiday = Utils.findNewestDateInObjectArray(innerHolidays, 'timestamp');
        if (innerHoliday.irrevocable) {
          throw new BadRequestException(IRREVOCABLE_HOLIDAY, IRREVOCABLE_HOLIDAY_MESSAGE);
        }
        break;
      }
    }
  }

  public updateAttendanceObject(attendances: Attendance[], attendanceType: AttendanceType, realDate: Date) {
    const day = realDate.getUTCDate();
    const queryArray: IQueryTransaction[] = [];
    const attendanceExceptionDay = {
      [day]: attendanceType.sigeCode,
    };
    for (const attendance of attendances) {
      attendance.attendance = Object.assign(JSON.parse(attendance.attendance), attendanceExceptionDay);
      const attendanceInformation = attendance as unknown as AttendanceInformationDto;
      queryArray.push(this.attendanceService.updateAttendanceObject(attendanceInformation) as unknown as IQueryTransaction);
    }
    return queryArray;
  }

}
