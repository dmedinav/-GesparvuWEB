import { IsString, IsInt, IsDateString } from 'class-validator';

export class ExceptionCreationDto {
  @IsString()
  readonly description: string;

  @IsInt()
  readonly exceptionType: number;

  @IsDateString()
  readonly date: Date;

  @IsInt()
  readonly group: number;
}
