import { IsInt, Min, Max, IsPositive } from 'class-validator';
import { Type } from 'class-transformer';

export class ExceptionCalendarDto {

    @Type(/* istanbul ignore next */() => Number)
    @Min(1)
    @Max(12)
    @IsInt()
    readonly month: number;

    @Type(/* istanbul ignore next */() => Number)
    @IsInt()
    @IsPositive()
    readonly year: number;

    @Type(/* istanbul ignore next */() => Number)
    @IsInt()
    @IsPositive()
    readonly group: number;
}
