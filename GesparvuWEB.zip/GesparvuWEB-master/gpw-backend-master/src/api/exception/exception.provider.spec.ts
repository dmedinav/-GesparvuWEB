import { IRREVOCABLE_HOLIDAY } from './../../common/constants/response-codes';
import { DEFAULT_SUCCESSFUL_POST_RESPONSE, IRREVOCABLE_HOLIDAY_MESSAGE, RETRIEVING_ERROR_MESSAGE } from './../../common/constants/response-messages';
import {
  exceptionCreationDtoMock,
  exceptionsCalendarOnlyExceptionsMock,
  exceptionsCalendarOnlyExceptionsResultMock,
  exceptionsCalendarResultMock,
  getExceptionsParamsDtoMock,
  exceptionsCalendarHolidaysFinalMock,
  exceptionAMock,
  exceptionBMock,
  exceptionDMock,
} from './../../common/mocks/exception';
import { attendanceTypeMock } from '../../common/mocks/attendance-type';
import { AttendanceService } from './../../database/entities/attendance/attendance.service';
import { AttendanceTypeService } from './../../database/entities/attendanceType/attendance-type.service';
import { HolidayService } from './../../database/entities/holiday/holiday.service';
import { ExceptionService } from './../../database/entities/exception/exception.service';
import { Test, TestingModule } from '@nestjs/testing';
import { ExceptionProvider } from './exception.provider';
import {
  notIrrevocableGroupHolidayMock,
  irrevocableEstablishmentHolidayMock,
  irrevocableGroupHolidayMock,
  notIrrevocableEstablishmentHolidayMock,
  irrevocableGroupHolidayYesterdayMock,
} from '../../common/mocks/holiday';
import { BadRequestException } from '../../common/exceptionFilters/custom-exceptions';
import { attendanceWithMonthlyAttendanceMock } from '../../common/mocks/attendance';
import { TransactionService } from '../../database/transaction/transaction.service';

// tslint:disable:no-string-literal
describe('ExceptionProvider', () => {
  let provider: ExceptionProvider;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [
        ExceptionProvider,
        {
          provide: ExceptionService,
          useValue: {
            createException: () => {/**/ },
            getExceptionsByMonthAndGroup: () => {/**/ },
          },
        },
        {
          provide: HolidayService,
          useValue: {
            getHolidaysForGroupInDate: () => {/**/ },
            getHolidaysByMonthAndGroup: () => {/**/ },
          },
        },
        {
          provide: AttendanceTypeService,
          useValue: {
            getAttendanceTypesForExceptionType: () => {/**/ },
          },
        },
        {
          provide: AttendanceService,
          useValue: {
            getAttendancesForGroupInDate: () => {/**/ },
            updateAttendanceObject: () => {/**/ },
          },
        },
        {
          provide: TransactionService,
          useValue: {
            executeTransaction: () => {/**/ },
          },
        },
      ],
    }).compile();

    provider = module.get<ExceptionProvider>(ExceptionProvider);
  });

  it('should be defined', () => {
    expect(provider).toBeDefined();
  });

  describe('getExceptionsCalendar tests', () => {
    it('removeOverridedExceptions should return an array', () => {
      expect(provider.removeOverridedExceptions(exceptionsCalendarOnlyExceptionsMock)).toEqual(exceptionsCalendarOnlyExceptionsResultMock);
    });

    it('removeOverridedExceptions should return an array sorted by date', () => {
      expect(provider.removeOverridedExceptions([exceptionBMock, exceptionAMock, exceptionDMock]))
      .toEqual([exceptionAMock, exceptionBMock, exceptionDMock]);
    });

    it('removeOverridedExceptionsHolidays should return an array', () => {
      expect(provider.removeOverridedExceptionsHolidays(exceptionsCalendarOnlyExceptionsResultMock, exceptionsCalendarHolidaysFinalMock))
         .toEqual(exceptionsCalendarResultMock);
    });

    it('removeOverridedExceptionsHolidays should return exceptions A and B', () => {
      expect(provider.removeOverridedExceptionsHolidays([exceptionAMock], [exceptionBMock]))
         .toEqual([exceptionAMock, exceptionBMock]);
    });

    it('getExceptionsCalendar should return an array', async () => {
      spyOn(provider['exceptionService'], 'getExceptionsByMonthAndGroup').
        and.returnValue(exceptionsCalendarOnlyExceptionsMock);

      spyOn(provider['holidayService'], 'getHolidaysByMonthAndGroup').
        and.returnValue(exceptionsCalendarHolidaysFinalMock);

      expect(await provider.getExceptionsCalendar(
        getExceptionsParamsDtoMock.month,
        getExceptionsParamsDtoMock.year,
        getExceptionsParamsDtoMock.group,
      )).toEqual(provider.addIrrevocableDescription(exceptionsCalendarResultMock));
    });
  });

  describe('createException tests', () => {
    beforeEach(async () => {
      spyOn(provider['attendanceService'], 'getAttendancesForGroupInDate').
        and.returnValue(Promise.resolve([{ ...attendanceWithMonthlyAttendanceMock }]));
    });

    it('createException should return OK if holiday is group and not irrevocable', async () => {
      spyOn(provider['attendanceTypeService'], 'getAttendanceTypesForExceptionType').
        and.returnValue(Promise.resolve(attendanceTypeMock));
      spyOn(provider['holidayService'], 'getHolidaysForGroupInDate').
        and.returnValue(Promise.resolve([notIrrevocableGroupHolidayMock]));
      spyOn(provider['attendanceService'], 'updateAttendanceObject').
        and.returnValue(Promise.resolve({}));
      spyOn(provider['exceptionService'], 'createException').
        and.returnValue(Promise.resolve({}));

      expect(await provider.createException(exceptionCreationDtoMock)).toEqual(DEFAULT_SUCCESSFUL_POST_RESPONSE);
    });

    it('createException should return OK if holiday is group and not irrevocable no matter the establishment holiday', async () => {
      spyOn(provider['attendanceTypeService'], 'getAttendanceTypesForExceptionType').
        and.returnValue(Promise.resolve(attendanceTypeMock));
      spyOn(provider['holidayService'], 'getHolidaysForGroupInDate').
        and.returnValue(Promise.resolve([notIrrevocableGroupHolidayMock, irrevocableEstablishmentHolidayMock]));
      spyOn(provider['attendanceService'], 'updateAttendanceObject').
        and.returnValue(Promise.resolve({}));
      spyOn(provider['exceptionService'], 'createException').
        and.returnValue(Promise.resolve({}));

      expect(await provider.createException(exceptionCreationDtoMock)).toEqual(DEFAULT_SUCCESSFUL_POST_RESPONSE);
    });

    it('createException should return OK if holiday is group and both irrevocables with array of holidays', async () => {
      spyOn(provider['attendanceTypeService'], 'getAttendanceTypesForExceptionType').
        and.returnValue(Promise.resolve(attendanceTypeMock));
      spyOn(provider['holidayService'], 'getHolidaysForGroupInDate').
        and.returnValue(Promise.resolve([irrevocableGroupHolidayYesterdayMock, notIrrevocableGroupHolidayMock]));
      spyOn(provider['attendanceService'], 'updateAttendanceObject').
        and.returnValue(Promise.resolve({}));
      spyOn(provider['exceptionService'], 'createException').
        and.returnValue(Promise.resolve({}));

      expect(await provider.createException(exceptionCreationDtoMock)).toEqual(DEFAULT_SUCCESSFUL_POST_RESPONSE);
    });

    it('createException should return BadRequest if holiday is irrevocable in establishment without group', async () => {
      spyOn(provider['attendanceTypeService'], 'getAttendanceTypesForExceptionType').
        and.returnValue(Promise.resolve(attendanceTypeMock));
      spyOn(provider['holidayService'], 'getHolidaysForGroupInDate').
        and.returnValue(Promise.resolve([irrevocableEstablishmentHolidayMock]));

      await provider.createException(exceptionCreationDtoMock).catch((error) => expect(error)
        .toEqual(new BadRequestException(IRREVOCABLE_HOLIDAY, IRREVOCABLE_HOLIDAY_MESSAGE)));
    });

    it('createException should return BadRequest if holiday is irrevocable in group', async () => {
      spyOn(provider['attendanceTypeService'], 'getAttendanceTypesForExceptionType').
        and.returnValue(Promise.resolve(attendanceTypeMock));
      spyOn(provider['holidayService'], 'getHolidaysForGroupInDate').
        and.returnValue(Promise.resolve([irrevocableGroupHolidayMock, notIrrevocableEstablishmentHolidayMock]));

      await provider.createException(exceptionCreationDtoMock).catch((error) => expect(error)
        .toEqual(new BadRequestException(IRREVOCABLE_HOLIDAY, IRREVOCABLE_HOLIDAY_MESSAGE)));
    });

    it('createException should return BadRequest attendanceType is null', async () => {
      spyOn(provider['attendanceTypeService'], 'getAttendanceTypesForExceptionType').
        and.returnValue(Promise.resolve(null));

      spyOn(provider['holidayService'], 'getHolidaysForGroupInDate').
        and.returnValue(Promise.resolve([irrevocableGroupHolidayMock, notIrrevocableEstablishmentHolidayMock]));

      await provider.createException(exceptionCreationDtoMock).catch((error) => expect(error)
        .toEqual(new BadRequestException(undefined, RETRIEVING_ERROR_MESSAGE)));
    });
  });
});
