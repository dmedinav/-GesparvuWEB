import { Test, TestingModule } from '@nestjs/testing';
import { SexualityProvider } from './sexuality.provider';
import { SexualityService } from '../../database/entities/sexuality/sexuality.service';

// tslint:disable:no-string-literal
describe('SexualityProvider', () => {
  let provider: SexualityProvider;
  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [
        SexualityProvider,
        {
          provide: SexualityService,
          useValue: {
            getAll: () => {/**/ },
          },
        },
      ],
    }).compile();
    provider = module.get<SexualityProvider>(SexualityProvider);
  });

  it('should be defined', () => {
    expect(provider).toBeDefined();
  });

  it('should return an ISexuality array', async () => {
    await provider.getSexualities().then(mock => {
      expect(mock).toEqual(undefined);
    });
  });

});
