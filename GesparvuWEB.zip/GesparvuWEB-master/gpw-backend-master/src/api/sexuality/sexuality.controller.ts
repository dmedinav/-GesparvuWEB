import { Controller, Get, UseGuards } from '@nestjs/common';
import { AuthGuard } from '@nestjs/passport';
import { SexualityProvider } from './sexuality.provider';
import { Sexuality } from '../../database/entities/sexuality/sexuality.entity';

@Controller('sexualities')
export class SexualityController {
  constructor(private sexualityProvider: SexualityProvider) { }

  @UseGuards(AuthGuard('jwt'))
  @Get()
  public getSexualities(): Promise<Sexuality[]> {
    return this.sexualityProvider.getSexualities();
  }
}
