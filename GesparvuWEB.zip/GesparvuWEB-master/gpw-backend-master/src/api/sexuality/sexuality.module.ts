import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { Sexuality } from '../../database/entities/sexuality/sexuality.entity';
import { SexualityService } from '../../database/entities/sexuality/sexuality.service';
import { SexualityController } from './sexuality.controller';
import { SexualityProvider } from './sexuality.provider';

@Module({
  imports: [TypeOrmModule.forFeature([Sexuality])],
  providers: [SexualityService, SexualityProvider],
  controllers: [SexualityController],
  exports: [SexualityService],
})
export class SexualityModule {}
