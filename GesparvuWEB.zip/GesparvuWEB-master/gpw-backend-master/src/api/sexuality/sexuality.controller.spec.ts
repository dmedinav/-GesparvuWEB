import { Test, TestingModule } from '@nestjs/testing';
import { SexualityController } from './sexuality.controller';
import { SexualityProvider } from './sexuality.provider';
import { SexualityService } from '../../database/entities/sexuality/sexuality.service';

describe('Sexuality Controller', () => {
  let controller: SexualityController;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [SexualityController],
      providers: [
        SexualityService,
        {
          provide: 'SexualityRepository',
          useValue: {
            find: () => {/**/},
          },
        },
        {
          provide: SexualityProvider, useValue: {
            getSexualities: () => undefined,
          },
        },
      ],
    }).compile();

    controller = module.get<SexualityController>(SexualityController);
  });

  it('should be defined', () => {
    expect(controller).toBeDefined();
  });

  it('should return an array.', async () => {
    // tslint:disable-next-line:no-string-literal
    spyOn(controller['sexualityProvider'], 'getSexualities').and.returnValue(Promise.resolve([{}]));
    expect(await controller.getSexualities()).toEqual([{}]);
  });

});
