import { Injectable } from '@nestjs/common';
import { SexualityService } from '../../database/entities/sexuality/sexuality.service';
import { Sexuality } from '../../database/entities/sexuality/sexuality.entity';

@Injectable()
export class SexualityProvider {
  constructor(private readonly sexualityService: SexualityService) { }

  public async getSexualities(): Promise<Sexuality[]> {
    return await this.sexualityService.getAll();
  }

}
