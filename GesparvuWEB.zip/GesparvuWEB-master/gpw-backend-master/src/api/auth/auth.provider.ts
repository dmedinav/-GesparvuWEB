import { UNAUTHORIZED_ERROR_MESSAGE } from '../../common/constants/response-messages';
import { UnauthorizedException, BadGatewayException } from '../../common/exceptionFilters/custom-exceptions';
import { LogService } from '../../common/logs/logs.service';
import { JwtService } from '@nestjs/jwt';
import { Injectable } from '@nestjs/common';
import { JwtPayload } from '../../common/interfaces/jwt-payload.interface';
import { Client } from 'ldapts';
import { InvalidCredentialsError } from 'ldapts/errors';
import { LoginDto } from './dto/login.dto';
import { ViewAuthTeacherService } from '../../database/entities/viewAuthTeacher/view-auth-teacher.service';

@Injectable()
export class AuthProvider {

  ldapUrl: string;
  ldapGroup: string;
  ldapMasterUser: string;
  ldapMasterPassword: string;
  ldapSearchField: string;

  constructor(
    private readonly jwtService: JwtService,
    private readonly logService: LogService,
    private readonly viewAuthTeacherService: ViewAuthTeacherService,
  ) {
    this.ldapUrl = process.env.LDAP_URL;
    this.ldapGroup = process.env.LDAP_GROUP;
    this.ldapMasterUser = `CN=${process.env.LDAP_MASTER_USR},${this.ldapGroup}`;
    this.ldapMasterPassword = process.env.LDAP_MASTER_USR_PASS;
    this.ldapSearchField = process.env.LDAP_FIELD_USR;
  }

  async signIn(request: LoginDto): Promise<string> {
    const lowerCaseUsername = request.username.toLocaleLowerCase();
    const result = await this.ldapValidation(lowerCaseUsername, request.password);
    if (!result) {
      throw new UnauthorizedException(undefined, UNAUTHORIZED_ERROR_MESSAGE);
    }
    const userData = await this.viewAuthTeacherService.findLdapUserInformation(lowerCaseUsername);
    const user: JwtPayload = {
      email: lowerCaseUsername,
      rut: userData ? userData.rut : null,
      establishmentName: userData ? userData.establishmentName : null,
      teacherName: userData ? userData.teacherName : null,
    };
    return this.jwtService.sign(user);
  }

  async validateUser(jwt: JwtPayload): Promise<any> {
    return jwt;
  }

  async ldapValidation(email: string, password: string) {
    const client = new Client({
      url: this.ldapUrl,
      connectTimeout: 10000,
      timeout: 10000,
    });
    let isAuthenticated: boolean;
    try {
      await client.bind(this.ldapMasterUser, this.ldapMasterPassword);
      this.logService.verbose('Successful bind with master LDAP');
    } catch (ex) {
      this.logService.error('Binding error with master LDAP', ex.message, 'auth/login');
      await client.unbind();
      throw new BadGatewayException();
    }

    try {
      const filter = `(${this.ldapSearchField}=${email})`;
      const {
        searchEntries,
      } = await client.search(this.ldapGroup, {
        scope: 'sub',
        filter,
      });
      if (!searchEntries || searchEntries.length !== 1) {
        this.logService.verbose('LDAP search without results');
        return false;
      }
      await client.bind(searchEntries[0].dn, password);
      isAuthenticated = true;
      this.logService.verbose(`Successful login for: ${email}`);
    } catch (ex) {
      if (ex instanceof InvalidCredentialsError) {
        this.logService.verbose('Invalid credentials');
      } else {
        this.logService.error('Login error', ex.message, 'auth/login');
        throw new BadGatewayException();
      }
      isAuthenticated = false;
    } finally {
      await client.unbind();
    }
    return isAuthenticated;
  }
}
