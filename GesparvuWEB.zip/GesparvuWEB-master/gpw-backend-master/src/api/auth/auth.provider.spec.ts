import { Test, TestingModule } from '@nestjs/testing';
import { AuthProvider } from './auth.provider';
import { ViewAuthTeacherService } from '../../database/entities/viewAuthTeacher/view-auth-teacher.service';
import { LogService } from '../../common/logs/logs.service';
import { PassportModule } from '@nestjs/passport';
import { JwtModule } from '@nestjs/jwt';
import {
  BadGatewayException,
  UnauthorizedException,
} from '../../common/exceptionFilters/custom-exceptions';
import { UNAUTHORIZED_ERROR_MESSAGE } from '../../common/constants/response-messages';
import { JwtPayload } from '../../common/interfaces/jwt-payload.interface';
import { Client } from 'ldapts';
import { InvalidCredentialsError } from 'ldapts/errors';

jest.mock('ldapts');
// tslint:disable:no-string-literal
describe('Auth', () => {
  let provider: AuthProvider;

  beforeEach(async () => {
    // @ts-ignore
    Client.mockClear();
    const module: TestingModule = await Test.createTestingModule({
      imports: [
        PassportModule.register({ defaultStrategy: 'jwt' }),
        JwtModule.register({
          secret: 'secret for test',
          signOptions: {
            expiresIn: 3600,
          },
        }),
      ],
      providers: [
        AuthProvider,
        LogService,
        {
          provide: ViewAuthTeacherService,
          useValue: {
            findLdapUserInformation: () => {/**/},
          },
        },
      ],
    }).compile();

    provider = module.get<AuthProvider>(AuthProvider);
  });

  it('should be defined', () => {
    expect(provider).toBeDefined();
  });

  it('should pass the authentication and return a jwt token', async () => {
    const credentials = {
      username: 'user',
      password: 'password',
    };
    jest.spyOn(provider, 'ldapValidation').mockImplementation(() =>  Promise.resolve(true));
    expect(await provider.signIn(credentials)).toBeTruthy();
  });

  it('should pass the authentication, return a jwt token and to be called with a rut if service returns a value', async () => {
    const credentials = {
      username: 'user',
      password: 'password',
    };
    const userData = {
      rut: 1234,
    };
    jest.spyOn(provider, 'ldapValidation').mockImplementation(() =>  Promise.resolve(true));
    spyOn(provider['viewAuthTeacherService'], 'findLdapUserInformation').and.returnValue(Promise.resolve(userData));
    const jwtSpy = spyOn(provider['jwtService'], 'sign').and.returnValue(Promise.resolve({}));
    await provider.signIn(credentials);
    expect(jwtSpy).toHaveBeenCalledWith({ email: credentials.username, rut: 1234});
  });

  it('should fail the authentication and return unauthorized exception', async () => {
    const credentials = {
      username: 'user',
      password: 'invalid-password',
    };
    jest.spyOn(provider, 'ldapValidation').mockImplementation(() =>  Promise.resolve(false));
    await provider.signIn(credentials).catch((error) => expect(error)
        .toEqual(new UnauthorizedException(undefined, UNAUTHORIZED_ERROR_MESSAGE)));
  });

  it('should return user data', async () => {
    const jwtData: JwtPayload = {
      email: 'user@test.com',
      rut: 123456789,
      establishmentName: 'Jardín de prueba',
      teacherName: 'Docente de prueba',
    };
    expect(await provider.validateUser(jwtData)).toBe(jwtData);
  });

  it('should return true validating against ldap', async () => {
    const credentials = {
      username: 'user',
      password: 'password',
    };
    // @ts-ignorejest.mock('ldapts');
    Client.mockImplementation(() => {
      return {
        bind: () => Promise.resolve({}),
        unbind: () => Promise.resolve({}),
        search: () => Promise.resolve({searchEntries: [{dn: 'user'}]}),
      };
    });
    expect(await provider.ldapValidation(credentials.username, credentials.password)).toEqual(true);
  });

  it('should return false validating against ldap', async () => {
    const credentials = {
      username: 'user',
      password: 'password',
    };
    // @ts-ignorejest.mock('ldapts');
    Client.mockImplementation(() => {
      return {
        bind: () => Promise.resolve({}),
        unbind: () => Promise.resolve({}),
        search: () => Promise.resolve({}),
      };
    });
    expect(await provider.ldapValidation(credentials.username, credentials.password)).toEqual(false);
  });

  it('should throw an exception conecting with ldap', async () => {
    const credentials = {
      username: 'user',
      password: 'password',
    };
    // @ts-ignorejest.mock('ldapts');
    Client.mockImplementation(() => {
      return {
        bind: () => {throw new Error(); },
        unbind: () => Promise.resolve({}),
        search: () => Promise.resolve({searchEntries: [{dn: 'user'}]}),
      };
    });
    await provider.ldapValidation(credentials.username, credentials.password).catch((error) => expect(error)
      .toEqual(new BadGatewayException()));
  });

  it('should return false because invalid password', async () => {
    const credentials = {
      username: 'user',
      password: 'password',
    };

    const mockedBind = jest
      .fn(() => Promise.resolve({}))
      .mockImplementationOnce(() => Promise.resolve({}))
      .mockImplementationOnce(() => {throw new InvalidCredentialsError(); });
    // @ts-ignorejest.mock('ldapts');
    Client.mockImplementation(() => {
      return {
        bind: mockedBind,
        unbind: () => Promise.resolve({}),
        search: () => Promise.resolve({searchEntries: [{dn: 'user'}]}),
      };
    });
    expect(await provider.ldapValidation(credentials.username, credentials.password)).toEqual(false);
  });

  it('should throw an exception binding ldap', async () => {
    const credentials = {
      username: 'user',
      password: 'password',
    };

    const mockedBind = jest
      .fn(() => Promise.resolve({}))
      .mockImplementationOnce(() => Promise.resolve({}))
      .mockImplementationOnce(() => {throw new Error(); });
    // @ts-ignorejest.mock('ldapts');
    Client.mockImplementation(() => {
      return {
        bind: mockedBind,
        unbind: () => Promise.resolve({}),
        search: () => Promise.resolve({searchEntries: [{dn: 'user'}]}),
      };
    });
    await provider.ldapValidation(credentials.username, credentials.password).catch((error) => expect(error)
      .toEqual(new BadGatewayException()));
  });
});
