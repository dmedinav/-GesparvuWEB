import { Controller, Post, Body, HttpCode } from '@nestjs/common';
import { LoginDto } from './dto/login.dto';
import { AuthProvider } from './auth.provider';

@Controller('auth')
export class AuthController {

  constructor(private readonly authProvider: AuthProvider) {}

  @HttpCode(200)
  @Post('login')
  public login(@Body() request: LoginDto): Promise<any> {
    return this.authProvider.signIn(request);
  }
}
