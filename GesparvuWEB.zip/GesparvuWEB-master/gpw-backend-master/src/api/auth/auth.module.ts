import { LogService } from './../../common/logs/logs.service';
import { ViewAuthTeacherModule } from './../../database/entities/viewAuthTeacher/view-auth-teacher.module';
import { Module } from '@nestjs/common';
import { JwtModule } from '@nestjs/jwt';
import { AuthProvider } from './auth.provider';
import { JwtStrategy } from './jwt.strategy';
import { PassportModule } from '@nestjs/passport';
import { AuthController } from './auth.controller';
import { ViewAuthTeacherService } from '../../database/entities/viewAuthTeacher/view-auth-teacher.service';

@Module({
  imports: [
    PassportModule.register({ defaultStrategy: 'jwt' }),
    JwtModule.register({
      secret: process.env.JWT_SECRET,
      signOptions: {
        expiresIn: Number(process.env.JWT_EXPIRATION_TIME),
      },
    }),
    ViewAuthTeacherModule,
  ],
  providers: [AuthProvider, JwtStrategy, LogService, ViewAuthTeacherService],
  exports: [PassportModule, AuthProvider],
  controllers: [AuthController],
})
export class AuthModule {}
