import { UNAUTHORIZED_ERROR_MESSAGE } from './../../common/constants/response-messages';
import { UnauthorizedException } from './../../common/exceptionFilters/custom-exceptions';
import { ExtractJwt, Strategy } from 'passport-jwt';
import { AuthProvider } from './auth.provider';
import { PassportStrategy } from '@nestjs/passport';
import { Injectable } from '@nestjs/common';
import { JwtPayload } from '../../common/interfaces/jwt-payload.interface';

@Injectable()
export class JwtStrategy extends PassportStrategy(Strategy) {
  constructor(private readonly authProvider: AuthProvider) {
    super({
      jwtFromRequest: ExtractJwt.fromAuthHeaderAsBearerToken(),
      secretOrKey: process.env.JWT_SECRET,
    });
  }

  async validate(payload: JwtPayload) {
    const user = await this.authProvider.validateUser(payload);
    if (!user) {
      throw new UnauthorizedException(undefined, UNAUTHORIZED_ERROR_MESSAGE);
    }
    return user;
  }
}
