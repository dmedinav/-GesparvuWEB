import { MainAttendanceDto } from './dto/attendance-creation.dto';
import { DEFAULT_SUCCESSFUL_POST_RESPONSE } from './../../common/constants/response-messages';
import { AttendanceService } from './../../database/entities/attendance/attendance.service';
import { Injectable } from '@nestjs/common';
import Utils from '../../common/utils/utils';
import { TransactionService } from '../../database/transaction/transaction.service';
import { IQueryTransaction } from '../../common/interfaces/query-transaction.interface';
import * as Excel from 'exceljs';
import { IAttendanceCodeTypes } from '../../common/interfaces/attendance-type.interface';
import {
  EXCEL_ATTENDANCE_CODE,
  EXCEL_NO_ATTENDANCE_CODE,
  EXCEL_NO_ENROLLMENT_CODE,
  EXCEL_NOT_WORKING_DAY_CODE,
  EXCEL_TEMPLATE_PATH,
  EXCEL_FIRST_TABLE_ROW,
  EXCEL_FIRST_TABLE_COLUMN,
  EXCEL_GROUP_INFO_CELL,
  EXCEL_DATE_INFO_CELL,
  EXCEL_ENROLLMENT_COLUMN,
  EXCEL_MONTH_COLUMN,
  EXCEL_RUT_COLUMN,
  EXCEL_NAMES_COLUMN,
  EXCEL_TOTAL_ENROLLMENTS_CELL,
  EXCEL_DAYS_ROW,
  EXCEL_TOTAL_ENROLLED_DAYS_COLUMN,
} from '../../common/constants/excel';
import { MONTHS, DAYS } from '../../common/constants/misc';
import { LogService } from '../../common/logs/logs.service';
import { BadGatewayException } from '../../common/exceptionFilters/custom-exceptions';
import { EnrollmentService } from '../../database/entities/enrollment/enrollment.service';
import { Enrollment } from '../../database/entities/enrollment/enrollment.entity';
import { IEnrollment } from '../../common/interfaces/enrollments.interface';

@Injectable()
export class AttendanceProvider {

  constructor(
    private readonly attendanceService: AttendanceService,
    private readonly enrollmentService: EnrollmentService,
    private readonly transactionService: TransactionService,
    private readonly logService: LogService,
  ) { }


  public async updateAttendanceObject(enrollments: MainAttendanceDto) {
    const attendanceCodeTypes = enrollments.attendanceCodes;
    const attendances = enrollments.attendances;
    const attendancesToFind = attendances.map(attendance => attendance.id);
    const queryArray: IQueryTransaction[] = [];
    const attendancesInformation = await this.attendanceService.getAttendancesObjectForIds(attendancesToFind);
    for (const entry of attendancesInformation) {
      const index = attendances.findIndex(attendance => attendance.id === entry.id);
      const defaultMonthlyAttendance = Utils.fillMonthlyAttendanceObject(attendanceCodeTypes.RAD_DEFAULT_CODE);
      let currentJson = {};
      if (!Utils.IsJsonString(entry.attendance)) {
        currentJson = defaultMonthlyAttendance;
      } else {
        currentJson = JSON.parse(entry.attendance);
        currentJson = Object.assign(defaultMonthlyAttendance, currentJson);
      }
      attendances[index].attendance = Object.assign(currentJson, attendances[index].attendance);
      queryArray.push(this.attendanceService.updateAttendanceObject(attendances[index]) as unknown as IQueryTransaction);
    }
    await this.transactionService.executeTransaction(queryArray);
    return DEFAULT_SUCCESSFUL_POST_RESPONSE;
  }

  /* istanbul ignore next */
  public async getMonthlyAttendanceFile(month: number, year: number, group: number, attendanceCodes: IAttendanceCodeTypes) {
    const workbook = await this.openExcelTemplate(EXCEL_TEMPLATE_PATH);
    let worksheet = workbook.getWorksheet('RAD');
    const rawEnrollments = await this.enrollmentService.getEnrollmentsByGroup(group, year, month);
    const enrollments = Utils.calculateTotals({enrollments: rawEnrollments}, attendanceCodes, year, month).enrollments;
    if (enrollments.length === 0) {
      return workbook;
    }
    worksheet = this.fillExcelWithAttendances(worksheet, enrollments, month, year, attendanceCodes);
    worksheet = this.fillExcelHeader(worksheet, enrollments, month, year);
    return workbook;
  }

  /* istanbul ignore next */
  public fillExcelHeader(worksheet: Excel.Worksheet, enrollments: Enrollment[], month: number, year: number) {
    worksheet = this.fillHeaderWithDays(worksheet, month, year);

    worksheet.getCell(EXCEL_GROUP_INFO_CELL).value =
      enrollments[0].group.establishment.establishmentCode + ' - ' +
      enrollments[0].group.establishment.name + ' - ' +
      enrollments[0].group.level.label + ' - ' +
      enrollments[0].group.name;

    worksheet.getCell(EXCEL_DATE_INFO_CELL).value = 'Días de Asistencia de ' + MONTHS[month - 1] + ' ' + year;
    worksheet.getCell(EXCEL_TOTAL_ENROLLMENTS_CELL).value = enrollments.length;

    return worksheet;
  }

  /* istanbul ignore next */
  public fillHeaderWithDays(worksheet: Excel.Worksheet, month: number, year: number) {
    const date = new Date();
    let numCol = EXCEL_FIRST_TABLE_COLUMN;
    for (date.setUTCFullYear(year, month - 1, 1); date.getUTCMonth() === month - 1; date.setUTCDate(date.getUTCDate() + 1)) {
      worksheet.getCell(EXCEL_DAYS_ROW, numCol).value = DAYS[date.getUTCDay()];
      numCol++;
    }
    return worksheet;
  }

  /* istanbul ignore next */
  public fillExcelWithAttendances(
    worksheet: Excel.Worksheet,
    enrollments: IEnrollment[],
    month: number,
    year: number,
    attendanceCodes: IAttendanceCodeTypes,
  ) {
    let row = EXCEL_FIRST_TABLE_ROW;
    let numCol = EXCEL_FIRST_TABLE_COLUMN;

    for (const enrollment of enrollments) {
      worksheet.getCell(EXCEL_ENROLLMENT_COLUMN + row).value = enrollment.id;
      worksheet.getCell(EXCEL_MONTH_COLUMN + row).value = Number(month);
      worksheet.getCell(EXCEL_RUT_COLUMN + row).value = enrollment.infant.rut + '-' + enrollment.infant.rutDv;
      worksheet.getCell(EXCEL_NAMES_COLUMN + row).value =
        enrollment.infant.fathersLastname + ' ' +
        enrollment.infant.mothersLastname + ', ' +
        enrollment.infant.names;
      worksheet.getCell(EXCEL_TOTAL_ENROLLED_DAYS_COLUMN + row).value = enrollment.totalEnrolledDays;

      const date = new Date();
      numCol = EXCEL_FIRST_TABLE_COLUMN;
      for (date.setFullYear(year, month - 1, 1); date.getUTCMonth() === month - 1; date.setUTCDate(date.getUTCDate() + 1)) {
        let dailyAttendance = JSON.parse(enrollment.attendances[0].attendance)[date.getUTCDate()];
        if (!Utils.isEnrolled(year, month - 1, date.getUTCDate(), enrollment)) {
          dailyAttendance = attendanceCodes.RAD_NO_ENROLLMENT_CODE;
        }
        if (dailyAttendance !== attendanceCodes.RAD_DEFAULT_CODE) {
          worksheet.getCell(row, numCol).value = this.radToExcelCode(dailyAttendance, attendanceCodes);
        }
        numCol++;
      }
      row++;
    }
    worksheet = this.hideExcelLastColumns(worksheet, numCol, month, year);
    return worksheet;
  }

  /* istanbul ignore next */
  public hideExcelLastColumns(worksheet: Excel.Worksheet, lastNumCol: number, month: number, year: number) {
    let days = Utils.getDaysInMonthWithDate(month, year);
    while (days < 31) {
      worksheet.getColumn(lastNumCol).hidden = true;
      worksheet.getColumn(lastNumCol).eachCell((cell) => {
        cell.value = 0;
      });
      lastNumCol++;
      days++;
    }
    return worksheet;
  }

  /* istanbul ignore next */
  public radToExcelCode(radCode: number, attendanceCodes: IAttendanceCodeTypes): number {
    return radCode === attendanceCodes.RAD_ATTENDANCE_CODE ? EXCEL_ATTENDANCE_CODE :
      radCode === attendanceCodes.RAD_NO_ATTENDANCE_CODE ? EXCEL_NO_ATTENDANCE_CODE :
        radCode === attendanceCodes.RAD_NO_ENROLLMENT_CODE ? EXCEL_NO_ENROLLMENT_CODE :
          EXCEL_NOT_WORKING_DAY_CODE;
  }

  /* istanbul ignore next */
  public async openExcelTemplate(path: string): Promise<Excel.Workbook> {
    const workbook = new Excel.Workbook();
    try {
      await workbook.xlsx.readFile(path);
    } catch (err) {
      this.logService.error('Error reading excel file', err.message, 'attendances/monthly/file');
      throw new BadGatewayException();
    }
    return workbook;
  }
}
