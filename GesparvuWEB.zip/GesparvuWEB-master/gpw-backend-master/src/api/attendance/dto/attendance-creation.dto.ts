import { IsNotEmpty, ValidateNested, IsNumber } from 'class-validator';
import { Type } from 'class-transformer';
import { IsAttendanceObjectValid } from './../../../common/validators/attendance-object.validator';
import { IAttendanceCodeTypes } from '../../../common/interfaces/attendance-type.interface';

export class AttendanceInformationDto {
  @IsNotEmpty()
  @IsNumber()
  id: number;

  @IsNotEmpty()
  attendance: object;
}

// tslint:disable-next-line:max-classes-per-file
export class MainAttendanceDto {
  @IsAttendanceObjectValid()
  @IsNotEmpty()
  @ValidateNested({ each: true })
  @Type(/* istanbul ignore next */ () => AttendanceInformationDto)
  attendances: AttendanceInformationDto[];
  attendanceCodes: IAttendanceCodeTypes;
}
