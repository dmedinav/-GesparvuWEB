import { MainAttendanceDto } from './dto/attendance-creation.dto';
import { AttendanceProvider } from './attendance.provider';
import {
  Controller,
  Body,
  Put,
  UseInterceptors,
  UseGuards,
  Get,
  Response,
  Query,
} from '@nestjs/common';
import { AttendanceCodesInterceptorRequest } from '../../common/interceptors/attendance-codes-request.interceptor';
import { AuthGuard } from '@nestjs/passport';
import { IAttendanceCodeTypes } from '../../common/interfaces/attendance-type.interface';
import { ExceptionCalendarDto } from '../exception/dto/exception-calendar.dto';

@UseInterceptors(AttendanceCodesInterceptorRequest)
@Controller('attendances')
export class AttendanceController {
  constructor(private attendanceProvider: AttendanceProvider) { }

  @UseGuards(AuthGuard('jwt'))
  @Put()
  public updateAttendanceObject(@Body() request: MainAttendanceDto) {
    return this.attendanceProvider.updateAttendanceObject(request);
  }

  /* istanbul ignore next */
  @UseGuards(AuthGuard())
  @Get('monthly/file')
  public getMonthlyAttendanceFile(
    @Body() request: { attendanceCodes: IAttendanceCodeTypes },
    @Response() res,
    @Query() queryParams: ExceptionCalendarDto,
  ): void {

    const workbook = this.attendanceProvider.getMonthlyAttendanceFile(
      queryParams.month,
      queryParams.year,
      queryParams.group,
      request.attendanceCodes,
    );

    res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    res.setHeader('Content-Disposition', 'attachment; filename=' + 'Report.xlsx');
    workbook.then((w) => {
      w.xlsx.write(res)
        .then(() => {
          res.end();
        });
    });
  }
}
