import { DEFAULT_SUCCESSFUL_POST_RESPONSE } from './../../common/constants/response-messages';
import { mainAttendanceDtoMock, attendanceCodesSigeMock } from './../../common/mocks/attendance';
import { AttendanceProvider } from './attendance.provider';
import { Test, TestingModule } from '@nestjs/testing';
import { AttendanceController } from './attendance.controller';
import { AttendanceTypeService } from '../../database/entities/attendanceType/attendance-type.service';

describe('Attendance Controller', () => {
  let controller: AttendanceController;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [AttendanceController],
      providers: [
        AttendanceTypeService,
        {
          provide: AttendanceProvider, useValue: {
            updateAttendanceObject: () => undefined,
          },
        },
        {
          provide: 'AttendanceTypeRepository',
          useValue: {
            find: () => {/**/},
          },
        },
      ],
    }).compile();

    controller = module.get<AttendanceController>(AttendanceController);
  });

  it('should be defined', () => {
    expect(controller).toBeDefined();
  });

  it('updateAttendanceObject should return an object when is requested.', async () => {
    // tslint:disable-next-line:no-string-literal
    spyOn(controller['attendanceProvider'], 'updateAttendanceObject').and.returnValue(Promise.resolve(DEFAULT_SUCCESSFUL_POST_RESPONSE));
    expect(await controller.updateAttendanceObject(mainAttendanceDtoMock)).toEqual(DEFAULT_SUCCESSFUL_POST_RESPONSE);
  });

});
