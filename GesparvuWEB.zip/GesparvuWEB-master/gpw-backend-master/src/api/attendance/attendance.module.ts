import { AttendanceProvider } from './attendance.provider';
import { AttendanceController } from './attendance.controller';
import { Attendance } from '../../database/entities/attendance/attendance.entity';
import { Module } from '@nestjs/common';
import { AttendanceService } from '../../database/entities/attendance/attendance.service';
import { TypeOrmModule } from '@nestjs/typeorm';
import { AttendanceTypeModule } from '../../database/entities/attendanceType/attendance-type.module';
import { TransactionService } from '../../database/transaction/transaction.service';
import { AuthModule } from '../auth/auth.module';
import { LogService } from '../../common/logs/logs.service';
import { EnrollmentService } from '../../database/entities/enrollment/enrollment.service';
import { Enrollment } from '../../database/entities/enrollment/enrollment.entity';
import { PeriodService } from '../../database/entities/period/period.service';
import { Period } from '../../database/entities/period/period.entity';

@Module({
  imports: [TypeOrmModule.forFeature([Attendance, Enrollment, Period]), AttendanceTypeModule, AuthModule],
  controllers: [AttendanceController],
  providers: [AttendanceService, AttendanceProvider, TransactionService, LogService, EnrollmentService, PeriodService],
  exports: [AttendanceService],
})
export class AttendanceModule {}
