import {
  attendanceWithMonthlyAttendanceMock,
  attendanceCodeTypesMock,
  mainAttendanceDtoMock,
  attendanceWithMonthlyAttendanceObjectMock,
} from './../../common/mocks/attendance';
import { AttendanceService } from './../../database/entities/attendance/attendance.service';
import { Test, TestingModule } from '@nestjs/testing';
import { AttendanceProvider } from './attendance.provider';
import { DEFAULT_SUCCESSFUL_POST_RESPONSE } from './../../common/constants/response-messages';
import Utils from '../../common/utils/utils';
import { TransactionService } from '../../database/transaction/transaction.service';
import { LogService } from '../../common/logs/logs.service';
import { EnrollmentService } from '../../database/entities/enrollment/enrollment.service';
import { PeriodService } from '../../database/entities/period/period.service';

describe('Attendance', () => {
  let provider: AttendanceProvider;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [
        AttendanceProvider,
        LogService,
        EnrollmentService,
        PeriodService,
        { provide: 'PeriodRepository', useValue: { getManager: () => {/**/ } } },
        { provide: 'EnrollmentRepository', useValue: { createQueryBuilder: () => {/**/ } } },
        { provide: TransactionService, useValue: { executeTransaction: () => {/**/ } } },
        {
          provide: AttendanceService,
          useValue: {
            updateAttendanceObject: () => {/**/ },
            getAttendancesObjectForIds: () => {/**/ },
          },
        },
      ],
    }).compile();
    provider = module.get<AttendanceProvider>(AttendanceProvider);
  });

  it('should be defined', () => {
    expect(provider).toBeDefined();
  });

  it('updateAttendanceObject should return OK and monthly attendance object is empty', async () => {
    // tslint:disable-next-line:no-string-literal
    const updateSpy = spyOn(provider['attendanceService'], 'updateAttendanceObject').and.returnValue(Promise.resolve({}));
    const monthlyAttendance = Utils.fillMonthlyAttendanceObject(attendanceCodeTypesMock.RAD_DEFAULT_CODE);
    const calledWith = {
      id: 1,
      attendance: monthlyAttendance,
    };
    calledWith.attendance = Object.assign(calledWith.attendance, mainAttendanceDtoMock.attendances[0].attendance);
    // tslint:disable-next-line:no-string-literal
    spyOn(provider['attendanceService'], 'getAttendancesObjectForIds').
      and.returnValue(Promise.resolve([attendanceWithMonthlyAttendanceMock]));
    expect(await provider.updateAttendanceObject(mainAttendanceDtoMock)).toEqual(DEFAULT_SUCCESSFUL_POST_RESPONSE);
    expect(updateSpy).toBeCalledWith(calledWith);
  });

  it('updateAttendanceObject should return OK and monthly attendance object has value', async () => {
    // tslint:disable-next-line:no-string-literal
    const updateSpy = spyOn(provider['attendanceService'], 'updateAttendanceObject').and.returnValue(Promise.resolve({}));
    const monthlyAttendance = Utils.fillMonthlyAttendanceObject(attendanceCodeTypesMock.RAD_DEFAULT_CODE);
    const calledWith = {
      id: 1,
      attendance: monthlyAttendance,
    };
    calledWith.attendance = Object.assign(calledWith.attendance, mainAttendanceDtoMock.attendances[0].attendance);
    // tslint:disable-next-line:no-string-literal
    spyOn(provider['attendanceService'], 'getAttendancesObjectForIds').
      and.returnValue(Promise.resolve([attendanceWithMonthlyAttendanceObjectMock]));
    expect(await provider.updateAttendanceObject(mainAttendanceDtoMock)).toEqual(DEFAULT_SUCCESSFUL_POST_RESPONSE);
    expect(updateSpy).toBeCalledWith(calledWith);
  });

});
