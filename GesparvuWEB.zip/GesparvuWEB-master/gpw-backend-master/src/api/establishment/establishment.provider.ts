import { EstablishmentService } from '../../database/entities/establishment/establishment.service';
import { Injectable } from '@nestjs/common';
import { Establishment } from '../../database/entities/establishment/establishment.entity';

@Injectable()
export class EstablishmentProvider {

  constructor(private readonly establishmentService: EstablishmentService) { }

  public async getEstablishmentsWithGroupsByCounty(countyId: number): Promise<Establishment[]> {
    return this.establishmentService.getEstablishmentsWithGroupsByCounty(countyId);
  }
}
