import { Test, TestingModule } from '@nestjs/testing';
import { EstablishmentController } from './establishment.controller';
import { EstablishmentProvider } from './establishment.provider';
import { establishmentParamsDtoMock } from '../../common/mocks/establishment';

describe('Establishment Controller', () => {
  let controller: EstablishmentController;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [EstablishmentController],
      providers: [
        {
          provide: EstablishmentProvider, useValue: {
            getEstablishmentsWithGroupsByCounty: () => undefined,
          },
        },
      ],
    }).compile();

    controller = module.get<EstablishmentController>(EstablishmentController);
  });

  it('should be defined', () => {
    expect(controller).toBeDefined();
  });

  it('getEstablishmentsWithGroupsByCounty should return an object when is requested.', async () => {
    const expected = { };
    // tslint:disable-next-line:no-string-literal
    spyOn(controller['establishmentProvider'], 'getEstablishmentsWithGroupsByCounty').and.returnValue(Promise.resolve(expected));
    expect(await controller.getEstablishmentsWithGroupsByCounty(establishmentParamsDtoMock)).toEqual({ });
  });

});
