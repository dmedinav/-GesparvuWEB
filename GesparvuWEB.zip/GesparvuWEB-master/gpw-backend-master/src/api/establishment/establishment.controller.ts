import { Establishment } from '../../database/entities/establishment/establishment.entity';
import { EstablishmentProvider } from './establishment.provider';
import { Controller, Get, Query, UseGuards  } from '@nestjs/common';
import { EstablishmentsByCountyDto } from './dto/establishment.dto';
import { AuthGuard } from '@nestjs/passport';

@Controller('establishments')
export class EstablishmentController {

  constructor(private establishmentProvider: EstablishmentProvider) {}

  @UseGuards(AuthGuard('jwt'))
  @Get()
  public getEstablishmentsWithGroupsByCounty(@Query() params: EstablishmentsByCountyDto): Promise<Establishment[]> {
    return this.establishmentProvider.getEstablishmentsWithGroupsByCounty(params.county);
  }
}
