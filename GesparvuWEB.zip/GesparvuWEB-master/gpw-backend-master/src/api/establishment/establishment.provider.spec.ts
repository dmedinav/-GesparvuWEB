import { establishmentDataMock } from './../../common/mocks/establishment';
import { EstablishmentService } from './../../database/entities/establishment/establishment.service';
import { EstablishmentProvider } from './establishment.provider';
import { Test, TestingModule } from '@nestjs/testing';

describe('EstablishmentProvider', () => {
  let provider: EstablishmentProvider;
  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [
        EstablishmentProvider,
        {
          provide: EstablishmentService,
          useValue: {
            getEstablishmentsWithGroupsByCounty: () => {/**/},
          },
        },
      ],
    }).compile();
    provider = module.get<EstablishmentProvider>(EstablishmentProvider);
  });

  it('should be defined', () => {
    expect(provider).toBeDefined();
  });

  it('getEstablishmentsWithGroupsByCounty should return an object when is requested', async () => {
    // tslint:disable-next-line:no-string-literal
    spyOn(provider['establishmentService'], 'getEstablishmentsWithGroupsByCounty').and.returnValue(Promise.resolve(establishmentDataMock));
    expect(await provider.getEstablishmentsWithGroupsByCounty(1)).toEqual(establishmentDataMock);
  });
});
