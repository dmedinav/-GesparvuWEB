import { Establishment } from '../../database/entities/establishment/establishment.entity';
import { Module } from '@nestjs/common';
import { EstablishmentService } from '../../database/entities/establishment/establishment.service';
import { TypeOrmModule } from '@nestjs/typeorm';
import { EstablishmentProvider } from './establishment.provider';
import { EstablishmentController } from './establishment.controller';
import { AuthModule } from '../auth/auth.module';

@Module({
  imports: [TypeOrmModule.forFeature([Establishment]), AuthModule],
  providers: [EstablishmentService, EstablishmentProvider],
  controllers: [EstablishmentController],
})
export class EstablishmentModule {}
