import { IsNotEmpty, IsNumberString } from 'class-validator';

export class EstablishmentsByCountyDto {
  @IsNotEmpty()
  @IsNumberString()
  readonly county: number;
}
