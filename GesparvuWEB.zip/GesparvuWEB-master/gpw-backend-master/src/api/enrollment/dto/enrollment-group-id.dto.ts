import { IsInt, IsPositive } from 'class-validator';
import { Type } from 'class-transformer';

export class EnrollmentsGroupIdDto {
  @Type(/* istanbul ignore next */ () => Number)
  @IsInt()
  @IsPositive()
  readonly id: number;
}
