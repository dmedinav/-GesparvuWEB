import { IsOptional, Min, Max, IsInt } from 'class-validator';
import { Type } from 'class-transformer';

export class EnrollmentsDateParamsDto {

  @IsOptional()
  @Type(/* istanbul ignore next */ () => Number)
  @IsInt()
  readonly year: number;

  @IsOptional()
  @Type(/* istanbul ignore next */ () => Number)
  @Min(1)
  @Max(12)
  @IsInt()
  readonly month: number;

  @IsOptional()
  @Type(/* istanbul ignore next */ () => Number)
  @Min(1)
  @Max(31)
  @IsInt()
  readonly day: number;

}
