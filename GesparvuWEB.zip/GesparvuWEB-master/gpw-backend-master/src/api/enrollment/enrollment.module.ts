import { Enrollment } from '../../database/entities/enrollment/enrollment.entity';
import { Module } from '@nestjs/common';
import { EnrollmentService } from '../../database/entities/enrollment/enrollment.service';
import { TypeOrmModule } from '@nestjs/typeorm';
import { EnrollmentProvider } from './enrollment.provider';
import { EnrollmentController } from './enrollment.controller';
import { AttendanceTypeModule } from '../../database/entities/attendanceType/attendance-type.module';
import { AuthModule } from '../auth/auth.module';
import { PeriodModule } from '../../database/entities/period/period.module';

@Module({
  imports: [TypeOrmModule.forFeature([Enrollment]), AttendanceTypeModule, AuthModule, PeriodModule],
  exports: [EnrollmentService],
  providers: [EnrollmentService, EnrollmentProvider],
  controllers: [EnrollmentController],
})
export class EnrollmentModule {}
