import { Test, TestingModule } from '@nestjs/testing';
import { EnrollmentController } from './enrollment.controller';
import { EnrollmentProvider } from './enrollment.provider';
import {
  enrollmentDataMock,
  enrollmentsByDateParamsMock,
  enrollmentsGroupParamsMock,
  enrollmentsParamsMock,
  enrollmentParamMock,
} from '../../common/mocks/enrollment';
import { AttendanceTypeService } from '../../database/entities/attendanceType/attendance-type.service';
import { userRequestMock } from '../../common/mocks/userReques';
import { attendanceCodeTypesMock } from '../../common/mocks/attendance';

describe('Enrollment Controller', () => {
  let controller: EnrollmentController;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [EnrollmentController],
      providers: [
        AttendanceTypeService,
        {
          provide: 'AttendanceTypeRepository',
          useValue: {
            find: () => {/**/ },
          },
        },
        {
          provide: EnrollmentProvider, useValue: {
            getEnrollmentsByGroup: () => undefined,
            getEnrollments: () => undefined,
            getEnrollment: () => undefined,
          },
        },
      ],
    }).compile();

    controller = module.get<EnrollmentController>(EnrollmentController);
  });

  it('should be defined', () => {
    expect(controller).toBeDefined();
  });

  it('getEnrollmentsByGroup should return an object when is requested.', async () => {
    // tslint:disable-next-line:no-string-literal
    spyOn(controller['enrollmentProvider'], 'getEnrollmentsByGroup').and.returnValue(Promise.resolve(enrollmentDataMock));
    expect(
      await controller.getEnrollmentsByGroup(enrollmentsGroupParamsMock, enrollmentsByDateParamsMock, { attendanceCodes: attendanceCodeTypesMock }),
    ).toEqual(enrollmentDataMock);
  });

  it('getEnrollments should return an object when is requested.', async () => {
    // tslint:disable-next-line:no-string-literal
    spyOn(controller['enrollmentProvider'], 'getEnrollments').and.returnValue(Promise.resolve(enrollmentDataMock));
    expect(await controller.getEnrollments(userRequestMock, enrollmentsParamsMock)).toEqual(enrollmentDataMock);
  });

  it('getEnrollment should return an enrollment.', async () => {
    // tslint:disable-next-line:no-string-literal
    spyOn(controller['enrollmentProvider'], 'getEnrollment').and.returnValue(Promise.resolve(enrollmentDataMock));
    expect(await controller.getEnrollment(enrollmentParamMock)).toEqual(enrollmentDataMock);
  });

});
