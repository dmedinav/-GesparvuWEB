import { EnrollmentProvider } from './enrollment.provider';
import { Controller, Get, Query, UseInterceptors, UseGuards, Param, Req, Body} from '@nestjs/common';
import { AttendanceCodesInterceptorResponse } from '../../common/interceptors/attendance-codes-response.interceptor';
import { IEnrollments } from '../../common/interfaces/enrollments.interface';
import { EnrollmentsDateParamsDto } from './dto/enrollments-date-params.dto';
import { EnrollmentsGroupIdDto } from './dto/enrollment-group-id.dto';
import { EnrollmentsFilterDto } from './dto/enrollments-filter.dto';
import { EnrollmentIdDto } from './dto/enrollment-id.dto';
import { Enrollment } from '../../database/entities/enrollment/enrollment.entity';
import { AuthGuard } from '@nestjs/passport';
import { IUserRequest } from '../../common/interfaces/user-request.interface';
import { AttendanceCodesInterceptorRequest } from '../../common/interceptors/attendance-codes-request.interceptor';
import { IAttendanceCodeTypes } from '../../common/interfaces/attendance-type.interface';

@Controller('enrollments')
export class EnrollmentController {

  constructor(private enrollmentProvider: EnrollmentProvider) {}

  @UseGuards(AuthGuard('jwt'))
  @Get('group/:id')
  @UseInterceptors(AttendanceCodesInterceptorResponse)
  @UseInterceptors(AttendanceCodesInterceptorRequest)
  public getEnrollmentsByGroup(
    @Param() params: EnrollmentsGroupIdDto,
    @Query() queryParams: EnrollmentsDateParamsDto,
    @Body() request: { attendanceCodes: IAttendanceCodeTypes },
  ): Promise<IEnrollments> {
    return this.enrollmentProvider.getEnrollmentsByGroup(
      Number(params.id),
      Number(queryParams.year),
      Number(queryParams.month),
      Number(queryParams.day),
      request.attendanceCodes,
    );
  }

  @UseGuards(AuthGuard('jwt'))
  @Get()
  public getEnrollments(@Req() request: IUserRequest, @Query() queryParams: EnrollmentsFilterDto): Promise<IEnrollments> {
    return this.enrollmentProvider.getEnrollments(
      Number(request.user.rut),
      queryParams.filter,
    );
  }

  @UseGuards(AuthGuard('jwt'))
  @Get('/:id')
  public getEnrollment(@Param() params: EnrollmentIdDto): Promise<Enrollment> {
    return this.enrollmentProvider.getEnrollment(
      Number(params.id),
    );
  }
}
