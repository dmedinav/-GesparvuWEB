import { ENROLLMENT_NOT_FOUND } from './../../common/constants/response-codes';
import { ENROLLMENT_NOT_FOUND_MESSAGE } from './../../common/constants/response-messages';
import { Enrollment } from './../../database/entities/enrollment/enrollment.entity';
import { EnrollmentService } from '../../database/entities/enrollment/enrollment.service';
import { Injectable } from '@nestjs/common';
import { IEnrollments } from '../../common/interfaces/enrollments.interface';
import { NotFoundException } from '../../common/exceptionFilters/custom-exceptions';
import { IAttendanceCodeTypes } from '../../common/interfaces/attendance-type.interface';
import { PeriodService } from '../../database/entities/period/period.service';
import Utils from '../../common/utils/utils';

@Injectable()
export class EnrollmentProvider {

  constructor(
    private readonly enrollmentService: EnrollmentService,
    private readonly periodService: PeriodService,
    ) { }

  public async getEnrollmentsByGroup(
    groupId: number,
    year: number,
    month: number,
    day: number,
    attendanceCodes: IAttendanceCodeTypes,
  ): Promise<IEnrollments> {

    let enrollments;

    if (!year || !month) {
      const now = new Date();
      year =  now.getUTCFullYear();
      month = now.getUTCMonth() + 1;

      enrollments = {
        enrollments: await this.enrollmentService.getEnrollmentsByGroup(groupId, year, month),
        isActiveMonth: (await this.periodService.isActiveMonth(year, month)),
      } as IEnrollments;
    } else {
      enrollments = {
        enrollments:
          day ? this.parseDayOfAttendanceObject(await this.enrollmentService.getEnrollmentsByGroup(groupId, year, month, day, false), day) :
            await this.enrollmentService.getEnrollmentsByGroup(groupId, year, month),
        isActiveMonth: (await this.periodService.isActiveMonth(year, month)),
      } as IEnrollments;
    }

    return day ? enrollments : Utils.calculateTotals(enrollments, attendanceCodes, year, month);
  }

  public async getEnrollments(teacher: number, filter: string): Promise<IEnrollments> {
    const enrollments = await this.enrollmentService.getEnrollments(teacher, filter);
    return { enrollments };
  }

  public async getEnrollment(enrollmentId: number): Promise<Enrollment> {
    const enrollment = await this.enrollmentService.getEnrollment(enrollmentId);
    if (!enrollment) { throw new NotFoundException(ENROLLMENT_NOT_FOUND, ENROLLMENT_NOT_FOUND_MESSAGE); }
    enrollment.group.name = enrollment.group.level.label + ' Grupo ' + enrollment.group.name;
    return enrollment;
  }

  public parseDayOfAttendanceObject(enrollments: Enrollment[], day: number): Enrollment[] {
    const finalEnrollments = [];
    for (const enrollment of enrollments) {
      try {
        enrollment.attendances[0].attendance = JSON.parse(enrollment.attendances[0].attendance)[day];
        finalEnrollments.push(enrollment);
      } catch (error) {/**/ }
    }
    return finalEnrollments;
  }
}
