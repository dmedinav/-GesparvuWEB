import { NotFoundException } from './../../common/exceptionFilters/custom-exceptions';
import { ENROLLMENT_NOT_FOUND } from './../../common/constants/response-codes';
import { ENROLLMENT_NOT_FOUND_MESSAGE } from './../../common/constants/response-messages';
import {
  enrollmentsDataActiveMock,
  enrollmentsDataNotActiveMock,
  enrollmentsDataDayActiveMock,
  enrollmentDataDayMock,
  enrollmentsDataActiveMockWithTotals,
  enrollmentBaseMock,
} from '../../common/mocks/enrollment';
import { NOW, ENROLLMENT_DATE } from '../../common/mocks/common';
import { EnrollmentService } from '../../database/entities/enrollment/enrollment.service';
import { EnrollmentProvider } from './enrollment.provider';
import { Test, TestingModule } from '@nestjs/testing';
import { Enrollment } from '../../database/entities/enrollment/enrollment.entity';
import { attendanceCodeTypesMock } from '../../common/mocks/attendance';
import { PeriodService } from '../../database/entities/period/period.service';

// tslint:disable:no-string-literal
describe('EnrollmentProvider', () => {
  let provider: EnrollmentProvider;
  const year = new Date(NOW).getFullYear();
  // getEnrollmentsByGroup uses 1-based month
  const month = new Date(NOW).getUTCMonth() + 1;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [
        EnrollmentProvider,
        {
          provide: EnrollmentService,
          useValue: {
            getEnrollmentsByGroup: () => {/**/ },
            getEnrollments: () => {/**/ },
            getEnrollment: () => {/**/ },
          },
        },
        {
          provide: PeriodService,
          useValue: {
            isActiveMonth: () => true,
          },
        },
      ],
    }).compile();
    provider = module.get<EnrollmentProvider>(EnrollmentProvider);
  });

  it('should be defined', () => {
    expect(provider).toBeDefined();
  });

  describe('enrollmentProvider', () => {
    beforeEach(() => {
      const enrollmentsMockDefinition = {
        id: 1,
        enrollmentDate: new Date(ENROLLMENT_DATE),
        retirementDate: null,
        infant: {},
        group: {
          name: 'name',
          level: {
            label: 'A',
          },
        },
        movement: {},
        modifiedBy: '',
        modificationDate: new Date(NOW),
        sigeTransfer: 1,
        transferDate: new Date(NOW),
        attendances: [{
          id: 1,
          attendance: '{"1": 2, "2": 1}',
        }],
      } as Enrollment;
      enrollmentsDataActiveMock.enrollments = [enrollmentsMockDefinition];
      spyOn(provider['enrollmentService'], 'getEnrollmentsByGroup').and.returnValue(Promise.resolve(enrollmentsDataActiveMock.enrollments));
      spyOn(provider['enrollmentService'], 'getEnrollments').and.returnValue(Promise.resolve(enrollmentDataDayMock));
      spyOn(provider['enrollmentService'], 'getEnrollment').and.returnValue(Promise.resolve(enrollmentDataDayMock));
    });

    it('should return an object.', async () => {
      expect(await provider.getEnrollmentsByGroup(254, null, null, null, attendanceCodeTypesMock)).toEqual(enrollmentsDataActiveMockWithTotals);
      expect(await provider.getEnrollmentsByGroup(254, year, month, null, attendanceCodeTypesMock)).toEqual(enrollmentsDataActiveMockWithTotals);
      expect(await provider.getEnrollmentsByGroup(254, year, month + 1, null, attendanceCodeTypesMock)).toEqual(enrollmentsDataActiveMockWithTotals);

      spyOn(provider['periodService'], 'isActiveMonth').and.returnValue(false);
      expect(await provider.getEnrollmentsByGroup(254, year, month + 2, null, attendanceCodeTypesMock)).toEqual(enrollmentsDataNotActiveMock);
      expect(await provider.getEnrollmentsByGroup(254, year, month - 1, null, attendanceCodeTypesMock)).toEqual(enrollmentsDataNotActiveMock);
    });

    it('should return an object with no enrolled.', async () => {
      const enrollments = await provider.getEnrollmentsByGroup(254, 2018, 5, null, attendanceCodeTypesMock);
      expect(enrollments.enrollments[0].totalEnrolledDays).toBe(0);
    });

    it('should return an object with attendance of an especific day with past month', async () => {
      await provider.getEnrollmentsByGroup(254, year, month, 1, attendanceCodeTypesMock).then(async mock => {
        expect(mock).toEqual(enrollmentsDataDayActiveMock);
      });
    });

    it('should return an object with attendance of an especific day with current month', async () => {
      await provider.getEnrollmentsByGroup(254, year, month + 1, 1, attendanceCodeTypesMock).then(mock => {
        expect(mock).toEqual(enrollmentsDataDayActiveMock);
      });
    });

    it('should return an object with enrollments of groups of a teacher', async () => {
      await provider.getEnrollments(11111111, 'filter').then(async mock => {
        expect(mock).toEqual({ enrollments: enrollmentDataDayMock });
      });
    });

    it('should return an enrollment', async () => {
      await provider.getEnrollment(1).then(async mock => {
        expect(mock).toEqual(enrollmentDataDayMock);
      })
        .catch(() => expect(false).toBe(true));
    });
  });

  describe(('enrollmentProvider Exceptions'), () => {
    it('getEnrollment should throw an exception if not found', async () => {
      spyOn(provider['enrollmentService'], 'getEnrollment').
        and.returnValue(Promise.resolve(undefined));

      await provider.getEnrollment(1).catch((error) => {
        expect(error).toEqual(new NotFoundException(ENROLLMENT_NOT_FOUND, ENROLLMENT_NOT_FOUND_MESSAGE));
      });
    });
  });
});
