import { Length, IsInt, IsDefined, IsDateString, IsBoolean } from 'class-validator';

export class TransferDto {
  @IsDefined()
  @IsInt()
  readonly enrollment: number;

  @IsDefined()
  @IsInt()
  readonly newGroup: number;

  @IsDefined()
  @IsDateString()
  readonly transferDate: Date;

  @IsDefined()
  @IsBoolean()
  readonly isPresent: boolean;
}
