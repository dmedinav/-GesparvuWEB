import { Length, IsInt, IsDefined, IsDateString } from 'class-validator';

export class MovementFormCreationDto {
  @IsDefined()
  @IsInt()
  readonly enrollment: number;

  @IsDefined()
  @IsInt()
  readonly movement: number;

  @IsDefined()
  @IsDateString()
  readonly retirementDate: Date;

  constructor(
    enrollment: number,
    movement: number,
    retirementDate: Date,
    public modificationDate: Date = null,
    public modifiedBy: string = null,
    public typingDate: Date = null,
    public typed: boolean = null
  ) {
    this.enrollment = enrollment;
    this.movement = movement;
    this.retirementDate = retirementDate;
  }
}
