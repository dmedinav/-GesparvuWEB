import { AttendanceModule } from './../attendance/attendance.module';
import { AuthModule } from './../auth/auth.module';
import { EnrollmentModule } from './../enrollment/enrollment.module';
import { Module } from '@nestjs/common';
import { Movement } from './../../database/entities/movement/movement.entity';
import { MovementController } from './movement.controller';
import { MovementForm } from '../../database/entities/movementForm/movement-form.entity';
import { MovementFormService } from '../../database/entities/movementForm/movement-form.service';
import { MovementProvider } from './movement.provider';
import { MovementService } from './../../database/entities/movement/movement.service';
import { TransactionService } from '../../database/transaction/transaction.service';
import { TypeOrmModule } from '@nestjs/typeorm';
import { InfantModule } from '../infant/infant.module';
import { TransferDto } from './dto/transfer.dto';

@Module({
  imports: [
    AttendanceModule,
    EnrollmentModule,
    TypeOrmModule.forFeature([Movement]),
    TypeOrmModule.forFeature([MovementForm]),
    AuthModule,
    InfantModule
  ],
  controllers: [
    MovementController
  ],
  providers: [
    MovementFormService,
    MovementService,
    MovementProvider,
    TransactionService
  ],
})
export class MovementModule { }
