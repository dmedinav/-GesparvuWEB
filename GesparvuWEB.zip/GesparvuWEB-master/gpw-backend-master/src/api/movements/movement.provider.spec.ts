// nest
import { Test, TestingModule } from '@nestjs/testing';

// entities
import { Attendance } from '../../database/entities/attendance/attendance.entity';

// services
import { AttendanceService } from '../../database/entities/attendance/attendance.service';
import { EnrollmentService } from '../../database/entities/enrollment/enrollment.service';
import { MovementFormService } from '../../database/entities/movementForm/movement-form.service';
import { MovementService } from './../../database/entities/movement/movement.service';
import { TransactionService } from '../../database/transaction/transaction.service';

//providers
import { MovementProvider } from './movement.provider';

// common
import { BadRequestException } from './../../common/exceptionFilters/custom-exceptions';
import { DEFAULT_SUCCESSFUL_POST_RESPONSE, SAVE_ERROR_MESSAGE, UNIQUE_MOVEMENT_VIOLATION_MESSAGE } from './../../common/constants/response-messages';
import { UNIQUE_VIOLATION_POSTGRE_CODE } from './../../common/constants/misc';
import { attendanceCodesSigeMock } from '../../common/mocks/attendance';
import { attendanceYearListMock } from '../../common/mocks/attendance';
import { movementFormCreationMock } from '../../common/mocks/movements';
import { movementTypesMock } from './../../common/mocks/movements';
import { InfantProvider } from '../infant/infant.provider';

// tslint:disable:no-string-literal
describe('Movement', () => {
  let provider: MovementProvider;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [
        MovementProvider,
        {
          provide: AttendanceService,
          useValue: {
            getAttendancesForEnrollment: () => attendanceYearListMock,
            deleteAttendance: () => {/**/},
            updateAttendanceObject: () => {/**/},
          },
        },
        {
          provide: EnrollmentService,
          useValue: {
            updateEnrollment: () => {/**/},
          },
        },
        {
          provide: MovementFormService,
          useValue: {
            withdrawInfant: () => {/**/},
          },
        },
        {
          provide: MovementService,
          useValue: {
            getMovementTypes: () => {/**/},
          },
        },
        {
          provide: TransactionService,
          useValue: {
            executeTransaction: () => {/**/},
          },
        },
        {
          provide: InfantProvider,
          useValue: {
            executeTransaction: () => {/**/},
          },
        }
      ],
    }).compile();

    provider = module.get<MovementProvider>(MovementProvider);
  });

  it('should be defined', () => {
    expect(provider).toBeDefined();
  });

  describe('withdrawInfant tests', () => {

    it('withdrawInfant should return OK if movement information is correct', async () => {

      // when the provider calls movementFormService.withdrawInfant return {}
      const movementFormServiceSpy = spyOn(provider['movementFormService'], 'withdrawInfant')
        .and.returnValue(Promise.resolve({}));

      // when the provider calls enrollmentService.updateEnrollment return {}
      const enrollmentServiceSpy = spyOn(provider['enrollmentService'], 'updateEnrollment')
        .and.returnValue(Promise.resolve({}));

      // when the provider calls attendanceService.deleteAttendance return {}
      const deleteAttendanceSpy = spyOn(provider['attendanceService'], 'deleteAttendance')
        .and.returnValue(Promise.resolve({}));

      // when the provider calls attendanceService.deleteAttendance return {}
      const updateAttendanceSpy = spyOn(provider['attendanceService'], 'updateAttendanceObject')
        .and.returnValue(Promise.resolve({}));

      expect(await provider.withdrawInfant(movementFormCreationMock))
        .toEqual(DEFAULT_SUCCESSFUL_POST_RESPONSE);

      expect(movementFormServiceSpy).toHaveBeenCalledWith(movementFormCreationMock);

      // validate that the enrollment service was updated
      expect(enrollmentServiceSpy).toHaveBeenCalled();

      const retirementMonth1Based = movementFormCreationMock.retirementDate.getUTCMonth() + 1;

      // validate that all following months  where deleted
      // 12 months of the previous year are untouched
      // 12 - retirementMonth1Based months of this year are deleted
      // 12 months of the next year are deleted
      expect(deleteAttendanceSpy).toHaveBeenCalledTimes(24 - retirementMonth1Based);

      // validate the correct attendance was updated 
      expect(updateAttendanceSpy).toHaveBeenCalledWith({
        id: retirementMonth1Based, // little hack from the mocks id is the month
        attendance: {"1":1,"2":0,"3":0,"4":0,"5":0,"6":0,"7":0,"8":0,"9":0,"10":0,"11":0,"12":0,"13":0,"14":0}
      });

    });

    it('withdrawInfant should return BadRequest when promise service returns a reject promise', async () => {
      const movementFormServiceSpy = spyOn(provider['movementFormService'], 'withdrawInfant').
        and.returnValue(Promise.reject({}));

      await provider.withdrawInfant(movementFormCreationMock).catch((error) => {
        expect(error).toEqual(new BadRequestException(undefined, SAVE_ERROR_MESSAGE));
        expect(movementFormServiceSpy).toHaveBeenCalledWith(movementFormCreationMock);
      });

    });

    it('withdrawInfant should return BadRequest when promise service returns a reject promise with unique violation code', async () => {
      const movementFormServiceSpy = spyOn(provider['movementFormService'], 'withdrawInfant').
        and.returnValue(Promise.reject({code: UNIQUE_VIOLATION_POSTGRE_CODE}));

      await provider.withdrawInfant(movementFormCreationMock).catch((error) => {
        expect(error).toEqual(new BadRequestException(undefined, UNIQUE_MOVEMENT_VIOLATION_MESSAGE));
        expect(movementFormServiceSpy).toHaveBeenCalledWith(movementFormCreationMock);
      });

    });

  });

  describe('getMovementTypes tests', () => {

    it('getMovementTypes should return OK if movement information is correct', async () => {

      const movementServiceSpy = spyOn(provider['movementService'], 'getMovementTypes').
        and.returnValue(Promise.resolve(movementTypesMock));

      expect(await provider.getMovementTypes()).toEqual(movementTypesMock);
      expect(movementServiceSpy).toHaveBeenCalledWith();

    });

  });

});
