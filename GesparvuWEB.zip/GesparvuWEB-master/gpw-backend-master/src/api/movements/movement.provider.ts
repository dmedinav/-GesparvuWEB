// nest
import { Injectable } from '@nestjs/common';

// services
import { AttendanceService } from '../../database/entities/attendance/attendance.service';
import { EnrollmentService } from '../../database/entities/enrollment/enrollment.service';
import { MovementFormService } from '../../database/entities/movementForm/movement-form.service';
import { MovementService } from './../../database/entities/movement/movement.service';
import { TransactionService } from '../../database/transaction/transaction.service';

// entities
import { MovementForm } from '../../database/entities/movementForm/movement-form.entity';

// dtos
import { MovementFormCreationDto } from './dto/movementForm.dto';
import { AttendanceInformationDto } from './../attendance/dto/attendance-creation.dto';

// common
import Utils from '../../common/utils/utils';
import { BadRequestException } from './../../common/exceptionFilters/custom-exceptions';
import { NotFoundException } from '../../common/exceptionFilters/custom-exceptions';
import { 
  DEFAULT_SUCCESSFUL_POST_RESPONSE, 
  SAVE_ERROR_MESSAGE, 
  UNIQUE_MOVEMENT_VIOLATION_MESSAGE,
  ENROLLMENT_NOT_FOUND_MESSAGE
 } from './../../common/constants/response-messages';
import { ENROLLMENT_NOT_FOUND } from './../../common/constants/response-codes';
import { IMovementTypes } from './../../common/interfaces/movement.interface';
import { IQueryTransaction } from '../../common/interfaces/query-transaction.interface';
import { UNIQUE_VIOLATION_POSTGRE_CODE } from './../../common/constants/misc';
import { READY_SIGE_CODE } from './../../common/constants/misc';
import { TransferDto } from './dto/transfer.dto';
import { InfantProvider } from '../infant/infant.provider';

@Injectable()
export class MovementProvider {

  constructor(
    private readonly attendanceService: AttendanceService,
    private readonly enrollmentService: EnrollmentService,
    private readonly movementFormService: MovementFormService,
    private readonly movementService: MovementService,
    private readonly transactionService: TransactionService,
    private readonly infantProvider: InfantProvider

  ) { }

  public async withdrawInfant(movementFormCreationDto: MovementFormCreationDto) {
    // update the modification date to now
    movementFormCreationDto.modificationDate = new Date();
    movementFormCreationDto.modifiedBy = process.env.JUNJI_RAD_POSTGRES_USER;
    movementFormCreationDto.typingDate = new Date();
    movementFormCreationDto.typed = true;

    const movementForm = movementFormCreationDto as MovementForm;

    // Create movement form in DB
    try {
      await this.movementFormService.withdrawInfant(movementForm);
    } catch (e) {
      if (e.code && e.code === UNIQUE_VIOLATION_POSTGRE_CODE) {
        throw new BadRequestException(undefined, UNIQUE_MOVEMENT_VIOLATION_MESSAGE);
      } else {
        throw new BadRequestException(undefined, SAVE_ERROR_MESSAGE);
      }
    }

    await this.enrollmentService.updateEnrollment(
      movementForm.enrollment,
      {
        retirementDate: movementForm.retirementDate,
        movement: movementForm.movement,
        sigeTransfer: READY_SIGE_CODE,
        modificationDate: new Date(),
        modifiedBy: process.env.JUNJI_RAD_POSTGRES_USER,
      }
    );

    // set delete all attendance from this day on
    const retirementYear = new Date(movementForm.retirementDate).getFullYear();
    const retirementMonth1Based = new Date(movementForm.retirementDate).getUTCMonth() + 1;
    const retirementDay = new Date(movementForm.retirementDate).getDate();
    const attendances = await this.attendanceService.getAttendancesForEnrollment(
      movementForm.enrollment
    );

    console.log('Mes retiro ${retirementYear}-${retirementMonth1Based}');

    for (const attendance of attendances) {
      console.log('Mes asistencia ${attendance.year}-${attendance.month}');
      if (attendance.year == retirementYear && attendance.month == retirementMonth1Based) {
        // If this is the retirement month, then change the retirment day and 
        // delete the next ones
        let attendanceObject = Utils.convertAttendanceObject(attendance);

        // create a copy of the monthly attendance to modify within the loop
        let monthlyAttendance = JSON.parse(attendanceObject.attendance);

        for (const day in JSON.parse(attendanceObject.attendance)) {
          if (parseInt(day) > retirementDay) {
            delete monthlyAttendance[day];
          }
        }

        const query = this.attendanceService.updateAttendanceObject({
          attendance: monthlyAttendance,
          id: attendance.id
        } as AttendanceInformationDto) as unknown as IQueryTransaction;

        await this.transactionService.executeTransaction([query]);

      } else {
        const attendanceDate = new Date(attendance.year, attendance.month, 1);
        console.log("---Fecha de asistencia vs fecha retiro---");
        let movementRetirementDate = new Date(movementForm.retirementDate)
        if (attendanceDate.setHours(0, 0, 0, 0) > movementRetirementDate.setHours(0, 0, 0, 0)) {
          console.log("...asistencia de un mes mayor al actual");
          // This is a month after the retirement month, delete it
          this.attendanceService.deleteAttendance(attendance);
        }
      }
    }

    return DEFAULT_SUCCESSFUL_POST_RESPONSE;
  }

  public async performTransfer(transferDto: TransferDto) {
    // TODO: Make this method's DB writes transactional
    const enrollment = await this.enrollmentService.getEnrollment(transferDto.enrollment);
    if (!enrollment) { throw new NotFoundException(ENROLLMENT_NOT_FOUND, ENROLLMENT_NOT_FOUND_MESSAGE); }

    let trasferDate = transferDto.transferDate;
    let withdrawDate = new Date(
      new Date(trasferDate).setDate(new Date(trasferDate).getDate() - 1)
      );
    if (new Date(trasferDate).setHours(0, 0, 0, 0) == new Date(enrollment.enrollmentDate).setHours(0, 0, 0, 0)) {
      withdrawDate = new Date(trasferDate);
    }

    const movementFormDto = new MovementFormCreationDto(
      transferDto.enrollment,
      // TODO: Use movement code for "traslado" instead of hardcoded 11.
      11,
      withdrawDate);
        

    const movementResult = await this.withdrawInfant(movementFormDto);
    if (movementResult === DEFAULT_SUCCESSFUL_POST_RESPONSE) {
      await this.infantProvider.createInfantForTransfer(transferDto);
    }
  }

  public async getMovementTypes(): Promise<IMovementTypes[]> {
    return await this.movementService.getMovementTypes();
  }

}
