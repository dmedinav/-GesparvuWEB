import { AuthGuard } from '@nestjs/passport';
import { IMovementTypes } from './../../common/interfaces/movement.interface';
import { MovementFormCreationDto } from './dto/movementForm.dto';
import { Controller, Post, Body, Get, UseGuards } from '@nestjs/common';
import { MovementProvider } from './movement.provider';
import { TransferDto } from './dto/transfer.dto';

@Controller('movements')
export class MovementController {

  constructor(private movementProvider: MovementProvider) { }

  @UseGuards((AuthGuard('jwt')))
  @Post('withdraw')
  public withdrawInfant(@Body() body: MovementFormCreationDto): Promise<any> {
    return this.movementProvider.withdrawInfant(body);
  }

  @UseGuards((AuthGuard('jwt')))
  @Post('transfer')
  public transferInfant(@Body() body: TransferDto): Promise<any> {
    return this.movementProvider.performTransfer(body);
  }

  @UseGuards((AuthGuard('jwt')))
  @Get('types')
  public getMovementTypes(): Promise<IMovementTypes[]> {
    return this.movementProvider.getMovementTypes();
  }
}
