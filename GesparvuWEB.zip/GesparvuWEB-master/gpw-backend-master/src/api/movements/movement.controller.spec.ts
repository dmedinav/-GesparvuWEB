import { movementFormCreationMock, movementTypesMock } from './../../common/mocks/movements';
import { Test, TestingModule } from '@nestjs/testing';
import { MovementController } from './movement.controller';
import { MovementProvider } from './movement.provider';

describe('Movements Controller', () => {
  let controller: MovementController;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [MovementController],
      providers: [
        {
          provide: MovementProvider, useValue: {
            withdrawInfant: () => undefined,
            getMovementTypes: () => undefined,
          },
        },
      ],
    }).compile();

    controller = module.get<MovementController>(MovementController);
  });

  it('should be defined', () => {
    expect(controller).toBeDefined();
  });

  it('withdrawInfant should return an object when is requested.', async () => {
    // tslint:disable-next-line:no-string-literal
    spyOn(controller['movementProvider'], 'withdrawInfant').and.returnValue(Promise.resolve(movementFormCreationMock));
    expect(await controller.withdrawInfant(movementFormCreationMock)).toEqual(movementFormCreationMock);
  });

  it('getMovementTypes should return an object when is requested.', async () => {
    // tslint:disable-next-line:no-string-literal
    spyOn(controller['movementProvider'], 'getMovementTypes').and.returnValue(Promise.resolve(movementTypesMock));
    expect(await controller.getMovementTypes()).toEqual(movementTypesMock);
  });

});
