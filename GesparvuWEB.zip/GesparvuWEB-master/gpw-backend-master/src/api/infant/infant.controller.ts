import { InfantCreationDto } from './dto/infant-creation.dto';
import { Controller, Get, UseGuards, Post, Body, Param } from '@nestjs/common';
import { AuthGuard } from '@nestjs/passport';
import { InfantParamsDto } from './dto/infant.dto';
import { InfantProvider } from './infant.provider';
import { ViewSimInfant } from '../../database/entities/viewSimInfant/view-sim-infant.entity';

@Controller('infants')
export class InfantController {
    constructor(private infantProvider: InfantProvider) {}

    @UseGuards(AuthGuard('jwt'))
    @Get('sim/:rut')
    public getInfant(@Param() params: InfantParamsDto): Promise<ViewSimInfant> {
      return this.infantProvider.getInfant(params.rut);
    }

    @UseGuards(AuthGuard('jwt'))
    @Post()
    public createInfant(@Body() infant: InfantCreationDto): Promise<any> {
      return this.infantProvider.createInfant(infant);
    }
}
