import { Test, TestingModule } from '@nestjs/testing';
import { InfantController } from './infant.controller';
import { InfantProvider } from './infant.provider';
import { SexualityService } from '../../database/entities/sexuality/sexuality.service';

describe('Infant Controller', () => {
  let controller: InfantController;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [InfantController],
      providers: [
        SexualityService,
        {
          provide: 'SexualityRepository',
          useValue: {
            find: () => {/**/},
          },
        },
        {
          provide: InfantProvider, useValue: {
            getInfant: () => undefined,
            createInfant: () => undefined,
          },
        },
      ],
    }).compile();

    controller = module.get<InfantController>(InfantController);
  });

  it('should be defined', () => {
    expect(controller).toBeDefined();
  });

  it('should return an infant when requested.', async () => {
    // tslint:disable-next-line:no-string-literal
    spyOn(controller['infantProvider'], 'getInfant').and.returnValue(Promise.resolve({}));
    expect(await controller.getInfant({rut: '22222222-1'})).toEqual({});
  });

  it('should create an infant when requested.', async () => {
    // tslint:disable-next-line:no-string-literal
    spyOn(controller['infantProvider'], 'createInfant').and.returnValue(Promise.resolve({}));
    expect(await controller.createInfant({} as any)).toEqual({});
  });

});
