// Services
import { AttendanceService } from '../../database/entities/attendance/attendance.service';
import { EnrollmentService } from '../../database/entities/enrollment/enrollment.service';
import { ExceptionService } from '../../database/entities/exception/exception.service';
import { GroupService } from '../../database/entities/group/group.service';
import { HolidayService } from '../../database/entities/holiday/holiday.service';
import { InfantFormService } from './../../database/entities/infantForm/infant-form.service';
import { InfantService } from '../../database/entities/infant/infant.service';
import { ViewSimInfantService } from '../../database/entities/viewSimInfant/view-sim-infant.service';
import Utils from '../../common/utils/utils';
import { Attendance } from '../../database/entities/attendance/attendance.entity';
import { BadRequestException, NotFoundException } from './../../common/exceptionFilters/custom-exceptions';
import { DEFAULT_SUCCESSFUL_POST_RESPONSE, SAVE_ERROR_MESSAGE, INFANT_NOT_FOUND_MESSAGE, EXISTING_INFANT_ERROR_MESSAGE, SAME_GROUP_ERROR, DIFFERENT_ESTABLISHMENT_ERROR } from './../../common/constants/response-messages';
import { ENROLLMENT_NOT_FOUND } from './../../common/constants/response-codes';
import { Enrollment } from '../../database/entities/enrollment/enrollment.entity';
import { Group } from '../../database/entities/group/group.entity';
import { IExceptionCalendar } from '../../common/interfaces/exception-calendar.interface';
import { Infant } from '../../database/entities/infant/infant.entity';
import { InfantCreationDto } from './dto/infant-creation.dto';
import { InfantForm } from '../../database/entities/infantForm/infant-form.entity';
import { Injectable } from '@nestjs/common';
import { Period } from '../../database/entities/period/period.entity';
import { ViewSimInfant } from '../../database/entities/viewSimInfant/view-sim-infant.entity';
import { TransferDto } from '../movements/dto/transfer.dto';
import { SimInfantService } from '../../database/entities/simInfant/sim-infant.service';

@Injectable()
export class InfantProvider {
  constructor(
    private readonly infantFormService: InfantFormService,
    private readonly infantService: InfantService,
    private readonly groupService: GroupService,
    private readonly enrollmentService: EnrollmentService,
    private readonly attendanceService: AttendanceService,
    private readonly viewSimInfantService: ViewSimInfantService,
    private readonly holidayService: HolidayService,
    private readonly exceptionService: ExceptionService,
    private readonly simInfantService: SimInfantService
  ) { }

  public async getInfant(rut: string): Promise<ViewSimInfant> {
    const rutArray = Utils.unformatRut(rut);
    const infant = await this.viewSimInfantService.getInfant(Number(rutArray[0]), rutArray[1]);
    if (!infant) { throw new NotFoundException(ENROLLMENT_NOT_FOUND, INFANT_NOT_FOUND_MESSAGE); }
    return infant;
  }

  public async createInfantForTransfer(transferDto: TransferDto) {
    const enrollment =
      await this.enrollmentService.getEnrollment(transferDto.enrollment);
    // Get the full group including its nested relations
    const currentGroup =
      await this.groupService.getGroup(enrollment.group.id);
    const newGroup =
      await this.groupService.getGroup(transferDto.newGroup);
    if (currentGroup.id === newGroup.id) {
      throw new BadRequestException(undefined, SAME_GROUP_ERROR);
    }
    if (currentGroup.establishment.id != newGroup.establishment.id) {
      throw new BadRequestException(undefined, DIFFERENT_ESTABLISHMENT_ERROR);
    }
    const infant: Infant = enrollment.infant;
    const infantDto = new InfantCreationDto(
      infant.rut + "-" + infant.rutDv,
      infant.names,
      infant.fathersLastname,
      infant.mothersLastname,
      infant.birthDate,
      infant.sexuality,
      transferDto.newGroup,
      transferDto.isPresent,
      "",
      transferDto.transferDate
    )
    return await this.createInfant(infantDto);
  }

  public async createInfant(infantDto: InfantCreationDto): Promise<any> {

    try {
      // Create infant form in DB
      const infantForm =
        await this.checkAndBuildInfantForm(infantDto) as unknown as InfantForm;
      const createdInfantForm = await this.infantFormService.createInfantForm(infantForm);

      // Create or update infant in DB
      const createdInfant =
        await this.createOrUpdateInfant(infantForm);

      const group = await this.groupService.getGroup(infantDto.group);

      // Create enrollment in DB
      const enrollment = this.buildEnrollment(
        infantDto,
        createdInfantForm.id,
        createdInfant,
        group) as Enrollment;
      const createdEnrollment =
        await this.enrollmentService.createEnrollment(enrollment);

      // Obtain periods for the created enrollment
      const periods = await this.enrollmentService.getEnrollmentPeriods(createdEnrollment);
      periods.forEach(async period => {
        // Create period's attendance list in DB
        let attendance = await this.buildAttendance(
          period, enrollment, createdInfantForm.isPresent);
        if (attendance != null) {
          await this.attendanceService.createAttendance(attendance);
        }
      });

      // Mark the infant form as done in order to prevent its future processing
      createdInfantForm.close(createdEnrollment.id);
      return DEFAULT_SUCCESSFUL_POST_RESPONSE;
    } catch (err) {
      throw new BadRequestException(undefined, SAVE_ERROR_MESSAGE, err);
    }
  }

  public async checkAndBuildInfantForm(infant: InfantCreationDto) {
    let withRut = false;
    let manual = true;
    let rut = null;
    let rutDv = null;
    let simInfant = null;
    if ('rut' in infant) {
      withRut = true;
      rut = Utils.unformatRut(infant.rut);
      rutDv = rut[1];
      rut = Number(rut[0]);
      try {
        simInfant = await this.getInfant(infant.rut);
        manual = false;
        // TODO: The following commented line meant that when creating a form
        // for an existing infant, previous data from the infant was used. Find
        // out if this is necessary or if it serves no purpose anymore now that
        // infants are automatically created or updated after the form creation.
        // Object.assign(infant, simInfant);
      } catch (err) {
        if (err.code === ENROLLMENT_NOT_FOUND) {
          manual = true;
        } else {
          throw err;
        }
      }
    }
    return this.buildInfantForm(infant, rut, rutDv, withRut, manual);
  }

  public buildInfantForm(infantDto: InfantCreationDto, rut: number, rutDv: string, withRut: boolean, manual: boolean) {
    const infantForm = new InfantForm();
    infantForm.rut = rut;
    infantForm.rutDv = rutDv;
    infantForm.birthDate =
      infantDto.birthDate ? new Date(infantDto.birthDate) : null;
    infantForm.names = infantDto.names;
    infantForm.fathersLastname = infantDto.fathersLastname;
    infantForm.mothersLastname = infantDto.mothersLastname;
    infantForm.group = infantDto.group;
    infantForm.isPresent = infantDto.isPresent;
    infantForm.manual = manual;
    infantForm.withRut = withRut;
    infantForm.sexuality = infantDto.sexuality;
    infantForm.description = infantDto.description;
    infantForm.enrollmentDate = infantDto.enrollmentDate;

    return infantForm;
  }

  public async createOrUpdateInfant(infantForm: InfantForm): Promise<Infant> {
    const existingInfant =
      await this.infantService.findByRut(infantForm.rut);
    let infant = await this.buildInfantFromForm(infantForm, existingInfant);
    return await this.infantService.createOrUpdateInfant(infant);
  }

  public async buildInfantFromForm(
    infantForm: InfantForm, existingInfant: Infant) {
    let infant = existingInfant;
    if (infant) {
      if (infant.normalized) {
        return infant;
      }
      else {
        infant.updateFromForm(infantForm);
      }
    }
    else {
      infant = new Infant();
      const simInfant = await this.simInfantService.findByRut(infantForm.rut);
      if (simInfant) {
        infant.updateFromSim(simInfant);
      }
      else {
        // Update infant from form
        infant.updateFromForm(infantForm);
      }
    }
    infant.sigeTransfer = 100;
    infant.ethnicGroup = 0;
    return infant;
  }

  public buildEnrollment(
    infantDto: InfantCreationDto,
    infantFormId: number,
    infant: Infant,
    group: Group) {
    let enrollment = new Enrollment();
    enrollment.enrollmentDate =
      infantDto.enrollmentDate ? new Date(infantDto.enrollmentDate) : null
    enrollment.infant = infant;
    enrollment.group = group;
    // TODO: Once known, use the correct value for this field
    enrollment.modifiedBy = "GPW dev";
    enrollment.modificationDate = new Date();
    enrollment.sigeTransfer = 100;
    enrollment.comment = "Solicitud GPW N " + infantFormId;
    return enrollment;
  }

  public async buildAttendance(
    period: Period,
    enrollment: Enrollment,
    presentOnEnrollmentDate: boolean) {

    let monthlyAttendance = await this.buildAttendanceDict(
      enrollment, period, presentOnEnrollmentDate);
    if (monthlyAttendance === null) {
      return null;
    }

    let attendance = new Attendance();

    attendance.month = period.month;
    attendance.year = period.year;
    attendance.order = 0;
    attendance.enrollment = enrollment
    // TODO: Once known, use the correct value for this field
    attendance.modifiedBy = "GPW dev";
    attendance.modificationDate = new Date();
    attendance.sigeTransfer = 100;
    let attendanceJson = { "asistencia": monthlyAttendance }
    attendance.attendance = JSON.stringify(attendanceJson);
    return attendance;
  }

  private async buildAttendanceDict(
    enrollment: Enrollment,
    period: Period,
    presentOnEnrollmentDate: boolean) {

    // If the enrollment is after this this period's end, no days should be added.
    // Note: In DB, period's months are 1-based, whereas JS Date uses 0-based
    // indexes for the months.
    const lastPeriodDay =
      Utils.getDaysInMonthWithDate(period.month, period.year);
    const periodEndDate =
      new Date(period.year, period.month - 1, lastPeriodDay);
    if (enrollment.enrollmentDate > periodEndDate) {
      return null;
    }

    const monthlyAttendance = {};
    // If the enrollment is inside this period, only add to attendance those
    // days contained in the period, from the enrollment date onwards.
    const enrollmentInPeriod =
      enrollment.enrollmentDate.getMonth() === period.month - 1
      && enrollment.enrollmentDate.getFullYear() === period.year;
    const firstDay = enrollmentInPeriod ?
      enrollment.enrollmentDate.getDate() : 1;

    // Create the dictionary with default values
    for (let i = firstDay; i <= lastPeriodDay; i++) {
      // TODO: Use attendance code instead of hardcoded 0.
      monthlyAttendance[i] = 0;
    }

    // Add attendance for enrollment date
    if (enrollmentInPeriod) {
      // TODO: Use attendance code instead of hardcoded number.
      monthlyAttendance[firstDay] = presentOnEnrollmentDate ? 1 : 2;
    }

    await this.addHolidaysToAttendance(
      enrollment,
      period,
      monthlyAttendance)

    return monthlyAttendance;
  }

  private async addHolidaysToAttendance(
    enrollment: Enrollment,
    period: Period,
    attendanceDict: Object) {
    const holidays = await this.holidayService.getHolidaysByMonthAndGroup(
      period.month, period.year, enrollment.group.id);
    this.addExceptionsToAttendanceDict(holidays, attendanceDict);

    const exceptions = await this.exceptionService.getExceptionsByMonthAndGroup(
      period.month, period.year, enrollment.group.id);
    this.addExceptionsToAttendanceDict(exceptions, attendanceDict);
  }

  private addExceptionsToAttendanceDict(
    exception: IExceptionCalendar[], attendanceDict: Object) {
    exception.forEach(e => {
      let date = e.date.getDate();
      if (date in attendanceDict) {
        // TODO: Use attendance code instead of hardcoded -1
        attendanceDict[date] = -1;
      }
    });
  }
}
