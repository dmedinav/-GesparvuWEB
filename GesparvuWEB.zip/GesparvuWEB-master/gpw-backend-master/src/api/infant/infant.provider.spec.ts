// services
import { AttendanceService } from '../../database/entities/attendance/attendance.service';
import { EnrollmentService } from '../../database/entities/enrollment/enrollment.service';
import { ExceptionService } from '../../database/entities/exception/exception.service';
import { GroupService } from '../../database/entities/group/group.service';
import { HolidayService } from '../../database/entities/holiday/holiday.service';
import { InfantFormService } from './../../database/entities/infantForm/infant-form.service';
import { InfantService } from '../../database/entities/infant/infant.service';
import { SimInfantService } from '../../database/entities/simInfant/sim-infant.service';
import { ViewSimInfantService } from '../../database/entities/viewSimInfant/view-sim-infant.service';

// entities
import { Enrollment } from '../../database/entities/enrollment/enrollment.entity';
import { InfantForm } from '../../database/entities/infantForm/infant-form.entity';

// DTO
import { InfantCreationDto } from './dto/infant-creation.dto';

import { ENROLLMENT_NOT_FOUND } from './../../common/constants/response-codes';
import { BadRequestException } from './../../common/exceptionFilters/custom-exceptions';
import { DEFAULT_SUCCESSFUL_POST_RESPONSE, SAVE_ERROR_MESSAGE, INFANT_NOT_FOUND_MESSAGE } from './../../common/constants/response-messages';
import {
  infantDatabaseMock,
  infantFinalWithoutManualAndWithRutMock,
  infantFinalWithManualAndWithRutMock,
  infantParsedRutMock,
  infantFinalWithManualAndWithoutRutMock,
} from './../../common/mocks/infant';
import { Test, TestingModule } from '@nestjs/testing';
import { InfantProvider } from './infant.provider';
import { NOW } from '../../common/mocks/common';
import { NotFoundException } from './../../common/exceptionFilters/custom-exceptions';

// tslint:disable:no-string-literal
describe('InfantProvider', () => {
  let provider: InfantProvider;
  let infantCreationMock;
  const originalDate = new Date(NOW);

  // Create a mockup for the enrollment created on createEnrollment
  const enrollment = new Enrollment();
  enrollment.id = 1;

  // Create a mockup for the infantForm created on createInfantForm
  const infantForm = new InfantForm();
  infantForm.close = jest.fn();

  jest.spyOn(global, 'Date').mockImplementation(() => originalDate as any);
  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [
        InfantProvider,
        {
          provide: AttendanceService,
          useValue: {
            createAttendance: () => {/**/ },
          },
        },
        {
          provide: EnrollmentService,
          useValue: {
            createEnrollment: () => enrollment,
            getEnrollmentPeriods: () => [],
          },
        },
        {
          provide: ExceptionService,
          useValue: {
          },
        },
        {
          provide: GroupService,
          useValue: {
            getGroup: () => {/**/ },
          },
        },
        {
          provide: HolidayService,
          useValue: {
          },
        },
        {
          provide: InfantFormService,
          useValue: {
            createInfantForm: () => infantForm,
          },
        },
        {
          provide: InfantService,
          useValue: {
            findByRut: () => {/**/ },
            createOrUpdateInfant: () => {/**/ },
          },
        },
        {
          provide: SimInfantService,
          useValue: {
            findByRut: () => {/**/ },
          },
        },
        {
          provide: ViewSimInfantService,
          useValue: {
            getInfant: () => {/**/ },
          },
        },
      ],
    }).compile();
    infantCreationMock = {
      rut: '26088597-9',
      fathersLastname: 'Fathers',
      mothersLastname: 'Mothers',
      names: 'Names',
      birthDate: originalDate,
      enrollmentDate: NOW,
      sexuality: 1,
      group: 254,
      isPresent: true,
      description: '',
    };
    provider = module.get<InfantProvider>(InfantProvider);
  });

  it('should be defined', () => {
    expect(provider).toBeDefined();
  });

  it('should create saved object if found on database', async () => {
    const creationSpy = spyOn(provider['infantFormService'], 'createInfantForm').and.returnValue(infantForm);

    spyOn(provider['viewSimInfantService'], 'getInfant').and.returnValue(Promise.resolve(infantDatabaseMock));

    const mock = await provider.createInfant(infantCreationMock);

    // create a new infantForm with the expected attributes to be passed to createInfantForm
    const notCreatedInfantForm = new InfantForm();
    Object.assign(notCreatedInfantForm, infantCreationMock);
    Object.assign(notCreatedInfantForm, infantFinalWithoutManualAndWithRutMock);
    Object.assign(notCreatedInfantForm, infantParsedRutMock);

    expect(creationSpy).toBeCalledWith(notCreatedInfantForm);
    expect(mock).toEqual(DEFAULT_SUCCESSFUL_POST_RESPONSE);
  });

  it('should return an error message when not found an infant', async () => {
    await provider.getInfant('22222222-1').catch(error => {
      expect(error).toEqual(new NotFoundException(ENROLLMENT_NOT_FOUND, INFANT_NOT_FOUND_MESSAGE));
    });
  });

  it('should return an ViewSimInfant object', async () => {
    spyOn(provider['viewSimInfantService'], 'getInfant').and.returnValue(Promise.resolve(infantDatabaseMock));
    await provider.getInfant('22222222-2').then(infant => {
      expect(infant).toEqual(infantDatabaseMock);
    });
  });

  it('should create saved object if not found on database with sended params', async () => {
    // when the provider calls infantFormService.createInfantForm return infantForm
    const creationSpy = spyOn(provider['infantFormService'], 'createInfantForm')
      .and.returnValue(infantForm);

    // when the provider calls viewSimInfantService.getInfant return an error
    spyOn(provider['viewSimInfantService'], 'getInfant')
      .and.returnValue(Promise.reject({ code: ENROLLMENT_NOT_FOUND }));

    const mock = await provider.createInfant(infantCreationMock);

    // create a new infantForm with the expected attributes to be passed to createInfantForm
    const notCreatedInfantForm = new InfantForm();
    Object.assign(notCreatedInfantForm, infantCreationMock);
    Object.assign(notCreatedInfantForm, infantFinalWithManualAndWithRutMock);
    Object.assign(notCreatedInfantForm, infantParsedRutMock);
    expect(creationSpy).toBeCalledWith(notCreatedInfantForm);

    expect(mock).toEqual(DEFAULT_SUCCESSFUL_POST_RESPONSE);
  });

  it('should create saved object if no rut is present in params', async () => {
    // when the provider calls infantFormService.createInfantForm return infantForm
    const creationSpy = spyOn(provider['infantFormService'], 'createInfantForm')
      .and.returnValue(infantForm);

    // when the eprovider calls viewSimInfantService.getInfant return undefined
    spyOn(provider['viewSimInfantService'], 'getInfant')
      .and.returnValue(Promise.resolve(undefined));

    // create an InfantCreationDto instance using the infantCreationMock
    const infantCreationMockDto =
      new InfantCreationDto(
        infantCreationMock.rut,
        infantCreationMock.names,
        infantCreationMock.fathersLastname,
        infantCreationMock.mothersLastname,
        infantCreationMock.birthDate,
        infantCreationMock.sexuality,
        infantCreationMock.group,
        infantCreationMock.isPresent,
        infantCreationMock.description,
        infantCreationMock.enrollmentDate)
    delete (infantCreationMockDto as any).rut;

    try {
      await provider.createInfant(infantCreationMockDto);
      // should not arrive to this
      expect(false).toBeTruthy();
    } catch (error) {
    }
  });

  it('should not create if an error occurs when getInfant return an exception different than not found', async () => {
    spyOn(provider['infantFormService'], 'createInfantForm').and.returnValue(Promise.resolve({}));
    spyOn(provider['viewSimInfantService'], 'getInfant').and.returnValue(Promise.reject({ code: 500 }));
    try {
      await provider.createInfant(infantCreationMock);
      expect(false).toBeTruthy();
    } catch (error) {
      expect(error).toEqual(new BadRequestException(undefined, SAVE_ERROR_MESSAGE, { code: 500 }));
    }
  });

  it('should not create if an error occurs', async () => {
    spyOn(provider['infantFormService'], 'createInfantForm').and.returnValue(Promise.reject());
    spyOn(provider['viewSimInfantService'], 'getInfant').and.returnValue(Promise.resolve(undefined));
    try {
      await provider.createInfant(infantCreationMock);
      expect(false).toBeTruthy();
    } catch (error) {
      expect(error).toEqual(new BadRequestException(undefined, SAVE_ERROR_MESSAGE));
    }
  });

});
