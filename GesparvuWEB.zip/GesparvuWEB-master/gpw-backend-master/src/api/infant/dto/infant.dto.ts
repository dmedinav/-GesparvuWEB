import { Type } from 'class-transformer';
import { IsRutValid } from '../../../common/validators/rut.validator';

export class InfantParamsDto {

  @Type(/* istanbul ignore next */ () => String)
  @IsRutValid()
  readonly rut: string;

}
