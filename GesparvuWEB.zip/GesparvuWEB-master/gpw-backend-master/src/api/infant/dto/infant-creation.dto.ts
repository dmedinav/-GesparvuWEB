import { Type } from 'class-transformer';
import { IsOptional, IsDateString, IsInt, IsBoolean, IsNotEmpty } from 'class-validator';
import { IsRutValid } from '../../../common/validators/rut.validator';

export class InfantCreationDto {

  @IsNotEmpty()
  @IsRutValid()
  @Type(/* istanbul ignore next */() => String)
  readonly rut: string;

  @IsNotEmpty()
  @Type(/* istanbul ignore next */() => String)
  readonly names: string;

  @IsNotEmpty()
  @Type(/* istanbul ignore next */() => String)
  readonly fathersLastname: string;

  @IsOptional()
  @Type(/* istanbul ignore next */() => String)
  readonly mothersLastname: string;

  @IsOptional()
  @IsDateString()
  readonly birthDate: Date;

  @IsOptional()
  @IsInt()
  readonly sexuality: number;

  @IsNotEmpty()
  @IsInt()
  readonly group: number;

  @IsNotEmpty()
  @IsBoolean()
  readonly isPresent: boolean;

  @IsOptional()
  @Type(/* istanbul ignore next */() => String)
  readonly description: string;

  @IsNotEmpty()
  @IsDateString()
  readonly enrollmentDate: Date;

  constructor(
    rut: string,
    names: string,
    fathersLastname: string,
    mothersLastname: string,
    birthDate: Date,
    sexuality: number,
    group: number,
    isPresent: boolean,
    description: string,
    enrollmentDate: Date) {
    this.rut = rut;
    this.names = names;
    this.fathersLastname = fathersLastname;
    this.mothersLastname = mothersLastname;
    this.birthDate = birthDate;
    this.sexuality = sexuality;
    this.group = group;
    this.isPresent = isPresent;
    this.description = description;
    this.enrollmentDate = enrollmentDate;
  }

}
