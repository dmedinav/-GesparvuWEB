import { InfantProvider } from './infant.provider';
import { InfantController } from './infant.controller';
import { InfantForm } from './../../database/entities/infantForm/infant-form.entity';
import { Infant } from './../../database/entities/infant/infant.entity';
import { InfantFormService } from './../../database/entities/infantForm/infant-form.service';
import { AuthModule } from './../auth/auth.module';
import { Module } from '@nestjs/common';
import { ViewSimInfantService } from '../../database/entities/viewSimInfant/view-sim-infant.service';
import { TypeOrmModule } from '@nestjs/typeorm';
import { InfantService } from '../../database/entities/infant/infant.service';
import { SexualityModule } from '../sexuality/sexuality.module';
import { GroupModule } from '../group/group.module';
import { EnrollmentModule } from '../enrollment/enrollment.module';
import { AttendanceModule } from '../attendance/attendance.module';
import { HolidayModule } from '../../database/entities/holiday/holiday.module';
import { ExceptionModule } from '../exception/exception.module';
import { SimInfantService } from '../../database/entities/simInfant/sim-infant.service';
import { SimInfant } from '../../database/entities/simInfant/sim-infant.entity';
import { TransferDto } from '../movements/dto/transfer.dto';

@Module({
  imports: [
    TypeOrmModule.forFeature([Infant]),
    TypeOrmModule.forFeature([InfantForm]),
    TypeOrmModule.forFeature([SimInfant]),
    AuthModule,
    SexualityModule,
    GroupModule,
    EnrollmentModule,
    AttendanceModule,
    HolidayModule,
    ExceptionModule,
    TransferDto
  ],
  providers: [
    InfantFormService,
    InfantService,
    InfantProvider,
    ViewSimInfantService,
    SimInfantService
  ],
  controllers: [InfantController],
  exports: [InfantProvider]
})
export class InfantModule { }
