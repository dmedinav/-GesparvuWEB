import { ExceptionTypeController } from './exception-type.controller';
import { ExceptionType } from './../../database/entities/exceptionType/exception-type.entity';
import { ExceptionTypeService } from './../../database/entities/exceptionType/exception-type.service';
import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { ExceptionTypeProvider } from './exception-type.provider';
import { AuthModule } from '../auth/auth.module';

@Module({
  imports: [TypeOrmModule.forFeature([ExceptionType]), AuthModule],
  controllers: [ExceptionTypeController],
  providers: [ExceptionTypeService, ExceptionTypeProvider],
})
export class ExceptionTypeModule {}
