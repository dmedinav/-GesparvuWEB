import { ExceptionTypeService } from './../../database/entities/exceptionType/exception-type.service';
import { exceptionTypeMock } from './../../common/mocks/exception-type';
import { Test, TestingModule } from '@nestjs/testing';
import { ExceptionTypeProvider } from './exception-type.provider';

describe('ExceptionTypeProvider', () => {
  let provider: ExceptionTypeProvider;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [
        ExceptionTypeProvider,
        {
          provide: ExceptionTypeService, useValue: {
            getAllExceptionTypes: () => undefined,
          },
        },
      ],
    }).compile();

    provider = module.get<ExceptionTypeProvider>(ExceptionTypeProvider);
  });

  it('should be defined', () => {
    expect(provider).toBeDefined();
  });

  it('getAllExceptionTypes should return an object when is requested', async () => {
    // tslint:disable-next-line:no-string-literal
    spyOn(provider['exceptionTypeService'], 'getAllExceptionTypes').and.returnValue(Promise.resolve([exceptionTypeMock]));
    expect(await provider.getAllExceptionTypes()).toEqual([exceptionTypeMock]);
  });
});
