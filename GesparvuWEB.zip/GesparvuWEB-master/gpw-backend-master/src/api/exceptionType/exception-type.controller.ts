import { ExceptionTypeProvider } from './exception-type.provider';
import { Controller, Get, UseGuards } from '@nestjs/common';
import { ExceptionType } from '../../database/entities/exceptionType/exception-type.entity';
import { AuthGuard } from '@nestjs/passport';

@Controller('exception-types')
export class ExceptionTypeController {

  constructor(private exceptionTypeProvider: ExceptionTypeProvider) {}

  @UseGuards(AuthGuard('jwt'))
  @Get()
  public getAllExceptionTypes(): Promise<ExceptionType[]> {
    return this.exceptionTypeProvider.getAllExceptionTypes();
  }
}
