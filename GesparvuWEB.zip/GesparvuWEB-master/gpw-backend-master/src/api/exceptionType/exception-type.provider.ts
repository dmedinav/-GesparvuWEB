import { ExceptionTypeService } from './../../database/entities/exceptionType/exception-type.service';
import { Injectable } from '@nestjs/common';
import { ExceptionType } from '../../database/entities/exceptionType/exception-type.entity';

@Injectable()
export class ExceptionTypeProvider {

  constructor(private readonly exceptionTypeService: ExceptionTypeService) {}

  public getAllExceptionTypes(): Promise<ExceptionType[]> {
    return this.exceptionTypeService.getAllExceptionTypes();
  }
}
