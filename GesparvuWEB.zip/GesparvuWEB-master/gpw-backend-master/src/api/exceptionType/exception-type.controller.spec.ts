import { ExceptionTypeProvider } from './exception-type.provider';
import { exceptionTypeMock } from './../../common/mocks/exception-type';
import { Test, TestingModule } from '@nestjs/testing';
import { ExceptionTypeController } from './exception-type.controller';

describe('ExceptionType Controller', () => {
  let controller: ExceptionTypeController;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [ExceptionTypeController],
      providers: [
        {
          provide: ExceptionTypeProvider, useValue: {
            getAllExceptionTypes: () => undefined,
          },
        },
      ],
    }).compile();

    controller = module.get<ExceptionTypeController>(ExceptionTypeController);
  });

  it('should be defined', () => {
    expect(controller).toBeDefined();
  });

  it('getAllExceptionTypes should return an object when is requested.', async () => {
    // tslint:disable-next-line:no-string-literal
    spyOn(controller['exceptionTypeProvider'], 'getAllExceptionTypes').and.returnValue(Promise.resolve([exceptionTypeMock]));
    expect(await controller.getAllExceptionTypes()).toEqual([exceptionTypeMock]);
  });

});
