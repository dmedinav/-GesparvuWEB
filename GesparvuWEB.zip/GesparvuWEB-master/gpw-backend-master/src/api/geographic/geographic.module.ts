import { GeographicService } from './../../database/entities/geographic/geographic.service';
import { GeographicController } from './geographic.controller';
import { County } from './../../database/entities/geographic/county.entity';
import { Province } from './../../database/entities/geographic/province.entity';
import { Region } from './../../database/entities/geographic/region.entity';
import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { GeographicProvider } from './geographic.provider';
import { AuthModule } from '../auth/auth.module';

@Module({
  imports: [TypeOrmModule.forFeature([Region, Province, County]), AuthModule],
  providers: [GeographicProvider, GeographicService],
  controllers: [GeographicController],
})
export class GeographicModule {}
