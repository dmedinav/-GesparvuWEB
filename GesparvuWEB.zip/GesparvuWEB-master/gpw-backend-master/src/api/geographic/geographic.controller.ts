import { Region } from './../../database/entities/geographic/region.entity';
import { GeographicProvider } from './geographic.provider';
import { Controller, Get, UseGuards } from '@nestjs/common';
import { AuthGuard } from '@nestjs/passport';

@Controller('geographic')
export class GeographicController {

  constructor(private geographicProvider: GeographicProvider) {}

  @UseGuards(AuthGuard('jwt'))
  @Get('all')
  public getAllGeographicInformation(): Promise<Region[]> {
    return this.geographicProvider.getAllGeographicInformation();
  }
}
