import { Region } from './../../database/entities/geographic/region.entity';
import { GeographicService } from './../../database/entities/geographic/geographic.service';
import { Injectable } from '@nestjs/common';

@Injectable()
export class GeographicProvider {

  constructor(private readonly geographicService: GeographicService) { }

  public async getAllGeographicInformation(): Promise<Region[]> {
    return this.geographicService.getRegionsWithProvincesAndCounties();
  }
}
