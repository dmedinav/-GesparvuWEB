import { GeographicProvider } from './geographic.provider';
import { Test, TestingModule } from '@nestjs/testing';
import { GeographicController } from './geographic.controller';

describe('Geographic Controller', () => {
  let controller: GeographicController;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [GeographicController],
      providers: [
        {
          provide: GeographicProvider, useValue: {
            getAllGeographicInformation: () => undefined,
          },
        },
      ],
    }).compile();

    controller = module.get<GeographicController>(GeographicController);
  });

  it('should be defined', () => {
    expect(controller).toBeDefined();
  });

  it('getAllGeographicInformation should return an object when is requested.', async () => {
    const expected = { };
    // tslint:disable-next-line:no-string-literal
    spyOn(controller['geographicProvider'], 'getAllGeographicInformation').and.returnValue(Promise.resolve(expected));
    expect(await controller.getAllGeographicInformation()).toEqual({ });
  });
});
