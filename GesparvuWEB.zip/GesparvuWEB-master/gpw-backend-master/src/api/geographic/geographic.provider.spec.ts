import { GeographicService } from './../../database/entities/geographic/geographic.service';
import { GeographicProvider } from './geographic.provider';
import { Test, TestingModule } from '@nestjs/testing';
import { regionDataMock } from '../../common/mocks/region';

describe('GeographicProvider', () => {
  let provider: GeographicProvider;
  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [
        GeographicProvider,
        {
          provide: GeographicService,
          useValue: {
            getRegionsWithProvincesAndCounties: () => {/**/},
          },
        },
      ],
    }).compile();
    provider = module.get<GeographicProvider>(GeographicProvider);
  });

  it('should be defined', () => {
    expect(provider).toBeDefined();
  });

  describe('getAllGeographicInformation', () => {
    it('should return an object.', async () => {
      // tslint:disable-next-line:no-string-literal
      spyOn(provider['geographicService'], 'getRegionsWithProvincesAndCounties').and.returnValue(Promise.resolve(regionDataMock));
      expect(await provider.getAllGeographicInformation()).toEqual(regionDataMock);
    });
  });
});
