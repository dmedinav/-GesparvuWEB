import { Test, TestingModule } from '@nestjs/testing';
import { GroupController } from './group.controller';
import { GroupProvider } from './group.provider';
import { groupDataMock } from '../../common/mocks/group';
import { userRequestMock } from '../../common/mocks/userReques';

describe('Group Controller', () => {
  let controller: GroupController;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [GroupController],
      providers: [
        {
          provide: GroupProvider, useValue: {
            getGroupsByTeacher: () => undefined,
          },
        },
      ],
    }).compile();

    controller = module.get<GroupController>(GroupController);
  });

  it('should be defined', () => {
    expect(controller).toBeDefined();
  });

  it('should return an array of groups.', async () => {
    // tslint:disable-next-line:no-string-literal
    spyOn(controller['groupProvider'], 'getGroupsByTeacher').and.returnValue(Promise.resolve([groupDataMock]));
    expect(await controller.getGroupsByTeacher(userRequestMock)).toEqual([groupDataMock]);
  });

});
