import { IsInt, IsPositive } from 'class-validator';
import { Type } from 'class-transformer';

export class GroupsByTeacherDto {
  @Type(/* istanbul ignore next */ () => Number)
  @IsInt()
  @IsPositive()
  readonly teacher: number;
}
