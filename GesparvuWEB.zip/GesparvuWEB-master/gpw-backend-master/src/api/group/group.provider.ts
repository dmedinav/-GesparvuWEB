import { Injectable } from '@nestjs/common';
import { GroupService } from '../../database/entities/group/group.service';
import { Group } from '../../database/entities/group/group.entity';

@Injectable()
export class GroupProvider {

  constructor(private readonly groupService: GroupService) { }

  public async getGroupsByTeacher(teacher: number): Promise<Group[]> {
    const groups = await this.groupService.getGroupsByTeacher(teacher);
    return groups;
  }

}
