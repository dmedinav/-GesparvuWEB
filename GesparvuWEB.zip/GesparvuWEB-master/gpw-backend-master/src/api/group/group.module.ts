import { AuthModule } from './../auth/auth.module';
import { Module } from '@nestjs/common';
import { Group } from '../../database/entities/group/group.entity';
import { TypeOrmModule } from '@nestjs/typeorm';
import { GroupService } from '../../database/entities/group/group.service';
import { GroupController } from './group.controller';
import { GroupProvider } from './group.provider';
import { PeriodModule } from '../../database/entities/period/period.module';

@Module({
  imports: [TypeOrmModule.forFeature([Group]), AuthModule, PeriodModule],
  exports: [GroupService],
  providers: [GroupProvider, GroupService],
  controllers: [GroupController],
})
export class GroupModule {}
