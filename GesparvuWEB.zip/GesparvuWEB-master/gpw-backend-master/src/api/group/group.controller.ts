import { AuthGuard } from '@nestjs/passport';
import { Controller, Get, UseGuards, Req } from '@nestjs/common';
import { Group } from '../../database/entities/group/group.entity';
import { GroupProvider } from './group.provider';
import { IUserRequest } from '../../common/interfaces/user-request.interface';

@Controller('groups')
export class GroupController {

  constructor(private groupProvider: GroupProvider) {}
  @UseGuards(AuthGuard('jwt'))
  @Get()
  public getGroupsByTeacher(@Req() request: IUserRequest): Promise<Group[]> {
    return this.groupProvider.getGroupsByTeacher(
      Number(request.user.rut),
    );
  }

}
