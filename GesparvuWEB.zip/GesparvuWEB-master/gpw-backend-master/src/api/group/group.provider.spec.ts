import { Test, TestingModule } from '@nestjs/testing';
import { GroupProvider } from './group.provider';
import { GroupService } from '../../database/entities/group/group.service';
import { groupDataMock, groupByTeacherParamsMock } from '../../common/mocks/group';

// tslint:disable:no-string-literal
describe('GroupProvider', () => {
  let provider: GroupProvider;
  const month = new Date().getUTCMonth();
  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [
        GroupProvider,
        {
          provide: GroupService,
          useValue: {
            getGroupsByTeacher: () => {/**/ },
          },
        },
      ],
    }).compile();
    provider = module.get<GroupProvider>(GroupProvider);
    spyOn(provider['groupService'], 'getGroupsByTeacher').and.returnValue(Promise.resolve([groupDataMock]));
  });

  it('should be defined', () => {
    expect(provider).toBeDefined();
  });

  it('should return an object with groups', () => {
    provider.getGroupsByTeacher(groupByTeacherParamsMock.teacher).then(async mock => {
      await expect(mock).toEqual([groupDataMock]);
    });
  });

});
