import { Enrollment } from './../../database/entities/enrollment/enrollment.entity';
import { ATTENDANCE_OBJECT_KEY } from './../constants/misc';
import { Attendance } from './../../database/entities/attendance/attendance.entity';
import { IAttendanceCodeTypes } from '../interfaces/attendance-type.interface';
import { AttendanceType } from '../../database/entities/attendanceType/attendance-type.entity';
import { IEnrollment, IEnrollments } from '../interfaces/enrollments.interface';

export default class Utils {

  static IsJsonString(objectString) {
    try {
      JSON.parse(objectString);
    } catch (e) {
      return false;
    }
    return true;
  }

  static getDaysInMonth() {
    const now = new Date();
    return new Date(now.getUTCFullYear(), now.getUTCMonth() + 1, 0).getDate();
  }

  static getDaysInMonthWithDate(month: number, year: number) {
    return new Date(year, month, 0).getUTCDate();
  }

  static findObjectsInObjectArray(array: any[], key: string) {
    return array.filter((element) => {
      if (key in element) { return element; }
    });
  }

  static findNewestDateInObjectArray(array: any[], key: string): any {
    array.sort((first, second) => {
      return +new Date(first[key]) - +new Date(second[key]);
    });
    return array[array.length - 1];
  }

  static fillMonthlyAttendanceObject(codeValue: number) {
    const daysInMonth = Utils.getDaysInMonth();
    const monthlyAttendance = {};
    for (let day = 1; day <= daysInMonth; day++) {
      monthlyAttendance[day] = codeValue;
    }
    return monthlyAttendance;
  }

  static formatAttendanceCodes(attendanceTypes: AttendanceType[]): any {
    const codes = {} as IAttendanceCodeTypes;
    attendanceTypes.forEach(attendanceType => {
      codes[attendanceType.type] = attendanceType.sigeCode;
    });
    return codes;
  }

  static cleanObject(obj: object) {
    for (const propName in obj) {
      if (obj[propName] === null || obj[propName] === undefined) {
        delete obj[propName];
      }
    }
  }

  static convertAttendanceObject(attendance: Attendance): Attendance {
    const attendanceObject = JSON.parse(attendance.attendance);
    attendance.attendance = JSON.stringify(attendanceObject[ATTENDANCE_OBJECT_KEY]);
    return attendance;
  }

  static unconvertAttendanceObject(attendance: object): object {
    return { [ATTENDANCE_OBJECT_KEY]: attendance };
  }

  static convertAttendanceArray(attendances: Attendance[]): Attendance[] {
    for (let attendance of attendances) {
      attendance = this.convertAttendanceObject(attendance);
    }
    return attendances;
  }

  static convertAttendanceArrayInEnrollments(enrollments: Enrollment[]): Enrollment[] {
    for (const enrollment of enrollments) {
      enrollment.attendances = this.convertAttendanceArray(enrollment.attendances);
    }
    return enrollments;
  }

  static unformatRut(rut: string) {
    const unformattedRut = rut;
    return unformattedRut.replace(/[. ]/g, '').split('-');
  }

  static isEnrolled(year: number, month: number, day: number, enrollment: IEnrollment) {
    const date = new Date(year, month, day).setHours(0, 0, 0, 0);
    const enrollmentDate = new Date(enrollment.enrollmentDate).setHours(0, 0, 0, 0);
    let retirementDate = null;
    if (enrollment.retirementDate) { retirementDate = new Date(enrollment.retirementDate).setHours(0, 0, 0, 0); }
    return (date >= enrollmentDate && (!retirementDate || date <= retirementDate));
  }

  static calculateTotals(enrollments: IEnrollments, attendanceCodes: IAttendanceCodeTypes, year: number, month: number): IEnrollments {
    enrollments.totalAttendance = 0;
    enrollments.dailyTotalAttendance = new Array(30).fill(0);

    for (const enrollment of enrollments.enrollments) {
      enrollment.totalAttendance = 0;
      enrollment.totalEnrolledDays = 0;

      const monthlyAttendance = JSON.parse(enrollment.attendances[0].attendance);
      for (const day of Object.keys(monthlyAttendance)) {
        if (monthlyAttendance[day] === attendanceCodes.RAD_ATTENDANCE_CODE) {
          enrollment.totalAttendance++;
          enrollments.dailyTotalAttendance[day]++;
        }
        if (Utils.isEnrolled(year, month - 1, Number(day), enrollment) && monthlyAttendance[day] !== attendanceCodes.RAD_HOLIDAY_CODE) {
          enrollment.totalEnrolledDays++;
        }
      }
      enrollments.totalAttendance += enrollment.totalAttendance;
    }
    return enrollments;
  }

}
