import Utils from '../../common/utils/utils';
import {
  attendanceWithoutMonthlyAttendanceMockWithoutKey,
  attendanceMock, attendanceWithKeyMock,
} from '../mocks/attendance';
import { enrollmentDataMock, enrollmentBaseMock } from '../../common/mocks/enrollment';
import { attendanceWithMonthlyAttendanceMock } from '../../common/mocks/attendance';
import { Attendance } from '../../database/entities/attendance/attendance.entity';

describe('Utils', () => {

  let attendances;
  let attendance;

  beforeEach(() => {
    attendances = [{
      id: 1,
      attendance: '{"asistencia": {"1": 1}}',
    }] as Attendance[];

    attendance = attendanceMock;
  });

  it('should calculate days in a month', () => {
    expect(Utils.getDaysInMonthWithDate(2, 2019)).toBe(28);
  });

  it('should remove the key of an attendance object', () => {
    expect(Utils.convertAttendanceObject(attendances[0]))
      .toStrictEqual(attendanceWithoutMonthlyAttendanceMockWithoutKey[0]);
  });

  it('should add a key to attendance object', () => {
    expect(Utils.unconvertAttendanceObject(attendance.attendance))
      .toStrictEqual(attendanceWithKeyMock.attendance);
  });

  it('should remove the key of an attendance arrays object', () => {
    expect(Utils.convertAttendanceArray(attendances))
      .toStrictEqual(attendanceWithoutMonthlyAttendanceMockWithoutKey);
  });

  it('should remove the key with undefined as value in object', () => {
    const expected = {
      key: 'value',
    };
    const testObject = {
      ...expected,
      secondKey: undefined,
    };
    Utils.cleanObject(testObject);
    expect(testObject)
      .toStrictEqual(expected);
  });

  it('should remove the key with null as value in object', () => {
    const expected = {
      key: 'value',
    };
    const testObject = {
      ...expected,
      secondKey: null,
    };
    Utils.cleanObject(testObject);
    expect(testObject)
      .toStrictEqual(expected);
  });

  it('should add a key of an enrollment arrays', () => {
    const enrollmentMock = enrollmentDataMock;
    enrollmentDataMock[0].attendances[0].attendance = attendanceWithMonthlyAttendanceMock.attendance;
    expect(Utils.convertAttendanceArrayInEnrollments(enrollmentDataMock))
      .toStrictEqual(enrollmentMock);
  });

  it('should return true', () => {
    const mock = enrollmentBaseMock;
    mock.retirementDate = new Date(2019, 9, 1);
    expect(Utils.isEnrolled(2019, 8, 1, mock)).toBeTruthy();
  });

});
