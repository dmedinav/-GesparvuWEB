import { Injectable, NestInterceptor, ExecutionContext, CallHandler } from '@nestjs/common';
import { map } from 'rxjs/operators';
import { Observable } from 'rxjs';
import { SexualityService } from '../../database/entities/sexuality/sexuality.service';

@Injectable()
export class SexualityInterceptorResponse implements NestInterceptor {

  constructor(private readonly sexualityService: SexualityService) { }

  intercept(context: ExecutionContext, next: CallHandler): Observable<any> {

    return next
      .handle()
      .pipe(
        map( async data => (
          Object.assign(
            data, { sexualities: await this.sexualityService.getAll() })
          ),
        ),
      );

  }
}
