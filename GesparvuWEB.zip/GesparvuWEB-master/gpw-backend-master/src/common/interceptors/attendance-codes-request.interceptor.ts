import { Injectable, NestInterceptor, ExecutionContext, CallHandler } from '@nestjs/common';
import { AttendanceTypeService } from '../../database/entities/attendanceType/attendance-type.service';
import Utils from '../utils/utils';

@Injectable()
export class AttendanceCodesInterceptorRequest implements NestInterceptor {

  constructor(private readonly attendanceTypeService: AttendanceTypeService) { }

  async intercept(context: ExecutionContext, next: CallHandler): Promise<any> {

    const request = context.switchToHttp().getRequest().body;
    request.attendanceCodes = Utils.formatAttendanceCodes(await this.attendanceTypeService.getAllAttendanceTypes());
    return next.handle().pipe();

  }
}
