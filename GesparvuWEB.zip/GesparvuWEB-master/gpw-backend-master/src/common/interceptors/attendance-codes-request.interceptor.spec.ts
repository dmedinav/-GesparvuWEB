import { Test, TestingModule } from '@nestjs/testing';
import { AttendanceCodesInterceptorRequest } from './attendance-codes-request.interceptor';
import { AttendanceTypeService } from '../../database/entities/attendanceType/attendance-type.service';
import { CallHandler, ExecutionContext } from '@nestjs/common';
import { of } from 'rxjs';
import { attendanceCodeTypesMock, attendanceCodesSigeMock } from '../mocks/attendance';

describe('AttendanceCodesInterceptorRequest', () => {
  let module: TestingModule;
  let interceptor: AttendanceCodesInterceptorRequest;
  let next: CallHandler;
  let context: ExecutionContext;

  beforeEach(async () => {
    module = await Test.createTestingModule({
      imports: [],
      providers: [
        AttendanceCodesInterceptorRequest,
        { provide: AttendanceTypeService, useValue: {getAllAttendanceTypes: () => Promise.resolve(attendanceCodesSigeMock) } },
      ],
    }).compile();

    interceptor = module.get<AttendanceCodesInterceptorRequest>(AttendanceCodesInterceptorRequest);

    next = { handle: () => of({ attendances: '' }) };
    const body = new Object();
    context = {
      switchToHttp: () => ({ getRequest: () => ({ body }) }),
    } as ExecutionContext;
  });

  it('should be defined.', () => {
    expect(interceptor).toBeDefined();
  });

  it('should have attendance codes in request', (done) => {
    interceptor.intercept(context, next).then((data) => {
      const request = context.switchToHttp().getRequest().body;
      expect(request.attendanceCodes).toEqual(attendanceCodeTypesMock);
      done();
    });
  });
});
