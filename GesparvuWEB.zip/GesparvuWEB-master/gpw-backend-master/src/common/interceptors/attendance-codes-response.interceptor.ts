import { Injectable, NestInterceptor, ExecutionContext, CallHandler } from '@nestjs/common';
import { AttendanceTypeService } from '../../database/entities/attendanceType/attendance-type.service';
import { map } from 'rxjs/operators';
import Utils from '../utils/utils';
import { Observable } from 'rxjs';

@Injectable()
export class AttendanceCodesInterceptorResponse implements NestInterceptor {

  constructor(private readonly attendanceTypeService: AttendanceTypeService) { }

  intercept(context: ExecutionContext, next: CallHandler): Observable<any> {

    return next
      .handle()
      .pipe(
        map( async data => (
          Object.assign(
            data, { attendanceCodes: Utils.formatAttendanceCodes(await this.attendanceTypeService.getAllAttendanceTypes()) })
          ),
        ),
      );

  }
}
