import { Test, TestingModule } from '@nestjs/testing';
import { AttendanceCodesInterceptorResponse } from './attendance-codes-response.interceptor';
import { AttendanceTypeService } from '../../database/entities/attendanceType/attendance-type.service';
import { CallHandler, ExecutionContext } from '@nestjs/common';
import { of } from 'rxjs';
import { attendanceCodeTypesMock, attendanceCodesSigeMock } from '../mocks/attendance';

describe('AttendanceCodesInterceptorResponse', () => {
  let module: TestingModule;
  let interceptor: AttendanceCodesInterceptorResponse;
  let next: CallHandler;

  beforeEach(async () => {
    module = await Test.createTestingModule({
      providers: [
        AttendanceCodesInterceptorResponse,
        { provide: AttendanceTypeService, useValue: {getAllAttendanceTypes: () => Promise.resolve(attendanceCodesSigeMock) } },
      ],
    }).compile();

    interceptor = module.get<AttendanceCodesInterceptorResponse>(AttendanceCodesInterceptorResponse);
    next = {
      handle: () => of({ attendances: '' }),
    } as CallHandler;
  });

  it('should be defined.', () => {
    expect(interceptor).toBeDefined();
  });

  it('should transform sige codes to attendance codes format', (done) => {

    interceptor.intercept({} as ExecutionContext, next).subscribe(async (data) => {
      const response = await data;
      expect(response.attendanceCodes).toEqual(attendanceCodeTypesMock);
      done();
    });
  });
});
