import { Test, TestingModule } from '@nestjs/testing';
import { CallHandler, ExecutionContext } from '@nestjs/common';
import { of } from 'rxjs';
import { SexualityInterceptorResponse } from './sexuality-response.interceptor';
import { SexualityService } from '../../database/entities/sexuality/sexuality.service';

describe('SexualityInterceptorResponse', () => {
  let module: TestingModule;
  let interceptor: SexualityInterceptorResponse;
  let next: CallHandler;

  beforeEach(async () => {
    module = await Test.createTestingModule({
      providers: [
        SexualityInterceptorResponse,
        { provide: SexualityService, useValue: {getAll: () => Promise.resolve({}) } },
      ],
    }).compile();

    interceptor = module.get<SexualityInterceptorResponse>(SexualityInterceptorResponse);
    next = {
      handle: () => of({ sexualities: '' }),
    } as CallHandler;
  });

  it('should be defined.', () => {
    expect(interceptor).toBeDefined();
  });

  it('should add sexualities to response object', (done) => {
    interceptor.intercept({} as ExecutionContext, next).subscribe(async (data) => {
      const response = await data;
      expect(response.sexualities).toEqual({});
      done();
    });
  });

});
