import { Validator } from 'class-validator';
import { IsRutValid } from './rut.validator';

describe('IsRutValidator', () => {

  class IsRutValidatorClass {
    @IsRutValid()
    public rut: string;

    constructor(rut: string) {
      this.rut = rut;
    }
  }

  const validator = new Validator();

  it('should return an error if rut is invalid.', async () => {
    const object = new IsRutValidatorClass('2222222-1');
    await validator.validate(object).then((errors) => expect(errors.length).toEqual(1));
  });

  it('should return an error if rut has no dv.', async () => {
    const object = new IsRutValidatorClass('2222222');
    await validator.validate(object).then((errors) => expect(errors.length).toEqual(1));
  });

  it('should return an error if rut length is less than 7.', async () => {
    const object = new IsRutValidatorClass('22222-1');
    await validator.validate(object).then((errors) => expect(errors.length).toEqual(1));
  });

  it('should not return any errors if rut is valid.', async () => {
    const object = new IsRutValidatorClass('26088597-9');
    await validator.validate(object).then((errors) => expect(errors.length).toEqual(0));
  });

  it('should not return any errors if rut is valid with K as dv.', async () => {
    const object = new IsRutValidatorClass('76271714-K');
    await validator.validate(object).then((errors) => expect(errors.length).toEqual(0));
  });

  it('should not return any errors if rut is valid with 0 as dv.', async () => {
    const object = new IsRutValidatorClass('18166270-0');
    await validator.validate(object).then((errors) => expect(errors.length).toEqual(0));
  });

});
