import { ValidationOptions, registerDecorator, ValidationArguments } from 'class-validator';
import { AttendanceInformationDto } from '../../api/attendance/dto/attendance-creation.dto';

export function IsAttendanceObjectValid(validationOptions?: ValidationOptions) {
  return (object, propertyName: string) => {
    registerDecorator({
      name: 'IsAttendanceObjectValid',
      target: object.constructor,
      propertyName,
      options: validationOptions,
      validator: { validate(attendances: AttendanceInformationDto[], validatorArguments) {
        return objectWithJustNumericKeys(attendances, validatorArguments);
      } },
    });
  };
}

function objectWithJustNumericKeys(attendances: AttendanceInformationDto[], validatorArguments: ValidationArguments) {
  // tslint:disable-next-line: no-string-literal
  const attendanceCodes = validatorArguments.object['attendanceCodes'];
  const allAttendanceCodes = Object.keys(attendanceCodes).map(key => attendanceCodes[key]);

  if (attendances !== undefined) {
    for (const attendance of attendances) {
      for (const key of Object.keys(attendance.attendance)) {
        const day = Number(key);
        if (isNaN(day) || day > 31 || day < 1 || !allAttendanceCodes.includes(attendance.attendance[day])) {
          return false;
        }
      }
    }
    return true;
  }
  return false;
}
