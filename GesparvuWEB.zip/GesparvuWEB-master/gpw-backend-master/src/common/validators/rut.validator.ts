import { ValidationOptions, registerDecorator, ValidationArguments } from 'class-validator';

export function IsRutValid(validationOptions?: ValidationOptions) {
  return (object, propertyName: string) => {
    registerDecorator({
      name: 'IsRutValid',
      target: object.constructor,
      propertyName,
      options: validationOptions,
      validator: { validate(rut: string, validatorArguments) {
        return validateRut(rut, validatorArguments);
      } },
    });
  };
}

/**
 * Validates that the given string complies with the chilean rut format
 * @param {string} rut
 * @returns {ValidationArguments} validatorArguments
 */
function validateRut(rut: string, validatorArguments: ValidationArguments) {
  // return non strings like undefined or null
  if (!rut) { return false; }

  const validateDv = rut.split('-');
  if (validateDv.length === 1) { return false; }
  rut = rut.replace('-', '');
  let body = rut.slice(0, -1);
  body = body.replace(/[^0-9]+/g, '');
  let checkDigit = rut.slice(-1).toUpperCase();

  if (body.length < 7) {
      return false;
  }
  let addition = 0;
  let multiple = 2;
  let index = 0;
  for (let i = 1; i <= body.length; i++) {

      index = multiple * parseInt(rut.charAt(body.length - i), 10);
      addition = addition + index;

      if (multiple < 7) {
          multiple = multiple + 1;
      } else {
          multiple = 2;
      }

  }
  const expectedCheckDigit = 11 - (addition % 11);
  checkDigit = (checkDigit === 'K') ? '10' : checkDigit;
  checkDigit = (checkDigit === '0') ? '11' : checkDigit;

  if (expectedCheckDigit !== parseInt(checkDigit, 10)) {
      return false;
  }

  return true;
}
