import { attendanceBadObjectMock, attendanceGoodObjectMock, attendanceCodeTypesMock } from './../mocks/attendance';
import { Validator } from 'class-validator';
import { IsAttendanceObjectValid } from './attendance-object.validator';

describe('AttendanceObjectValidator', () => {

  class AttendanceValidatorClass {
    @IsAttendanceObjectValid()
    public attendances: object;
    public attendanceCodes: object;

    constructor(attendanceCodes?: object, attendances?: object) {
      this.attendanceCodes = attendanceCodes;
      this.attendances = attendances;
    }
  }

  const validator = new Validator();

  it('should return an error if the attendance object is invalid.', async () => {
    const object = new AttendanceValidatorClass(attendanceCodeTypesMock, attendanceBadObjectMock);
    await validator.validate(object).then((errors) => expect(errors.length).toEqual(1));
  });

  it('should return an error if the attendance object is undefined.', async () => {
    const object = new AttendanceValidatorClass(attendanceCodeTypesMock, undefined);
    await validator.validate(object).then((errors) => expect(errors.length).toEqual(1));
  });

  it('should not return any errors if the attendance object is valid.', async () => {
    const object = new AttendanceValidatorClass(attendanceCodeTypesMock, attendanceGoodObjectMock);
    await validator.validate(object).then((errors) => expect(errors.length).toEqual(0));
  });
});
