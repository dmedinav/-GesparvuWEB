import { HttpStatus } from '@nestjs/common';

// tslint:disable:max-classes-per-file
export class CustomHttpException {
  public statusCode: number;
  public errorMessage: string;
  public code: number;
  public serviceMethod: string;
  public exceptionError: string;
}

export class BadRequestException extends CustomHttpException {
  constructor(
    code = 40000,
    errorMessage = 'The request could not be understood',
    exceptionError = null,
  ) {
    super();
    this.statusCode = HttpStatus.BAD_REQUEST;
    this.errorMessage = errorMessage;
    this.code = code;
    this.exceptionError = exceptionError;
  }
}
export class NotFoundException extends CustomHttpException {
  constructor(
    code = 40400,
    errorMessage = 'The resource you are trying to reach cant be found',
    exceptionError = null,
  ) {
    super();
    this.statusCode = HttpStatus.NOT_FOUND;
    this.errorMessage = errorMessage;
    this.code = code;
    this.exceptionError = exceptionError;
  }
}

export class UnauthorizedException extends CustomHttpException {
  constructor(
    code = 40100,
    errorMessage = 'Authorization is required to do this action',
    exceptionError = null,
  ) {
    super();
    this.statusCode = HttpStatus.UNAUTHORIZED;
    this.errorMessage = errorMessage;
    this.code = code;
    this.exceptionError = exceptionError;
  }
}

export class BadGatewayException extends CustomHttpException {
  constructor(
    code = 50200,
    errorMessage = null,
    exceptionError = null,
  ) {
    super();
    this.statusCode = HttpStatus.BAD_GATEWAY;
    this.errorMessage = errorMessage;
    this.code = code;
    this.exceptionError = exceptionError;
  }
}
