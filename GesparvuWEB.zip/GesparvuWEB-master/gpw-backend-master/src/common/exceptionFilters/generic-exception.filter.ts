import { Response, Request } from 'express';
import { ExceptionFilter, Catch, ArgumentsHost, HttpStatus, HttpException } from '@nestjs/common';
import { CustomHttpException } from './custom-exceptions';
import { LogService } from '../logs/logs.service';
import { DEFAULT_ERROR_MESSAGE } from '../constants/response-messages';

@Catch()
export class GenericExceptionFilter implements ExceptionFilter {
  private url: string;
  private response: Response;
  private request: Request;

  // tslint:disable-next-line:no-empty
  constructor(private readonly logService: LogService) {}

  public catch(exception: any, host: ArgumentsHost) {
    const ctx = host.switchToHttp();
    this.response = ctx.getResponse<Response>();
    this.request = ctx.getRequest<Request>();
    this.url = this.request.url;

    if (exception instanceof HttpException) { return this.handleHttpException(exception); }
    if (exception instanceof CustomHttpException) { return this.handleCustomHttpException(exception); }

    this.logService.error('[JUNJI-RAD-Backend] Unhandled exception', exception.toString(), this.url);

    this.response.status(HttpStatus.INTERNAL_SERVER_ERROR).json({
      statusCode: HttpStatus.INTERNAL_SERVER_ERROR,
      errorMessage: DEFAULT_ERROR_MESSAGE,
      path: this.url,
    });
  }

  private handleHttpException(exception: HttpException) {
    this.logService.error('[JUNJI-RAD-Backend] HTTP Exception', JSON.stringify(exception), this.url);
    return this.response.status(exception.getStatus()).json({
      statusCode: exception.getStatus(),
      errorMessage: exception.message,
      path: this.url,
    });
  }

  private async handleCustomHttpException(exception: CustomHttpException) {
    this.logService.error('[JUNJI-RAD-Backend] Custom HTTP Exception', JSON.stringify(exception), this.url);
    delete exception.exceptionError;
    const jsonResponse = { ...exception, path: this.url };
    return this.response
      .status(exception.statusCode)
      .json(jsonResponse);
  }
}
