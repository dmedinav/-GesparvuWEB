import { HttpException, ArgumentsHost } from '@nestjs/common';
import { Test, TestingModule } from '@nestjs/testing';
import { BadRequestException, NotFoundException, UnauthorizedException } from './custom-exceptions';
import { GenericExceptionFilter } from './generic-exception.filter';
import { LogService } from '../logs/logs.service';

describe('GenericExceptionFilter', () => {
  let module: TestingModule;
  let filter: GenericExceptionFilter;

  beforeEach(async () => {
    module = await Test.createTestingModule({
      providers: [
        GenericExceptionFilter,
        { provide: LogService, useValue: { error: () => {/**/} } },
      ],
    }).compile();

    filter = module.get<GenericExceptionFilter>(GenericExceptionFilter);
  });

  it('should be defined.', () => {
    expect(filter).toBeDefined();
  });

  describe('GenericExceptionFilter catch', () => {
    let responseJsonSpy: object;
    let logServiceSpy;
    // tslint:disable-next-line:no-empty
    const jsonObject = { json: () => { } };
    const context = {
      getResponse: () => {
        return {
          status: () => {
            return jsonObject;
          },
        };
      },
      getRequest: () => {
        return { url: 'exceptions', query: {}, body: { rut: '19' } };
      },
    };
    const host = { switchToHttp: () => context } as ArgumentsHost;

    beforeEach(() => {
      // tslint:disable-next-line:no-string-literal
      logServiceSpy = spyOn(filter['logService'], 'error');
      responseJsonSpy = spyOn(jsonObject, 'json');
    });

    it('should change the response when the exception type is HttpException.', () => {
      const expection = new HttpException('BadRequest', 400);
      filter.catch(expection, host);
      expect(responseJsonSpy).toBeCalledWith({
        statusCode: 400,
        errorMessage: 'BadRequest',
        path: 'exceptions',
      });
    });

    it('should change the response when the exception type is a generic error.', () => {
      const expection = new Error('null pointer exception');
      filter.catch(expection, host);
      expect(responseJsonSpy).toBeCalledWith({
        statusCode: 500,
        errorMessage: 'En estos momentos no podemos atender su solicitud.',
        path: 'exceptions',
      });
      expect(logServiceSpy).toBeCalled();
    });

    it('should change the response when the exception type is a BadRequestException.', async () => {
      const code = 1234;
      const expection = new BadRequestException(code);
      const expected = {
        statusCode: 400,
        errorMessage: 'The request could not be understood',
        path: 'exceptions',
        code: 1234,
      };
      await filter.catch(expection, host);
      expect(responseJsonSpy).toBeCalledWith(expected);
    });

    it('should change the response when the exception type is a UnauthorizedException.', async () => {
      const code = 1234;
      const expection = new UnauthorizedException(code);
      const expected = {
        statusCode: 401,
        errorMessage: 'Authorization is required to do this action',
        path: 'exceptions',
        code: 1234,
      };
      await filter.catch(expection, host);
      expect(responseJsonSpy).toBeCalledWith(expected);
    });

    it('should change the response when the exception type is a NotFoundException.', async () => {
      const expection = new NotFoundException();
      const expected = {
        statusCode: 404,
        errorMessage: 'The resource you are trying to reach cant be found',
        path: 'exceptions',
        code: 40400,
      };
      await filter.catch(expection, host);
      expect(responseJsonSpy).toBeCalledWith(expected);
    });
  });
});
