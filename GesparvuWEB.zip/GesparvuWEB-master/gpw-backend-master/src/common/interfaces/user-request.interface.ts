export interface IUserRequest {
  user: {
    rut: number;
  };
}
