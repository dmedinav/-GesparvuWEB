export interface IAttendanceCodeTypes {
  RAD_DEFAULT_CODE: number;
  RAD_ATTENDANCE_CODE: number;
  RAD_NO_ATTENDANCE_CODE: number;
  RAD_HOLIDAY_CODE: number;
  RAD_NO_ENROLLMENT_CODE: number;
  RAD_INVALID_DAY_CODE: number;
}
