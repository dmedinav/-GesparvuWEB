export interface IExceptionCalendar {
  date: Date;
  description: string;
  isHoliday: boolean;
  irrevocable?: boolean;
  timestamp: Date;
}
