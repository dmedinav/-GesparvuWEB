export interface JwtPayload {
  email: string;
  rut: number;
  teacherName: string;
  establishmentName: string;
}
