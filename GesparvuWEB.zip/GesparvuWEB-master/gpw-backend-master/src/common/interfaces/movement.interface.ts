export interface IMovementTypes {
  description: string;
  id: number;
}
