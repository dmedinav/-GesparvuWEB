import { Enrollment } from '../../database/entities/enrollment/enrollment.entity';

export interface IEnrollments {
  enrollments: IEnrollment[];
  isActiveMonth?: boolean;
  totalAttendance?: number;
  dailyTotalAttendance?: number[];
}

export interface IEnrollment extends Enrollment {
  totalAttendance?: number;
  totalEnrolledDays?: number;
}
