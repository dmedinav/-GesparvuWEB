export interface IQueryTransaction {
  sql: string;
  parameters: any[];
}
