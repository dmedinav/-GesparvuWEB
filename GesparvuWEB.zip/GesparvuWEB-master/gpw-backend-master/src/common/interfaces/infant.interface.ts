export interface IInfant {
    rut: number;
    rutDv: string;
    fathersLastname: string;
    mothersLastname: string;
    names: string;
    sexuality: number;
    birthDate: Date;
}