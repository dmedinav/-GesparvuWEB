export const UNIQUE_VIOLATION_POSTGRE_CODE = '23505';

export const MONTHS = [
  'Enero',
  'Febrero',
  'Marzo',
  'Abril',
  'Mayo',
  'Junio',
  'Julio',
  'Agosto',
  'Septiembre',
  'Octubre',
  'Noviembre',
  'Diciembre',
];

export const DAYS = [
  'D',
  'L',
  'M',
  'X',
  'J',
  'V',
  'S',
];

export const ATTENDANCE_OBJECT_KEY = 'asistencia';

export const UPDATE_TO_SEND_SIGE_CODE = 101;

export const CREATION_SIGE_CODE = 100;

export const READY_SIGE_CODE = 102;
