export const EXCEPTION_CREATION_ORDER = [
  'groupId',
  'establishmentId',
  'countyId',
  'regionId',
  'country',
];

export const IRREVOCABLE_DESCRIPTION = ' irrenunciable';
