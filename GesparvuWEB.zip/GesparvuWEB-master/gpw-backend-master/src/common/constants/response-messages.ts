
export const RETRIEVING_ERROR_MESSAGE = 'Hubo un error al obtener los datos';
export const UNIQUE_MOVEMENT_VIOLATION_MESSAGE = 'Ya existe un movimiento para la matrícula especificada';
export const SAVE_ERROR_MESSAGE = 'Hubo un error al guardar los datos, por favor verifica la información que se desea guardar';
export const ENROLLMENT_NOT_FOUND_MESSAGE = 'La matrícula a la que quiere acceder no existe en el sistema';
export const INFANT_NOT_FOUND_MESSAGE = 'El RUN ingresado no existe en el sistema';
export const IRREVOCABLE_HOLIDAY_MESSAGE = 'Este día tiene un feriado irrenunciable';
export const DEFAULT_SUCCESSFUL_POST_RESPONSE = {
  status: 'OK',
};
export const NO_ATTENDANCE_ERROR_MESSAGE = 'No existe asistencia para este dia';
export const UNAUTHORIZED_ERROR_MESSAGE = 'El email o la contraseña no fueron correctas, inténtalo nuevamente.';
export const DEFAULT_ERROR_MESSAGE = 'En estos momentos no podemos atender su solicitud.';
export const EXISTING_INFANT_ERROR_MESSAGE = rut => `Ya existe un párvulo con RUT ${rut} en el sistema`;
export const SAME_GROUP_ERROR = 'El párvulo ya está en el grupo de destino';
export const DIFFERENT_ESTABLISHMENT_ERROR = 'El grupo de destino debe ser del mismo establecimieto que el grupo actual';
