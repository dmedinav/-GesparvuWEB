import path = require('path');

export const EXCEL_NO_ATTENDANCE_CODE = 0;
export const EXCEL_ATTENDANCE_CODE = 1;
export const EXCEL_NOT_WORKING_DAY_CODE = 2;
export const EXCEL_NO_ENROLLMENT_CODE = 3;
export const EXCEL_TEMPLATE_PATH = path.dirname(require.main.filename) + '/../excel-templates/RAD_GPW.xlsx';

export const EXCEL_ENROLLMENT_COLUMN = 'A';
export const EXCEL_MONTH_COLUMN = 'B';
export const EXCEL_RUT_COLUMN = 'D';
export const EXCEL_NAMES_COLUMN = 'E';
export const EXCEL_FIRST_TABLE_COLUMN = 6;
export const EXCEL_TOTAL_ENROLLED_DAYS_COLUMN = 'AL';

export const EXCEL_DAYS_ROW = 4;
export const EXCEL_FIRST_TABLE_ROW = 6;
export const EXCEL_GROUP_INFO_CELL = 'F1';
export const EXCEL_DATE_INFO_CELL = 'F2';
export const EXCEL_TOTAL_ENROLLMENTS_CELL = 'D3';
