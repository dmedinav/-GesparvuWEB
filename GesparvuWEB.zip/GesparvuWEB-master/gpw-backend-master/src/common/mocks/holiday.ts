import { Holiday } from './../../database/entities/holiday/holiday.entity';

export const notIrrevocableGroupHolidayMock = {
  country: false,
  groupId: 1,
  irrevocable: false,
  timestamp: new Date(),
} as unknown as Holiday;

export const irrevocableGroupHolidayYesterdayMock = {
  country: false,
  groupId: 1,
  irrevocable: true,
  timestamp: new Date(new Date().setDate(new Date().getDate() - 1)),
} as unknown as Holiday;

export const irrevocableEstablishmentHolidayMock = {
  country: false,
  establishmentId: 1,
  irrevocable: true,
  timestamp: new Date(),
} as unknown as Holiday;

export const irrevocableGroupHolidayMock = {
  country: false,
  groupId: 1,
  irrevocable: true,
  timestamp: new Date(),
} as unknown as Holiday;

export const notIrrevocableEstablishmentHolidayMock = {
  country: false,
  establishmentId: 1,
  irrevocable: false,
  timestamp: new Date(),
} as unknown as Holiday;
