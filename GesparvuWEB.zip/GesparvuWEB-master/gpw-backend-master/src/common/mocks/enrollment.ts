import { NOW, ENROLLMENT_DATE } from './common';
import { Enrollment } from '../../database/entities/enrollment/enrollment.entity';
import { EnrollmentsDateParamsDto } from '../../api/enrollment/dto/enrollments-date-params.dto';
import { IEnrollments, IEnrollment } from '../interfaces/enrollments.interface';
import { EnrollmentsGroupIdDto } from '../../api/enrollment/dto/enrollment-group-id.dto';
import { EnrollmentsFilterDto } from '../../api/enrollment/dto/enrollments-filter.dto';
import { EnrollmentIdDto } from '../../api/enrollment/dto/enrollment-id.dto';

const attendanceDay = [{
  id: 1,
  attendance: 2,
}];

const attendanceDate = [{
  id: 1,
  attendance: '{"1": 2, "2": 1}',
}];

export const enrollmentBaseMock = {
  id: 1,
  enrollmentDate: new Date(ENROLLMENT_DATE),
  retirementDate: null,
  infant: {},
  group: {
    name: 'name',
    level: {
      label: 'A',
    },
  },
  movement: {},
  modifiedBy: '',
  modificationDate: new Date(NOW),
  sigeTransfer: 1,
  transferDate: new Date(NOW),
} as Enrollment;

export const enrollmentDataMock = [{
  ...enrollmentBaseMock,
  attendances: attendanceDate,
  totalAttendance: 1,
  totalEnrolledDays: 2,
}] as IEnrollment[];

export const enrollmentDataDayMock = {
  ...enrollmentBaseMock,
  attendances: attendanceDay,
};

const dailyTotalAttendance = [0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0];
const totalAttendance = 1;

export const enrollmentsDataActiveMockWithTotals = {
  enrollments: enrollmentDataMock,
  isActiveMonth: true,
  totalAttendance,
  dailyTotalAttendance,
} as IEnrollments;

export const enrollmentsDataActiveMock = {
  enrollments: enrollmentDataMock,
  isActiveMonth: true,
} as IEnrollments;

export const enrollmentsDataNotActiveMock = {
  enrollments: enrollmentDataMock,
  isActiveMonth: false,
  totalAttendance,
  dailyTotalAttendance,
} as IEnrollments;

export const enrollmentsDataDayActiveMock = {
  enrollments: [enrollmentDataDayMock],
  isActiveMonth: true,
};

export const enrollmentsDataDayNotActiveMock = {
  enrollments: [enrollmentDataDayMock],
  isActiveMonth: false,
};

export const enrollmentsGroupParamsMock = {
  id: 254,
} as EnrollmentsGroupIdDto;

export const enrollmentsByDateParamsMock = {
  year: 2019,
  month: 4,
} as EnrollmentsDateParamsDto;

export const enrollmentsParamsMock = {
  filter: 'filter',
} as EnrollmentsFilterDto;

export const enrollmentParamMock = {
  id: 1,
} as EnrollmentIdDto;
