import { IUserRequest } from '../interfaces/user-request.interface';

export const userRequestMock = {
  user: {
    rut: 11111111,
  },
} as IUserRequest;
