import { Group } from '../../database/entities/group/group.entity';
import { GroupDto } from '../../api/group/dto/group.dto';
import { GroupsByTeacherDto } from '../../api/group/dto/groups-by-teacher.dto';

export const groupDataMock = {
  id: 254,
  name: 'A',
  levelGrade: 8,
  modality: 2,
  program: 2,
  academicYear: 2019,
  sigeTransfer: null,
  transferDate: null,
  capacity: 5,
  workday: 2,
  enrollments: null,
  establishment: null,
  exceptions: null,
  groupTeachers: null,
  holidays: null,
  level: null,
  period: null,
} as Group;

export const groupParamsMock = {
  id: 254,
} as GroupDto;

export const groupByTeacherParamsMock = {
  teacher: 11111111,
} as GroupsByTeacherDto;
