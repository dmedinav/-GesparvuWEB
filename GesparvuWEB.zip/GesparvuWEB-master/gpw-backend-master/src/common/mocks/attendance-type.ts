import { AttendanceType } from '../../database/entities/attendanceType/attendance-type.entity';

export const attendanceTypeMock = {
  sigeCode: 1,
} as AttendanceType;
