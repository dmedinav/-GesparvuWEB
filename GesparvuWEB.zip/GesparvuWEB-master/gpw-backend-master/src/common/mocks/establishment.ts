import { Establishment } from './../../database/entities/establishment/establishment.entity';
import { EstablishmentsByCountyDto } from '../../api/establishment/dto/establishment.dto';

export const establishmentDataMock = {
  id: 1,
  rbd: 11111111,
  dvRbd: 1,
  establishmentCode: 2,
  name: '',
  website: '',
  authorizeMailExchange: '',
  county: null,
  responsible: '',
  dependency: '',
  startRoDate: new Date(),
  endRoDate: new Date(),
  status: '',
  resolution: '',
  resolutionDate: new Date(),
  gender: '',
  systemLoginDate: new Date(),
  updatedAt: new Date(),
  phoneAreaCode: '',
  phone: '',
  cellPhone: '',
  email: '',
  address: '',
  addressNumber: '',
  referenceAddress: '',
  postalCode: '',
  longitude: '',
  latitude: '',
  sigeTransfer: 1,
  transferDate: new Date(),
  groups: [],
} as Establishment;

export const establishmentParamsDtoMock = {
  county: 1,
} as EstablishmentsByCountyDto;
