import { NOW } from './common';
import { ViewSimInfant } from './../../database/entities/viewSimInfant/view-sim-infant.entity';

export const infantParsedRutMock = {
    rut: 26088597,
    rutDv: '9',
};

export const infantDatabaseMock: ViewSimInfant = {
    ...infantParsedRutMock,
    fathersLastname: 'TestF',
    mothersLastname: 'TestM',
    names: 'Test',
    sexuality: 1,
    birthDate: new Date(NOW),
};

export const infantFinalWithoutManualAndWithRutMock = {
    withRut: true,
    manual: false,
    enrollmentDate: NOW,
};

export const infantFinalWithManualAndWithRutMock = {
    withRut: true,
    manual: true,
    enrollmentDate: NOW,
};

export const infantFinalWithManualAndWithoutRutMock = {
    withRut: false,
    manual: true,
    enrollmentDate: new Date(NOW),
};
