import { ExceptionType } from './../../database/entities/exceptionType/exception-type.entity';

export const exceptionTypeMock = {
  id: 1,
  description: 'Test description',
  attendanceType: {},
  workDay: true,
  exceptions: [],
} as ExceptionType;
