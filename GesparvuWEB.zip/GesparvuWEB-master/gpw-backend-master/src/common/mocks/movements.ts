import { MovementFormCreationDto } from '../../api/movements/dto/movementForm.dto';
import { NOW } from './common';
import { IMovementTypes } from '../interfaces/movement.interface';

export const movementFormCreationMock = {
  enrollment: 1,
  movement: 2,
  retirementDate: new Date(NOW),
  modificationDate: new Date(NOW),
  modifiedBy: 'kunder',
} as unknown as MovementFormCreationDto;

export const movementTypesMock = [
  {
    id: 1,
    description: 'DESCRIPTION',
  },
] as IMovementTypes[];
