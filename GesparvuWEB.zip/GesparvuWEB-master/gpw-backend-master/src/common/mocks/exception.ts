import { Exception } from './../../database/entities/exception/exception.entity';
import { ExceptionCreationDto } from '../../api/exception/dto/exception.dto';
import { IExceptionCalendar } from '../interfaces/exception-calendar.interface';
import { ExceptionCalendarDto } from '../../api/exception/dto/exception-calendar.dto';

export const exceptionCreationDtoMock = {
  description: 'Description',
  exceptionType: 1,
  date: new Date(),
  group: 1,
} as ExceptionCreationDto;

export const exceptionCreationMock = {
  description: 'Description',
  exceptionType: 1,
  date: new Date(),
  group: 1,
} as unknown as Exception;

export const getExceptionsParamsDtoMock = {
  month: 5,
  year: 2019,
  group: 254,
} as ExceptionCalendarDto;

// tslint:disable: quotemark
export const exceptionAMock = {
  date: new Date("2019-05-01T03:00:00.000Z"),
  timestamp: new Date("2019-05-01T03:00:00.000Z"),
  irrevocable: null,
  isHoliday: false,
  description: 'exception 1',
};

// tslint:disable: quotemark
export const exceptionCMock = {
  date: new Date("2019-05-05T03:00:00.000Z"),
  timestamp: new Date("2019-05-05T03:00:00.002Z"),
  irrevocable: null,
  isHoliday: false,
  description: 'exception 3 - 2',
};

// tslint:disable: quotemark
export const exceptionBMock = {
  date: new Date("2019-05-04T03:00:00.000Z"),
    timestamp: new Date("2019-05-04T03:00:00.002Z"),
    irrevocable: null,
    isHoliday: false,
    description: 'exception 2',
};

// tslint:disable: quotemark
export const exceptionDMock = {
  date: new Date("2019-05-19T03:00:00.000Z"),
    timestamp: new Date("2019-01-04T03:00:00.002Z"),
    irrevocable: null,
    isHoliday: false,
    description: 'exception 4',
};

// tslint:disable: quotemark
export const exceptionsCalendarOnlyExceptionsMock = [
  exceptionAMock,
  exceptionBMock,
  {
    date: new Date("2019-05-04T03:00:00.000Z"),
    timestamp: new Date("2019-05-04T03:00:00.001Z"),
    irrevocable: null,
    isHoliday: false,
    description: 'exception 2',
  },
  {
    date: new Date("2019-05-05T03:00:00.000Z"),
    timestamp: new Date("2019-05-05T03:00:00.001Z"),
    irrevocable: null,
    isHoliday: false,
    description: 'exception 3 - 1',
  },
  exceptionCMock,
] as unknown as IExceptionCalendar[];

export const exceptionsCalendarOnlyExceptionsResultMock = [
  exceptionAMock,
  exceptionBMock,
  exceptionCMock,
] as unknown as IExceptionCalendar[];

export const exceptionsCalendarHolidaysFinalMock = [
  {
    date: new Date("2019-05-01T03:00:00.000Z"),
    timestamp: new Date("2019-05-01T03:00:00.000Z"),
    irrevocable: true,
    isHoliday: true,
    description: 'Feriado',
  },
  {
    date: new Date("2019-05-02T03:00:00.000Z"),
    timestamp: new Date("2019-05-01T03:00:00.000Z"),
    irrevocable: true,
    isHoliday: true,
    description: 'Feriado',
  },
  {
    date: new Date("2019-05-04T03:00:00.000Z"),
    timestamp: new Date("2019-05-04T03:00:00.000Z"),
    irrevocable: false,
    isHoliday: true,
    description: 'Feriado',
  },
  {
    date: new Date("2019-05-05T03:00:00.000Z"),
    timestamp: new Date("2019-05-05T03:00:00.000Z"),
    irrevocable: false,
    isHoliday: true,
    description: 'Feriado',
  },
  {
    date: new Date("2019-05-07T03:00:00.000Z"),
    timestamp: new Date("2019-05-01T03:00:00.000Z"),
    irrevocable: true,
    isHoliday: true,
    description: 'Feriado',
  },
  {
    date: new Date("2019-05-08T03:00:00.000Z"),
    timestamp: new Date("2019-05-01T03:00:00.000Z"),
    irrevocable: true,
    isHoliday: true,
    description: 'Feriado',
  },
] as unknown as IExceptionCalendar[];

export const exceptionsCalendarResultMock = [
  {
    date: new Date("2019-05-01T03:00:00.000Z"),
    timestamp: new Date("2019-05-01T03:00:00.000Z"),
    irrevocable: true,
    isHoliday: true,
    description: 'Feriado',
  },
  {
    date: new Date("2019-05-02T03:00:00.000Z"),
    timestamp: new Date("2019-05-01T03:00:00.000Z"),
    irrevocable: true,
    isHoliday: true,
    description: 'Feriado',
  },
  {
    date: new Date("2019-05-04T03:00:00.000Z"),
    timestamp: new Date("2019-05-04T03:00:00.002Z"),
    irrevocable: null,
    isHoliday: false,
    description: 'exception 2',
  },
  {
    date: new Date("2019-05-05T03:00:00.000Z"),
    timestamp: new Date("2019-05-05T03:00:00.002Z"),
    irrevocable: null,
    isHoliday: false,
    description: 'exception 3 - 2',
  },
  {
    date: new Date("2019-05-07T03:00:00.000Z"),
    timestamp: new Date("2019-05-01T03:00:00.000Z"),
    irrevocable: true,
    isHoliday: true,
    description: 'Feriado',
  },
  {
    date: new Date("2019-05-08T03:00:00.000Z"),
    timestamp: new Date("2019-05-01T03:00:00.000Z"),
    irrevocable: true,
    isHoliday: true,
    description: 'Feriado',
  },
] as unknown as IExceptionCalendar[];
