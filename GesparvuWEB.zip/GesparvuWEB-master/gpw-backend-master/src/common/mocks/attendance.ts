import { Attendance } from './../../database/entities/attendance/attendance.entity';
import { AttendanceInformationDto, MainAttendanceDto } from './../../api/attendance/dto/attendance-creation.dto';

export const attendanceWithoutMonthlyAttendanceMock = [{
  id: 1,
  attendance: '{"asistencia": {"1": 1}}',
}] as Attendance[];

export const attendanceWithMonthlyAttendanceMock = {
  id: 1,
  attendance: '{"1":1}',
};

export const attendanceWithoutMonthlyAttendanceMockWithoutKey = [{
  id: 1,
  attendance: attendanceWithMonthlyAttendanceMock.attendance,
}] as Attendance[];

export const attendanceMock = {
  attendance: { 1: 1 },
};

export const attendanceWithMonthlyAttendanceObjectMock = {
  id: 1,
  attendance: attendanceMock.attendance,
};

export const attendanceInformationDtoMock = {
  id: 1,
  attendance: attendanceMock.attendance,
} as AttendanceInformationDto;

export const attendanceGoodObjectMock = [attendanceMock];

export const attendanceWithKeyMock = {
  attendance: { asistencia: attendanceMock.attendance },
};

export const attendanceBadObjectMock = [{
  attendance: '{"asistencia": {"error": 1}}',
}];

export const attendanceCodeTypesMock = {
  RAD_DEFAULT_CODE: 0,
  RAD_ATTENDANCE_CODE: 1,
  RAD_NO_ATTENDANCE_CODE: 2,
  RAD_HOLIDAY_CODE: -1,
  RAD_NO_ENROLLMENT_CODE: -3,
  RAD_INVALID_DAY_CODE: 99,
};

export const attendanceCodesSigeMock = [
  { sigeCode: 0, type: 'RAD_DEFAULT_CODE' },
  { sigeCode: 1, type: 'RAD_ATTENDANCE_CODE' },
  { sigeCode: 2, type: 'RAD_NO_ATTENDANCE_CODE' },
  { sigeCode: -1, type: 'RAD_HOLIDAY_CODE' },
  { sigeCode: -3, type: 'RAD_NO_ENROLLMENT_CODE' },
  { sigeCode: 99, type: 'RAD_INVALID_DAY_CODE' },
];

export const mainAttendanceDtoMock = {
  attendances: [
    {
      id: 1,
      attendance: { 1: 2 },
    },
  ],
  attendanceCodes: attendanceCodeTypesMock,
} as MainAttendanceDto;

export const excelAttendancesMock = [
  {
    id: 32,
    attendance: '{asistencia: {"1": 0, "2": 0, "3": 0, "4": 0, "5": 0, "6": 0, "7": 0 }}',
    enrollment: {
      id: 2410,
      infant: {},
      group: {
        name: 'A',
        id: 254,
      },
    },
  },
  {
    id: 33,
    attendance: '{asistencia: {"1": 0, "2": 0, "3": 0, "4": 0, "5": 0, "6": 0, "7": 0 }}',
    enrollment: {
      id: 2411,
      infant: {},
      group: {
        name: 'B',
        id: 255,
      },
    },
  },
];

export const attendanceFromDBMock = {
  id: 1,
  month: 3,
  year: 2019,
  order: 0,
  attendance: '{"asistencia":{"1":1,"2":0,"3":0,"4":0,"5":0,"6":0,"7":0,"8":0,"9":0,"10":0,"11":0,"12":0,"13":0,"14":0,"15":0,"16":0,"17":0,"18":0,"19":0,"20":0,"21":0,"22":0,"23":0,"24":0,"25":0,"26":0,"27":0,"28":0,"29":0,"30":0,"31":0}}',
  modifiedBy: 'GPW dev',
  modificationDate: '2020-03-05T22:43:31.997Z',
  sigeTransfer: 100,
  transferDate: null
};

function* generateAttendanceYearListMock() {
  let month;
  let attendance;
  let daysInMonth;
  let monthAttendance;

  // Create an academicYear of 3 calendar years to test border cases
  for (let yearDelta = -1; yearDelta <= 1; yearDelta += 1) {
    month = 0;
    while (month++ < 12) {
      attendance = Object.assign({}, attendanceFromDBMock);
      attendance.year += yearDelta;
      attendance.month = month;
      daysInMonth = new Date(attendance.year, month, 0).getDate();

      let monthAttendance = {};

      for (let i = 1; i <= daysInMonth; i += 1) {
        monthAttendance[i] = i == 1 ? 1 : 0; // attendance on the first day every month
      }

      attendance.id = month;
      attendance.attendance = JSON.stringify({asistencia: monthAttendance});

      yield attendance
    }
  }
}

export const attendanceYearListMock = [ ...generateAttendanceYearListMock() ];
