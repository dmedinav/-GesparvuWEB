import { Region } from './../../database/entities/geographic/region.entity';

export const regionDataMock = {
  id: 1,
  name: 'Region',
  provinces: [],
  regionCode: 3234,
} as Region;
