import { Logger } from '@nestjs/common';
import { Test, TestingModule } from '@nestjs/testing';
import { LogService } from './logs.service';

describe('LogService', () => {
  let module: TestingModule;
  let service: LogService;

  beforeEach(async () => {
    module = await Test.createTestingModule({
      providers: [
        LogService,
      ],
    }).compile();

    service = module.get<LogService>(LogService);
  });

  it('should be defined.', () => {
    expect(service).toBeDefined();
  });

  it('error should send the log.', async () => {
    const expected = {
      message: '[JUNJI-RAD-Backend] Unhandled exception',
      exception: 'Exception 1',
      url: 'daily-attendance/',
      serviceMethod: 'service',
    };
    const consoleSpy = jest.spyOn(Logger.prototype, 'error');
    service.error('[JUNJI-RAD-Backend] Unhandled exception', 'Exception 1', 'daily-attendance/', 'service');
    expect(consoleSpy).toHaveBeenCalledWith(expected);
  });

  it('log call should send the log.', async () => {
    const consoleSpy = jest.spyOn(Logger.prototype, 'log');
    service.log('Log');
    expect(consoleSpy).toHaveBeenCalledWith('Log');
  });

  it('verbose call should send the log.', async () => {
    const consoleSpy = jest.spyOn(Logger.prototype, 'verbose');
    service.verbose('Log');
    expect(consoleSpy).toHaveBeenCalledWith('Log');
  });

  it('warn call should send the log.', async () => {
    const consoleSpy = jest.spyOn(Logger.prototype, 'warn');
    service.warn('Log');
    expect(consoleSpy).toHaveBeenCalledWith('Log');
  });

  it('debug call should send the log.', async () => {
    const consoleSpy = jest.spyOn(Logger.prototype, 'debug');
    service.debug('Log');
    expect(consoleSpy).toHaveBeenCalledWith('Log');
  });
});
