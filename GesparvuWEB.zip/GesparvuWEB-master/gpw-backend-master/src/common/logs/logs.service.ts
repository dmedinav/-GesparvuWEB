import { Injectable, Logger } from '@nestjs/common';

@Injectable()
export class LogService extends Logger {

  error(message: string, exception: string, url: string, serviceMethod?: string) {
    const payload = {
      message,
      exception,
      url,
      serviceMethod,
    };
    super.error(payload);
  }

  verbose(message: string) {
    super.verbose(message);
  }

  log(message: string) {
    super.log(message);
  }

  warn(message: string) {
    super.warn(message);
  }

  debug(message: string) {
    super.debug(message);
  }
}
