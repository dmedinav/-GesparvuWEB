import { LogService } from './common/logs/logs.service';
import { GenericExceptionFilter } from './common/exceptionFilters/generic-exception.filter';
import { NestFactory } from '@nestjs/core';
import { AppModule } from './app.module';
import { ValidationPipe } from '@nestjs/common';

async function bootstrap() {
  const app = await NestFactory.create(AppModule);
  const logService = app.get(LogService);
  app.enableCors();
  app.useGlobalPipes(new ValidationPipe({
    disableErrorMessages: false,
  }));
  app.useGlobalFilters(new GenericExceptionFilter(logService));
  const port = process.env.PORT || 3000;
  await app.listen(port, '0.0.0.0');
}
bootstrap();
