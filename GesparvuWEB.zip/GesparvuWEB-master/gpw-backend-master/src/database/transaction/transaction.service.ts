import { Injectable } from '@nestjs/common';
import { getManager } from 'typeorm';
import { IQueryTransaction } from '../../common/interfaces/query-transaction.interface';

@Injectable()
export class TransactionService {

  constructor() { /**/ }

  public executeTransaction(querys: IQueryTransaction[]) {
    return getManager().transaction(async transactionalManager => {
      for (const query of querys) {
        await transactionalManager.query(query[0], query[1]);
      }
    });
  }

}
