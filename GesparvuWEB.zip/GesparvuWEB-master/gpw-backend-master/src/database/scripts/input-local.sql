-- cd

-- \cd /Documentos/proyectos/Junji/junji-rad-backend/src/database/scripts

-- drop and create

\c postgres
drop database "gesparvu-dev";
create database "gesparvu-dev";
\c "gesparvu-dev"

--  schema

\i schema.sql

-- inserts

INSERT INTO estado_declaracion VALUES (1, '');

\COPY region FROM '/home/kunder/Documentos/proyectos/Junji/junji-rad-backend/src/database/scripts/data/region.csv' DELIMITERS ',' CSV;
\COPY provincia FROM '/home/kunder/Documentos/proyectos/Junji/junji-rad-backend/src/database/scripts/data/province.csv' DELIMITERS ',' CSV;
\COPY comuna FROM '/home/kunder/Documentos/proyectos/Junji/junji-rad-backend/src/database/scripts/data/county.csv' DELIMITERS ',' CSV;
\COPY establecimiento FROM '/home/kunder/Documentos/proyectos/Junji/junji-rad-backend/src/database/scripts/data/establishment.csv' DELIMITERS ',' CSV NULL AS 'null';
\COPY docente FROM '/home/kunder/Documentos/proyectos/Junji/junji-rad-backend/src/database/scripts/data/teacher.csv' DELIMITERS ',' CSV NULL AS 'null';
\i data/periodo.sql
\COPY grupo FROM '/home/kunder/Documentos/proyectos/Junji/junji-rad-backend/src/database/scripts/data/group.csv' DELIMITERS ',' CSV NULL AS 'null';
\COPY grupo_docente FROM '/home/kunder/Documentos/proyectos/Junji/junji-rad-backend/src/database/scripts/data/group_teacher.csv' DELIMITERS ',' CSV NULL AS 'null';
\COPY parvulo FROM '/home/kunder/Documentos/proyectos/Junji/junji-rad-backend/src/database/scripts/data/infant.csv' DELIMITERS ',' CSV NULL AS 'null';
\COPY matricula FROM '/home/kunder/Documentos/proyectos/Junji/junji-rad-backend/src/database/scripts/data/enrollment.csv' DELIMITERS ',' CSV NULL AS 'null';
\i data/attendance.sql
\i data/attendance_type.sql
\i data/exception_type.sql
\i data/exception.sql
\i data/holiday.sql
\i data/movement_type.sql
\i data/movement.sql
\i data/usuarios_ldap.sql

INSERT INTO grado_sige VALUES (1, 123, 'Sala cuna');

INSERT INTO nivel_grado VALUES (8, 0, 'Sala cuna heterogenea', 1, null);
INSERT INTO nivel_grado VALUES (9, 1, 'Sala cuna menor', 1, null);
INSERT INTO nivel_grado VALUES (10, 2, 'Sala cuna mayor', 1, null);

-- permissions

-- GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA public TO kunder;

insert into SIM_PARVULO values (18252167, '1', 'paterno', 'materno', 'nombre1 nombre2', TO_DATE('27/05/2019', 'DD/MM/YYYY'), 1);
insert into SIM_PARVULO values ('22222222', '2', 'Barone', 'Cavalieri', 'Alehandro', TO_DATE('27/05/2019', 'DD/MM/YYYY'), 2);

insert into sexualidad values (1, 'Femenina');
insert into sexualidad values (2, 'Masculina');

DROP view view_grupo_docente;
CREATE VIEW view_grupo_docente AS SELECT "docente_id" AS "teacher", "grupo_id" AS "group", "responsable" AS "responsable", "fecha_incorporacion" AS "incorporationDate", "fecha_retiro" AS "retirementDate" FROM grupo_docente;
