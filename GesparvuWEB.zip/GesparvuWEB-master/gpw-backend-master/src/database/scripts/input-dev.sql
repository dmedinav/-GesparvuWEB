-- cd

-- \cd /Documentos/proyectos/Junji/junji-rad-backend/src/database/scripts

-- drop and create

\c postgres
drop database "gesparvu";
create database "gesparvu";
\c "gesparvu"

--  schema

\i schema.sql

-- inserts

INSERT INTO estado_declaracion VALUES (1, '');

\COPY region FROM '/home/kunder/Documentos/proyectos/Junji/junji-rad-backend/src/database/scripts/data/region.csv' DELIMITERS ',' CSV;
\COPY provincia FROM '/home/kunder/Documentos/proyectos/Junji/junji-rad-backend/src/database/scripts/data/province.csv' DELIMITERS ',' CSV;
\COPY comuna FROM '/home/kunder/Documentos/proyectos/Junji/junji-rad-backend/src/database/scripts/data/county.csv' DELIMITERS ',' CSV;
\COPY establecimiento FROM '/home/kunder/Documentos/proyectos/Junji/junji-rad-backend/src/database/scripts/data/establishment.csv' DELIMITERS ',' CSV NULL AS 'null';
\COPY docente FROM '/home/kunder/Documentos/proyectos/Junji/junji-rad-backend/src/database/scripts/data/teacher.csv' DELIMITERS ',' CSV NULL AS 'null';
\COPY grupo FROM '/home/kunder/Documentos/proyectos/Junji/junji-rad-backend/src/database/scripts/data/group.csv' DELIMITERS ',' CSV NULL AS 'null';
\COPY grupo_docente FROM '/home/kunder/Documentos/proyectos/Junji/junji-rad-backend/src/database/scripts/data/group_teacher.csv' DELIMITERS ',' CSV NULL AS 'null';
\COPY parvulo FROM '/home/kunder/Documentos/proyectos/Junji/junji-rad-backend/src/database/scripts/data/infant.csv' DELIMITERS ',' CSV NULL AS 'null';
\COPY matricula FROM '/home/kunder/Documentos/proyectos/Junji/junji-rad-backend/src/database/scripts/data/enrollment.csv' DELIMITERS ',' CSV NULL AS 'null';
\i data/attendance.sql
\i data/attendance_type.sql
\i data/exception_type.sql
\i data/exception.sql
\i data/holiday.sql
\i data/movement_type.sql
\i data/movement.sql
\i data/usuarios_ldap.sql

-- permissions

GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA public TO kunder;
GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA public TO kunder;


