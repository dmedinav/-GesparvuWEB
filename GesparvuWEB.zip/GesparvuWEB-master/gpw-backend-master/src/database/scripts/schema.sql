-- tables

create table cargo
(
  id_cargo                      serial,
  nombre                        varchar(100) not null,

  primary key (id_cargo)
);

create table dig_log_rad
(
  id_dig_log_rad                serial,
  es_nuevo                      char(1) not null,
  fecha_cambio                  timestamp not null,
  orden                         int,
  cuenta_asistencia             int not null,
  cuenta_matricula              int not null,
  dig_usuario_id                int not null,
  asistencia_id                 int not null,

  primary key (id_dig_log_rad)
);

create table dig_rol
(
  id_dig_rol                    serial,
  cod_rol                       int not null,
  nombre                        varchar(40) not null,
  descripcion                   varchar(100) not null,
  estado                        varchar(20) not null,

  primary key (id_dig_rol)
);

create table dig_tipo_usuario
(
  id_dig_tipo_usuario           serial,
  nombre                        varchar(100) not null,

  primary key (id_dig_tipo_usuario)
);

create table dig_usuario_perfil
(
  dig_perfil_id                 int not null,
  dig_usuario_id                int not null,

  primary key (dig_perfil_id, dig_usuario_id)
);

create table direccion_regional
(
  id_direccion_regional         serial,
  cod_dre                       int not null,
  descripcion                   varchar(60) not null,
  telefono                      varchar(20),
  fax                           varchar(20),
  direccion                     varchar(100),
  ciu_id                        int,
  region_id                     int not null,

  primary key (id_direccion_regional)
);

create table estado_civil
(
  id_estado_civil               int not null,
  descripcion                   varchar(25),

  primary key (id_estado_civil)
);

create table estado_declaracion
(
  id_estado_declaracion int not null,
  nombre                        varchar(25) not null,

  primary key (id_estado_declaracion)
);

create table etnia
(
  id_etnia                      int not null,
  nombre                        varchar(80) not null,
  descripcion                   varchar(120),

  primary key (id_etnia)
);

create table grado_sige
(
  id_grado_sige                 int not null,
  cod_grado                     int not null,
  glosa_grado                   varchar(50) not null,

  primary key (id_grado_sige)
);

create table modalidad_curricular
(
  id_modalidad_curricular       int not null,
  cod_modalidad                 int not null,
  descripcion                   varchar(30) not null,

  primary key (id_modalidad_curricular)
);

create table nacionalidad
(
  id_nacionalidad               int not null,
  descripcion                   varchar(150) not null,

  primary key (id_nacionalidad)
);

create table necesidad_educ_espec
(
  id_necesidad_educ_espec       int not null,
  nombre                        varchar(80) not null,

  primary key (id_necesidad_educ_espec)
);

create table nivel_grado
(
  id_nivel_grado                int not null,
  cod_nivel                     int not null,
  glosa_nivel                   varchar(50) not null,
  grado_sige_id                 int not null,
  rango_edad                    varchar(100),

  primary key (id_nivel_grado)
);

create table pais
(
  id_pais                       int not null,
  nombre                        varchar(120) not null,
  cod_pais                      varchar(3),

  primary key (id_pais)
);

create table parvulo
(
  id_parvulo                    int not null,
  rut                           int not null,
  dv                            varchar(1) not null,
  apellido_paterno              varchar(50) not null,
  apellido_materno              varchar(50),
  nombres                       varchar(100) not null,
  sexualidad_id                 int not null,
  fecha_nacimiento              timestamp,
  fecha_defuncion               timestamp,
  comuna_id                     int,
  etnia_id                      int not null,
  nacionalidad_id               int,
  ndes_educvas_espc_id          int,
  telefono                      varchar(20),
  celular                       varchar(20),
  correo_electronico            varchar(100),
  direccion                     varchar(100),
  numero_direccion              varchar(20),
  numeo_dpto                    varchar(20),
  informacion_adicional         varchar(100),
  traspaso_sige                 int,
  traspaso_fecha                timestamp,

  primary key (id_parvulo)
);

create table planta
(
  id_planta                     int,
  establecimiento_id            int,
  docente_id                    int,
  cargo_id                      int,
  fecha_incorporacion           timestamp not null,
  fecha_fin                     timestamp,

  primary key (id_planta)
);

create table programa
(
  id_programa                   int not null,
  cod_programa                  int not null,
  descripcion                   varchar(35) not null,

  primary key (id_programa)
);

create table provincia
(
  id_provincia                  int not null,
  nombre                        varchar(30) not null,
  region_id                     int not null,

  primary key (id_provincia)
);

create table region
(
  id_region                     int not null,
  nombre                        varchar(80) not null,
  cod_region                    int not null,

  primary key (id_region)
);

create table sexualidad
(
  id_sexualidad                 int not null,
  descripcion                   varchar(20) not null,

  primary key (id_sexualidad)
);

create table solicitud_dia
(
  id_solicitud_dia              int not null,
  fecha_rectificacion           timestamp not null,
  resolucion                    varchar(30),
  solicitud                     varchar(16) not null,
  motivo                        text,
  estado                        varchar(21),
  fecha_resolucion              timestamp,
  numero_resolucion             varchar(20),
  modificado_por                varchar(30),
  fecha_modificacion            timestamp,

  primary key (id_solicitud_dia)
);

create table tipo_docente
(
  id_tipo_docente               int not null,
  nombre                        varchar(50) not null,
  descripcion                   varchar(120),

  primary key (id_tipo_docente)
);

create table tipo_jornada
(
  id_tipo_jornada               int not null,
  nombre                        varchar(30) not null,
  descripcion                   varchar(80),

  primary key (id_tipo_jornada)
);

create table tipo_movimiento
(
  id_tipo_movimiento            int not null,
  cod_tipo_mov                  char(1) not null,
  descripcion                   varchar(15) not null,

  primary key (id_tipo_movimiento)
);

create table tipo_responsabilidad
(
  id_tip_res                    int,
  nombre                        varchar(100),

  primary key (id_tip_res)
);

create table comuna
(
  id_comuna                     int not null,
  nombre                        varchar(80) not null,
  provincia_id                  int not null,

  primary key (id_comuna)
);

create table coordinacion
(
  id_coordinacion               int not null,
  cod_coordinacion              int not null,
  region_id                     int not null,
  nombre                        varchar(30),

  primary key (id_coordinacion)
);

create table dig_perfil
(
  id_dig_perfil                 int not null,
  dig_tpo_uro_id                int not null,
  nombre                        varchar(50) not null,
  descripcion                   varchar(100),
  estado                        varchar(20) default 'activo' not null,

  primary key (id_dig_perfil)  
);

create table dig_perfil_rol
(
  dig_perfil_id                 int not null,
  dig_rol_id                    int not null,

  primary key (dig_perfil_id, dig_rol_id)
);

create table dig_usuario
(
  id_dig_usuario                int not null,
  rut                           int not null,
  dv                            varchar(1) not null,
  coordinacion_id               int not null,
  direccion_regional_id         int not null,
  nombres                       varchar(60) not null,
  apellido_paterno              varchar(30) not null,
  apellido_materrno             varchar(30) not null,
  clave                         varchar(100) not null,
  estado                        varchar(15) not null,
  correo_electronico            varchar(50) not null,

  primary key (id_dig_usuario)
);

create table docente
(
  id_docente                    int not null,
  rut                           int not null unique,
  dv                            varchar(1) not null,
  apellido_paterno              varchar(50) not null,
  apellido_materno              varchar(500) not null,
  nombres                       varchar(100) not null,
  fecha_nacimiento              timestamp not null,
  sexualidad_id                 int not null,
  pais_id                       int not null,
  nacionalidad_id               int not null,
  etnia_id                      int not null,
  celular                       varchar(10) not null,
  correo_electronico            varchar(50) not null,
  edo_civil_id                  int not null,
  tipo_docente_id               int not null,

  primary key (id_docente)
);

create table ensenanza
(
  id_ensenanza                  int not null,
  cod_ensenanza                 int,
  edo_fto_ensenanza             varchar(22) not null,
  nivel_grado_id                int not null,

  primary key (id_ensenanza)
);

create table establecimiento
(
  id_establecimiento            int not null,
  rbd                           int not null,
  dv_rbd                        int,
  cod_establec                  int not null,
  nombre                        varchar(100) not null,
  sitio_web                     varchar(100),
  autorizo_intercambio_correo   char(1),
  comuna_id                     int not null,
  responsable                   varchar(100),
  dependencia                   varchar(8) not null,
  inicio_ro                     timestamp,
  termino_ro                    timestamp,
  estado                        varchar(36),
  resolucion                    varchar(10),
  fecha_resolucion              timestamp,
  genero                        varchar(14),
  ingreso_sistema               timestamp,
  actualizacion                 timestamp,
  codigo_area_telefono          varchar(3),
  telefono                      varchar(50),
  celular                       varchar(50),
  correo_electronico            varchar(100),
  direccion                     varchar(120),
  numero_direccion              varchar(10),
  direccion_referencia          varchar(200),
  codigo_postal                 varchar(15),
  longitud                      varchar(50),
  latitud                       varchar(50),
  traspaso_sige                 int,
  traspaso_fecha                timestamp,

  primary key (id_establecimiento)
);

create table grupo_docente
(
  grupo_id                      int not null,
  docente_id                    int not null,
  responsable                   char(1) not null,
  fecha_incorporacion           timestamp not null,
  fecha_retiro                  timestamp,

  primary key (docente_id, grupo_id)
);

create table grupo_solicitud_dia
(
  grupo_id                      int not null,
  soltud_dia_id                 int not null,
  modificado_por                varchar(30),
  fecha_modificacion            timestamp,

  primary key (grupo_id, soltud_dia_id)
);

create table jornada
(
  id_jornada                    int not null,
  inicio                        varchar(10) not null,
  termino                       varchar(10) not null,
  tipo_jornada_id               int not null,

  primary key (id_jornada)
);

create table movimiento
(
  id_movimiento                 serial,
  tipo_movimiento_id            int not null,
  correl_tipo_mov               int not null,
  descripcion                   varchar(40) not null,
  activo                        boolean not null,

  primary key (id_movimiento)
);

create table grupo
(
  id_grupo                      int not null,
  letra                         varchar(2) not null,
  nivel_grado_id                int not null,
  modalidad_id                  int not null,
  programa_id                   int not null,
  establecimiento_id            int not null,
  ano_escolar                   int not null,
  traspaso_sige                 int,
  traspaso_fecha                timestamp,
  capacidad                     int,
  jornada_id                    int,

  primary key (id_grupo)
);

create table matricula
(
  id_matricula                  int not null,
  fecha_incorporacion           timestamp not null,
  fecha_retiro                  timestamp,
  parvulo_id                    int not null,
  grupo_id                      int not null,
  movimiento_id                 int,
  modificado_por                varchar(30),
  fecha_modificacion            timestamp,
  traspaso_sige                 int,
  traspaso_fecha                timestamp,
  COMENTARIO                    VARCHAR(800),

  primary key (id_matricula)
);

create table asistencia
(
  id_asistencia                 serial,
  mes                           int not null,
  ano                           int not null,
  orden                         int not null,
  matricula_id                  int not null,
  asistencia                    varchar(4000) not null,
  modificado_por                varchar(30),
  fecha_modificacion            timestamp,
  traspaso_sige                 int,
  traspaso_fecha                timestamp,

  primary key (id_asistencia)
);

create table dig_log_asistencia
(
  id_dig_log_asistencia         serial,
  fecha                         timestamp not null,
  asistencia                    varchar(4) not null,
  presente                      int not null,
  asistencia_id                 int not null,
  dig_usuario_id                int not null,
  fecha_cambio                  timestamp not null,

  primary key (id_dig_log_asistencia)
);

create table docente_grupo
(
  id_doc_grupo                  int,
  iplanta_id                    int,
  grupo_id                      int,
  responsab_id                  int,
  fecha                         timestamp,

  primary key (id_doc_grupo)
);

create table tipo_asistencia
(
  id_tipo_asistencia            int,
  descripcion                   varchar(2000),
  cod_sige                      int,
  tipo                          varchar(100),

  primary key (id_tipo_asistencia)
);

create table tipo_excepcion
(
  id_tipo_excepcion             int not null,
  descripcion                   varchar(2000),
  tipo_asistencia_id            int,
  trabajo                       boolean,

  primary key (id_tipo_excepcion)
);

create table excepcion
(
  id_excepcion                  serial,
  fecha                         timestamptz,
  pais                          boolean,
  region_id                     int,
  comuna_id                     int,
  establecimiento_id            int,
  grupo_id                      int,
  tipo_excepcion_id             int,
  descripcion                   varchar(2000),
  fecha_creacion                timestamp default current_timestamp,

  primary key (id_excepcion)
);

create table feriados
(
  id_feriado                    serial,
  fecha                         timestamp,
  pais                          boolean,
  region_id                     int,
  comuna_id                     int,
  establecimiento_id            int,
  grupo_id                      int,
  asistencia_id                 int,
  irrenunciable                 boolean,
  fecha_creacion                timestamp default current_timestamp,

  primary key (id_feriado)
);

-- Tablas form

CREATE TABLE FORM_CIERRE_MATRICULA
(
  MATRICULA_ID         int,
  FECHA_INCORPORACION  timestamp,
  FECHA_MODIFICACION   timestamptz,
  FECHA_RETIRO         timestamptz,
  MODIFICADO_POR       VARCHAR(200),
  MOVIMIENTO_ID        int,
  FECHA_CREACION       timestamp default current_timestamp,
  DIGITADO             boolean default false,
  FECHA_DIGITACION     timestamp,

  primary key (MATRICULA_ID)
);


CREATE TABLE FORM_PARVULO
(
  RUN              int                       NOT NULL,
  RUN_DV           varchar(1)                 NOT NULL,
  APELL_PATERNO    varchar(100)           NOT NULL,
  APELL_MATERNO    varchar(100),
  NOMBRES          varchar(100)           NOT NULL,
  FEC_NACIM        timestamp,
  SEXO             varchar(10),
  FECHA_MATRICULA  timestamp                         NOT NULL,
  GRUPO_ID         int                       NOT NULL,
  FECHA_CREACION   timestamp default current_timestamp,
  INGRESADO_GP     boolean,
  FECHA_GP         timestamp,
  MANUAL           boolean,
  CON_RUT          boolean,
  COMENTARIO       VARCHAR(1000)

  -- primary key (id)
);

-- vistas

CREATE TABLE SIM_PARVULO
(
  RUN            int                      NOT NULL,
  RUN_DV         varchar(3), 
  APELL_PATERNO  varchar(60),
  APELL_MATERNO  varchar(60),
  NOMBRES        varchar(90),
  FEC_NACIM      timestamp,
  SEXO           varchar(3),

  primary key (RUN)
);

CREATE VIEW VIEW_PARVULO_SIM AS
select RUN,RUN_DV,APELL_PATERNO,APELL_MATERNO,NOMBRES,FEC_NACIM,SEXO from SIM_PARVULO;

CREATE TABLE USUARIO_LDAP
(
  USUARIO_LDAP        VARCHAR(100),
  RUT                 int,
  DV                  varchar(3),
  ESTABLECIMIENTO_ID  int
);

-- indices

create index ind_rut_par on parvulo (rut);
create index ind_rut_docente on docente (rut);
create index ind_cod_establec on establecimiento (cod_establec);
create index ind_id_establec on grupo (establecimiento_id);

-- foreign keys

alter table parvulo add foreign key (comuna_id) references comuna (id_comuna);
-- alter table parvulo add foreign key (etnia_id) references etnia (id_etnia);
-- alter table parvulo add foreign key (nacionalidad_id) references nacionalidad (id_nacionalidad);
-- alter table parvulo add foreign key (sexualidad_id) references sexualidad (id_sexualidad);
-- alter table parvulo add foreign key (ndes_educvas_espc_id) references necesidad_educ_espec (id_necesidad_educ_espec);

alter table planta add foreign key (establecimiento_id) references establecimiento (id_establecimiento);
alter table planta add foreign key (docente_id) references docente (id_docente);
alter table planta add foreign key (cargo_id) references cargo (id_cargo);

alter table provincia add foreign key (region_id) references region (id_region);

alter table comuna add foreign key (provincia_id) references provincia (id_provincia);

alter table coordinacion add foreign key (region_id) references region (id_region);

alter table dig_perfil add foreign key (dig_tpo_uro_id) references dig_tipo_usuario (id_dig_tipo_usuario);

alter table dig_perfil_rol add foreign key (dig_perfil_id) references dig_perfil (id_dig_perfil);
alter table dig_perfil_rol add foreign key (dig_rol_id) references dig_rol (id_dig_rol);

alter table dig_usuario add foreign key (direccion_regional_id) references direccion_regional (id_direccion_regional);
alter table dig_usuario add foreign key (coordinacion_id) references coordinacion (id_coordinacion);

-- alter table docente add foreign key (edo_civil_id) references estado_civil (id_estado_civil);
-- alter table docente add foreign key (etnia_id) references etnia (id_etnia);
-- alter table docente add foreign key (nacionalidad_id) references nacionalidad (id_nacionalidad);
-- alter table docente add foreign key (pais_id) references pais (id_pais);
-- alter table docente add foreign key (sexualidad_id) references sexualidad (id_sexualidad);
-- alter table docente add foreign key (tipo_docente_id) references tipo_docente (id_tipo_docente);

alter table ensenanza add foreign key (nivel_grado_id) references nivel_grado (id_nivel_grado);

alter table establecimiento add foreign key (comuna_id) references comuna (id_comuna);

alter table grupo_docente add foreign key (docente_id) references docente (id_docente);
alter table grupo_docente add foreign key (grupo_id) references grupo (id_grupo);

alter table grupo_solicitud_dia add foreign key (grupo_id) references grupo (id_grupo);
alter table grupo_solicitud_dia add foreign key (soltud_dia_id) references solicitud_dia (id_solicitud_dia);

alter table jornada add foreign key (tipo_jornada_id) references tipo_jornada (id_tipo_jornada);

alter table movimiento add foreign key (tipo_movimiento_id) references tipo_movimiento (id_tipo_movimiento);

alter table grupo add foreign key (establecimiento_id) references establecimiento (id_establecimiento);
-- alter table grupo add foreign key (modalidad_id) references modalidad_curricular (id_modalidad_curricular);
-- alter table grupo add foreign key (nivel_grado_id) references nivel_grado (id_nivel_grado);
-- alter table grupo add foreign key (programa_id) references programa (id_programa);
-- alter table grupo add foreign key (jornada_id) references jornada (id_jornada);

alter table matricula add foreign key (grupo_id) references grupo (id_grupo);
-- alter table matricula add foreign key (movimiento_id) references movimiento (id_movimiento);
alter table matricula add foreign key (parvulo_id) references parvulo (id_parvulo);

alter table asistencia add foreign key (matricula_id) references matricula (id_matricula);

alter table dig_log_asistencia add foreign key (asistencia_id) references asistencia (id_asistencia);
alter table dig_log_asistencia add foreign key (dig_usuario_id) references dig_usuario (id_dig_usuario);

alter table docente_grupo add foreign key (iplanta_id) references planta (id_planta);
alter table docente_grupo add foreign key (grupo_id) references grupo (id_grupo);
alter table docente_grupo add foreign key (responsab_id) references tipo_responsabilidad (id_tip_res);

alter table tipo_excepcion add foreign key (tipo_asistencia_id) references tipo_asistencia (id_tipo_asistencia);
alter table excepcion add foreign key (tipo_excepcion_id) references tipo_excepcion (id_tipo_excepcion);
alter table excepcion add foreign key (region_id) references region (id_region);
alter table excepcion add foreign key (comuna_id) references comuna (id_comuna);
alter table excepcion add foreign key (establecimiento_id) references establecimiento (id_establecimiento);
alter table excepcion add foreign key (grupo_id) references grupo (id_grupo);

alter table feriados add foreign key (asistencia_id) references tipo_asistencia (id_tipo_asistencia);
alter table feriados add foreign key (region_id) references region (id_region);
alter table feriados add foreign key (comuna_id) references comuna (id_comuna);
alter table feriados add foreign key (establecimiento_id) references establecimiento (id_establecimiento);
alter table feriados add foreign key (grupo_id) references grupo (id_grupo);

alter table FORM_CIERRE_MATRICULA add foreign key (MOVIMIENTO_ID) references movimiento (id_movimiento);
alter table FORM_CIERRE_MATRICULA add foreign key (MATRICULA_ID) references matricula (id_matricula);

alter table FORM_PARVULO add foreign key (GRUPO_ID) references grupo (id_grupo);

-- NUEVO

CREATE VIEW view_auth_docentes AS SELECT usuario_ldap.usuario_ldap AS "ldapUser",
    usuario_ldap.rut,
    usuario_ldap.dv AS "rutDv",
    usuario_ldap.establecimiento_id AS "establishmentId",
    split_part(docente.nombres::text, ' '::text, 1) AS "teacherName",
    establecimiento.nombre AS "establishmentName"
   FROM usuario_ldap
     LEFT JOIN docente ON usuario_ldap.rut = docente.rut
     LEFT JOIN establecimiento ON usuario_ldap.establecimiento_id = establecimiento.id_establecimiento;

CREATE TABLE PERIODO
(
  ano_parvulario   int not null,
  mes           int not null, 
  ano           int not null, 
  activo        boolean not null,

  primary key (mes, ano)
);

ALTER TABLE grupo
ALTER COLUMN ano_escolar SET DATA TYPE int USING ano_escolar::integer;

-- 30/7

ALTER TABLE grupo RENAME COLUMN ano_escolar TO ano_parvulario;

CREATE VIEW view_grupo_docente AS 
SELECT p.docente_id AS teacher, g.id_grupo AS "group", e.responsable, p.fecha_incorporacion AS incorporationdate, p.fecha_fin AS retirementdate
FROM grupo g, planta p, establecimiento e
WHERE 
  g.establecimiento_id = e.id_establecimiento AND 
  p.establecimiento_id = e.id_establecimiento;

-- 6/8

UPDATE sim_parvulo
SET sexo = 2                                            
WHERE sexo = 'M';

UPDATE sim_parvulo
SET sexo = 1                                            
WHERE sexo = 'F';

DROP VIEW VIEW_PARVULO_SIM;

ALTER TABLE SIM_PARVULO
ALTER COLUMN sexo SET DATA TYPE int USING sexo::integer;

CREATE VIEW VIEW_PARVULO_SIM AS
SELECT 
  RUN AS "rut",
  RUN_DV AS "rutDv" ,
  APELL_PATERNO AS "fathersLastname",
  APELL_MATERNO AS "mothersLastname",
  NOMBRES AS "names",
  FEC_NACIM AS "birthDate",
  SEXO AS "sexuality" 
FROM SIM_PARVULO;

-- 8/8

DROP VIEW view_grupo_docente;

CREATE VIEW view_grupo_docente AS 
SELECT p.docente_id AS teacher, g.id_grupo AS "group"
FROM grupo g, planta p, establecimiento e
WHERE 
  g.establecimiento_id = e.id_establecimiento AND 
  p.establecimiento_id = e.id_establecimiento;

create index ind_id_plan on PLANTA (establecimiento_id);
create index ind_id_engr on matricula (grupo_id);
create index ind_id_enpvr on matricula (parvulo_id);
