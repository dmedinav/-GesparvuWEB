-- tests

Insert into EXCEPCION (fecha, PAIS, COMUNA_ID, TIPO_EXCEPCION_ID, DESCRIPCION) Values (TO_DATE('27/05/2019', 'DD/MM/YYYY'), false, 13130, 2, 'Corte de agua Comunal San Ramon');
Insert into EXCEPCION (fecha, PAIS, COMUNA_ID, TIPO_EXCEPCION_ID, DESCRIPCION) Values (TO_DATE('27/05/2019', 'DD/MM/YYYY'), false, 13131, 2, 'Corte de agua Comunal San Joaquin');
Insert into EXCEPCION (fecha, PAIS, ESTABLECIMIENTO_ID, TIPO_EXCEPCION_ID, DESCRIPCION) Values (TO_DATE('01/06/2019', 'DD/MM/YYYY'), false, 9081, 6, 'Clases Sabado Jardin Mis Primeros pasos');
