Insert into TIPO_EXCEPCION Values 
(1, 'Consejo de Profesores',  4,    false),
(2, 'Problema Estructural',   4,    false),
(3, 'Actividad Comunal',      4,    false),
(6, 'Clases Sabados',         1,    true),
(7, 'Clases Feriado',         1,    true);