INSERT INTO TIPO_ASISTENCIA VALUES 
(1, 'Dia sin registro de asistencia',                                0,  'RAD_DEFAULT_CODE'),
(2, 'Dia Asistido',                                                  1,  'RAD_ATTENDANCE_CODE'),
(3, 'Dia ausente',                                                   2,  'RAD_NO_ATTENDANCE_CODE'),
(4, 'Dia No trabajado por calendario',                               -1, 'RAD_HOLIDAY_CODE'),
(5, 'Dia no matriculado (dependera de la matricula)',                -3, 'RAD_NO_ENROLLMENT_CODE'),
(6, 'Solo se utiliza para el dia 31 cuando el mes no tiene 31 dias', 99, 'RAD_INVALID_DAY_CODE');