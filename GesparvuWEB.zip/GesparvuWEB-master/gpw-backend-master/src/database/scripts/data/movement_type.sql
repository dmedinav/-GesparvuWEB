Insert into TIPO_MOVIMIENTO (ID_TIPO_MOVIMIENTO, COD_TIPO_MOV, DESCRIPCION) Values 
(1, 'D', 'Desertado'),
(2, 'T', 'Trasladado'),
(3, 'E', 'Egresado'),
(4, 'R', 'No Sigue'),
(5, 'H', 'Eliminado');