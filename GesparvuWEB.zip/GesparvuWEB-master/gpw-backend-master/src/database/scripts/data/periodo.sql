-- tests

Insert into PERIODO (ano_parvulario, mes, ano, activo) Values 
(2019, 3, 2019, false),
(2019, 4, 2019, false),
(2019, 5, 2019, true),
(2019, 6, 2019, true),
(2019, 7, 2019, true),
(2019, 8, 2019, true),
(2019, 9, 2019, true),
(2019, 10, 2019, false),
(2019, 11, 2019, false),
(2019, 12, 2019, false),
(2019, 1, 2020, false),
(2019, 2, 2021, false);

