import { ViewAuthTeacherService } from './view-auth-teacher.service';
import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';

@Module({
  imports: [TypeOrmModule.forRoot()],
  providers: [ViewAuthTeacherService],
  exports: [ViewAuthTeacherService],
})
export class ViewAuthTeacherModule {}
