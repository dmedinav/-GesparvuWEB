import { Test, TestingModule } from '@nestjs/testing';
import { ViewAuthTeacherService } from './view-auth-teacher.service';

jest.mock('typeorm', () => ({
  getManager: () => ({
    findOne: () => Promise.resolve({}),
  }),
  ViewColumn: () => jest.fn(),
  ViewEntity: () => jest.fn(),
}));

describe('ViewAuthTeacherService', () => {
  let service: ViewAuthTeacherService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [ViewAuthTeacherService],
    }).compile();

    service = module.get<ViewAuthTeacherService>(ViewAuthTeacherService);
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });

  it('should execute a find.', async () => {
    expect(await service.findLdapUserInformation('email@mail.com')).toEqual({});
  });

});
