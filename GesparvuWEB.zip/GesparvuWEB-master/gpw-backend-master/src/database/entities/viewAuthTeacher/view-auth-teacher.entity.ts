import { ViewEntity, ViewColumn } from 'typeorm';

@ViewEntity({
    name: 'view_auth_docentes',
})

export class ViewAuthTeacher {

  @ViewColumn()
  ldapUser: string;

  @ViewColumn()
  rut: number;

  @ViewColumn()
  rutDv: string;

  @ViewColumn()
  establishmentId: number;

  @ViewColumn()
  teacherName: string;

  @ViewColumn()
  establishmentName: string;
}
