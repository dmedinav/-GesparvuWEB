import { Injectable } from '@nestjs/common';
import { getManager } from 'typeorm';
import { ViewAuthTeacher } from './view-auth-teacher.entity';

@Injectable()
export class ViewAuthTeacherService {

  // tslint:disable-next-line:no-empty
  constructor() {}

  public findLdapUserInformation(ldapUser: string): Promise<ViewAuthTeacher> {
    return getManager().findOne(ViewAuthTeacher, { ldapUser });
  }

}
