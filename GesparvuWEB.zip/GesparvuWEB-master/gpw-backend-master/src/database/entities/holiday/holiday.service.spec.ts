import { notIrrevocableGroupHolidayMock } from '../../../common/mocks/holiday';
import { Test, TestingModule } from '@nestjs/testing';
import { HolidayService } from './holiday.service';
import { getExceptionsParamsDtoMock } from '../../../common/mocks/exception';

// tslint:disable:no-string-literal
describe('HolidayService', () => {
  let service: HolidayService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [
        HolidayService,
        {
          provide: 'GroupService',
          useValue: {
            getGroupLocationQuery: () => {/**/ },
          },
        },
        {
          provide: 'HolidayRepository',
          useValue: {
            createQueryBuilder: () => {/**/ },
          },
        },
      ],
    }).compile();

    service = module.get<HolidayService>(HolidayService);
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });

  it('should call both repositories on function call.', async () => {
    const groupQueryBuilderSpy = spyOn(service['groupService'], 'getGroupLocationQuery').and.returnValue({
      innerJoin: () => ({
        innerJoin: () => ({
          innerJoin: () => ({
            innerJoin: () => ({
              where: () => ({
                select: () => ({
                  addSelect: () => ({
                    addSelect: () => ({
                      addSelect: () => ({
                        getQuery: () => 'QUERY',
                      }),
                    }),
                  }),
                }),
              }),
            }),
          }),
        }),
      }),
    });

    const holidayQueryBuilderSpy = spyOn(service['holidayRepository'], 'createQueryBuilder').and.returnValue({
      innerJoin: () => ({
        where: () => ({
          setParameter: () => ({
            select: () => ({
              getMany: () => Promise.resolve(notIrrevocableGroupHolidayMock),
            }),
          }),
        }),
      }),
    });
    const holidays = await service.getHolidaysForGroupInDate(1, new Date());

    expect(groupQueryBuilderSpy).toBeCalledWith(1);
    expect(holidayQueryBuilderSpy).toBeCalledWith('holiday');
    expect(holidays).toEqual(notIrrevocableGroupHolidayMock);
  });

  it('should call getRawMany', async () => {
    // tslint:disable-next-line:no-string-literal
    spyOn(service['holidayRepository'], 'createQueryBuilder').and.returnValue({
      setParameter: () => ({
        innerJoin: () => ({
          where: () => ({
            andWhere: () => ({
              andWhere: () => ({
                orderBy: () => ({
                  select: () => ({
                    addSelect: () => ({
                      addSelect: () => ({
                        addSelect: () => ({
                          addSelect: () => ({
                            getRawMany: () => Promise.resolve({}),
                          }),
                        }),
                      }),
                    }),
                  }),
                }),
              }),
            }),
          }),
        }),
      }),
    } as any);

    expect(await service.getHolidaysByMonthAndGroup(
      getExceptionsParamsDtoMock.month,
      getExceptionsParamsDtoMock.year,
      getExceptionsParamsDtoMock.group,
    )).toEqual({});
  });

});
