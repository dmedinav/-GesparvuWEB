import { Holiday } from './holiday.entity';
import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { GroupService } from '../group/group.service';
import { IExceptionCalendar } from '../../../common/interfaces/exception-calendar.interface';

@Injectable()
export class HolidayService {
  constructor(
    @InjectRepository(Holiday)
    private readonly holidayRepository: Repository<Holiday>,
    private readonly groupService: GroupService,
  ) { }

  public async getHolidaysForGroupInDate(groupId: number, date: Date): Promise<Holiday[]> {
    const groups = this.groupService.getGroupLocationQuery(groupId);

    const holidays = this.holidayRepository.createQueryBuilder('holiday')
      .innerJoin('(' + groups + ')', 'groups', 'holiday.group.id = groups.id OR'
        + ' holiday.establishment.id = groups.establishment OR'
        + ' holiday.county.id = groups.county OR'
        + ' holiday.region.id = groups.region OR'
        + ' holiday.country = true')
      .where('holiday.date = :holidayDate', { holidayDate: date })
      .setParameter('groupid', groupId)
      .select([
        'holiday.establishment.id', 'holiday.group.id', 'holiday.county.id',
        'holiday.region.id', 'holiday.country', 'holiday.timestamp', 'holiday.irrevocable',
      ])
      .getMany();

    return holidays;
  }

  // tslint:disable: quotemark
  public getHolidaysByMonthAndGroup(month: number, year: number, group: number): Promise<IExceptionCalendar[]> {
    const groupQuery = this.groupService.getGroupLocationQuery(group);

    return this.holidayRepository.createQueryBuilder('holiday')
      .setParameter('groupid', group)
      .innerJoin('(' + groupQuery + ')', 'groups', 'holiday.group.id = groups.id OR'
        + ' holiday.establishment.id = groups.establishment OR'
        + ' holiday.county.id = groups.county OR'
        + ' holiday.region.id = groups.region OR'
        + ' holiday.country = true')
      .where("date_part('year', holiday.date) = :year", { year })
      .andWhere("date_part('month', holiday.date) = :month", { month })
      .andWhere('(holiday.group.id is null OR holiday.group.id = :group)', { group })
      .orderBy('holiday.date')
      .select(['holiday.date as date'])
      .addSelect(['holiday.timestamp as timestamp'])
      .addSelect(['holiday.irrevocable as irrevocable'])
      .addSelect('true', 'isHoliday')
      .addSelect("'Feriado'", 'description')
      .getRawMany();
  }

}
