import { AttendanceType } from './../attendanceType/attendance-type.entity';
import { County } from '../geographic/county.entity';
import { Entity, Column, PrimaryGeneratedColumn, ManyToOne, JoinColumn, CreateDateColumn, RelationId } from 'typeorm';
import { Group } from '../group/group.entity';
import { Region } from '../geographic/region.entity';
import { Establishment } from '../establishment/establishment.entity';

@Entity({name: 'feriados'})
export class Holiday {

  @PrimaryGeneratedColumn({name: 'id_feriado'})
  id: number;

  @Column({name: 'fecha'})
  date: Date;

  @Column({name: 'pais'})
  country: boolean;

  @ManyToOne(/* istanbul ignore next */ type => Region, /* istanbul ignore next */ region => region.holidays)
  @JoinColumn({name: 'region_id'})
  region: Region;

  @RelationId(/* istanbul ignore next */ (holiday: Holiday) => holiday.region)
  regionId: number;

  @ManyToOne(/* istanbul ignore next */ type => County, /* istanbul ignore next */ county => county.holidays)
  @JoinColumn({name: 'comuna_id'})
  county: County;

  @RelationId(/* istanbul ignore next */ (holiday: Holiday) => holiday.county)
  countyId: number;

  @ManyToOne(/* istanbul ignore next */ type => Establishment, /* istanbul ignore next */ establishment => establishment.holidays)
  @JoinColumn({name: 'establecimiento_id'})
  establishment: Establishment;

  @RelationId(/* istanbul ignore next */ (holiday: Holiday) => holiday.establishment)
  establishmentId: number;

  @ManyToOne(/* istanbul ignore next */ type => Group, /* istanbul ignore next */ group => group.holidays)
  @JoinColumn({name: 'grupo_id'})
  group: Group;

  @RelationId(/* istanbul ignore next */ (holiday: Holiday) => holiday.group)
  groupId: number;

  @ManyToOne(/* istanbul ignore next */ type => AttendanceType, /* istanbul ignore next */ attendanceType => attendanceType.holidays)
  @JoinColumn({name: 'asistencia_id'})
  attendanceType: AttendanceType;

  @Column({name: 'irrenunciable'})
  irrevocable: boolean;

  @CreateDateColumn({name: 'fecha_creacion'})
  timestamp: Date;

}
