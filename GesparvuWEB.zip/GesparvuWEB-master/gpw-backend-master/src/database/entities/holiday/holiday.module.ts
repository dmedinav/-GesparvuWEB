import { Group } from './../group/group.entity';
import { Holiday } from './holiday.entity';
import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { HolidayService } from './holiday.service';
import { GroupService } from '../group/group.service';
import { PeriodModule } from '../period/period.module';

@Module({
  imports: [TypeOrmModule.forFeature([Holiday, Group]), PeriodModule],
  providers: [HolidayService, GroupService],
  exports: [HolidayService],
})
export class HolidayModule {}
