import { Entity, Column, PrimaryGeneratedColumn, ManyToOne, JoinColumn } from 'typeorm';
import { Enrollment } from '../enrollment/enrollment.entity';

@Entity({name: 'asistencia'})
export class Attendance {

  @PrimaryGeneratedColumn({name: 'id_asistencia'})
  id: number;

  @Column({name: 'mes'})
  month: number;

  @Column({name: 'ano'})
  year: number;

  @Column({name: 'orden'})
  order: number;

  @ManyToOne(/* istanbul ignore next */ type => Enrollment, /* istanbul ignore next */ enrollment => enrollment.attendances)
  @JoinColumn({name: 'matricula_id'})
  enrollment: Enrollment;

  @Column({name: 'asistencia'})
  attendance: string;

  @Column({length: 30, name: 'modificado_por'})
  modifiedBy: string;

  @Column({name: 'fecha_modificacion'})
  modificationDate: Date;

  @Column({name: 'traspaso_sige'})
  sigeTransfer: number;

  @Column({name: 'traspaso_fecha'})
  transferDate: Date;
}
