import { UPDATE_TO_SEND_SIGE_CODE } from './../../../common/constants/misc';
import { AttendanceInformationDto } from './../../../api/attendance/dto/attendance-creation.dto';
import { Attendance } from './attendance.entity';
import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository, In } from 'typeorm';
import Utils from '../../../common/utils/utils';
import {MoreThanOrEqual} from "typeorm";

@Injectable()
export class AttendanceService {
  constructor(
    @InjectRepository(Attendance)
    private readonly attendanceRepository: Repository<Attendance>,
  ) { }

  public async getAttendancesObjectForIds(attendances: number[]): Promise<Attendance[]> {
    return Utils.convertAttendanceArray(
      await this.attendanceRepository.find({ select: ['id', 'attendance'], where: { id: In(attendances) } }),
    );
  }

  public createAttendance(attendance: Attendance): Promise<Attendance> {
    return this.attendanceRepository.save(attendance);
  }

  public deleteAttendance(attendance: Attendance) {
    this.attendanceRepository.delete(attendance.id);
  }

  public async  getAttendancesForGroupInDate(groupId: number, month: number, year: number): Promise<Attendance[]> {
    return Utils.convertAttendanceArray(
      await this.attendanceRepository.createQueryBuilder('attendance')
        .leftJoinAndSelect('attendance.enrollment', 'enrollment')
        .where('enrollment.group.id = :group', { group: groupId })
        .andWhere('attendance.year = :year', { year })
        .andWhere('attendance.month = :month', { month })
        .select(['attendance.id', 'attendance.attendance'])
        .getMany(),
    );
  }

  public async  getAttendancesForEnrollment(enrollmentId: number): Promise<Attendance[]> {
    return this.attendanceRepository.find({
      where: {
        enrollment: enrollmentId
      },
    });
  }

  public updateAttendanceObject(attendanceInformation: AttendanceInformationDto) {
    const query = { id: attendanceInformation.id };
    const monthlyAttendance = JSON.stringify(Utils.unconvertAttendanceObject(attendanceInformation.attendance));
    return this.attendanceRepository
      .createQueryBuilder('attendance')
      .update({ attendance: monthlyAttendance, sigeTransfer: UPDATE_TO_SEND_SIGE_CODE })
      .where(query)
      .getQueryAndParameters();
  }

}
