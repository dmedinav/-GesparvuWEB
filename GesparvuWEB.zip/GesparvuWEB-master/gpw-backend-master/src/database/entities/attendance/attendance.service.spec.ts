import {
  attendanceInformationDtoMock,
  attendanceWithoutMonthlyAttendanceMock,
  attendanceWithoutMonthlyAttendanceMockWithoutKey,
} from './../../../common/mocks/attendance';
import { Test, TestingModule } from '@nestjs/testing';
import { AttendanceService } from './attendance.service';

describe('AttendanceService', () => {
  let service: AttendanceService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [
        AttendanceService,
        {
          provide: 'AttendanceRepository',
          useValue: {
            find: () => {/**/ },
            update: () => {/**/ },
            createQueryBuilder: () => {/**/ },
          },
        },
      ],
    }).compile();

    service = module.get<AttendanceService>(AttendanceService);
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });

  it('should call find on function call.', async () => {
    // tslint:disable-next-line:no-string-literal
    spyOn(service['attendanceRepository'], 'find').and.returnValue(Promise.resolve(attendanceWithoutMonthlyAttendanceMockWithoutKey));
    expect(await service.getAttendancesObjectForIds([1])).toEqual(attendanceWithoutMonthlyAttendanceMockWithoutKey);
  });

  it('should call the orm api on function call and return attendances for a group', async () => {
    // tslint:disable-next-line:no-string-literal
    const queryBuilderSpy = spyOn(service['attendanceRepository'], 'createQueryBuilder').and.returnValue({
      leftJoinAndSelect: () => ({
        where: () => ({
          andWhere: () => ({
            andWhere: () => ({
              select: () => ({
                getMany: () => Promise.resolve(attendanceWithoutMonthlyAttendanceMock),
              }),
            }),
          }),
        }),
      }),
    });
    const attendances = await service.getAttendancesForGroupInDate(1, 2019, 12);

    expect(queryBuilderSpy).toBeCalledWith('attendance');
    expect(attendances).toEqual(attendanceWithoutMonthlyAttendanceMock);
  });

  it('should update the attendance object.', async () => {
    const query = { id: attendanceInformationDtoMock.id };
    // tslint:disable-next-line:no-string-literal
    const updateSpyOn = spyOn(service['attendanceRepository'], 'createQueryBuilder').and.returnValue({
      update: () => ({
        where: () => ({
          getQueryAndParameters: () => Promise.resolve({}),
        }),
      }),
    } as any);
    const updateObject = await service.updateAttendanceObject(attendanceInformationDtoMock);
    expect(updateSpyOn).toBeCalledWith('attendance');
    expect(updateObject).toEqual({});
  });

});
