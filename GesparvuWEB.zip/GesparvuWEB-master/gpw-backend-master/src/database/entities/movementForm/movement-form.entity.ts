import { Movement } from '../movement/movement.entity';
import { Enrollment } from '../enrollment/enrollment.entity';
import { Entity, Column, CreateDateColumn, PrimaryColumn, OneToOne, JoinColumn } from 'typeorm';

@Entity({name: 'form_cierre_matricula'})
export class MovementForm {

  @PrimaryColumn({name: 'matricula_id'})
  @OneToOne(/* istanbul ignore next */ type => Enrollment)
  @JoinColumn({name: 'matricula_id'})
  enrollment: number;

  @Column({name: 'movimiento_id'})
  @OneToOne(/* istanbul ignore next */ type => Movement)
  @JoinColumn({name: 'movimiento_id'})
  movement: number;

  @Column({name: 'modificado_por'})
  modifiedBy: string;

  @Column({name: 'fecha_retiro'})
  retirementDate: Date;

  @Column({name: 'fecha_modificacion'})
  modificationDate: Date;

  @CreateDateColumn({name: 'fecha_creacion'})
  timestamp: Date;

  @Column({name: 'fecha_digitacion'})
  typingDate: Date;

  @Column({ name: 'digitado' })
  typed: boolean;
}
