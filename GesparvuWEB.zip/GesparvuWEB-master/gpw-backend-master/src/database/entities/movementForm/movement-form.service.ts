import { MovementForm } from './movement-form.entity';
import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository, InsertResult } from 'typeorm';

@Injectable()
export class MovementFormService {
  constructor(
    @InjectRepository(MovementForm)
    private readonly movementFormRepository: Repository<MovementForm>,
  ) { }

  public withdrawInfant(movement: MovementForm): Promise<InsertResult> {
    return this.movementFormRepository
    .createQueryBuilder('movementForm')
    .insert()
    .into(MovementForm)
    .values([movement])
    .execute();
  }
}
