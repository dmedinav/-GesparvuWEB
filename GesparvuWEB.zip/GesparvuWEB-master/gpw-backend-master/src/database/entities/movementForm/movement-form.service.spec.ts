import { Test, TestingModule } from '@nestjs/testing';
import { MovementFormService } from './movement-form.service';
import { movementFormCreationMock } from '../../../common/mocks/movements';
import { MovementForm } from './movement-form.entity';

describe('MovementService', () => {
  let service: MovementFormService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [MovementFormService,
        {
          provide: 'MovementFormRepository',
          useValue: {
            createQueryBuilder: () => {/**/},
          },
        },
    ],
    }).compile();

    service = module.get<MovementFormService>(MovementFormService);
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });

  it('should insert new movement.', async () => {
    // tslint:disable-next-line:no-string-literal
    const insertSpyOn = spyOn(service['movementFormRepository'], 'createQueryBuilder').and.returnValue({
      insert: () => ({
        into: () => ({
          values: () => ({
            execute: () => Promise.resolve({}),
          }),
        }),
      }),
    } as any);
    const insertObject = await service.withdrawInfant(movementFormCreationMock as MovementForm);
    expect(insertSpyOn).toBeCalledWith('movementForm');
    expect(insertObject).toEqual({});
  });

});
