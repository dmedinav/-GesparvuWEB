import { Holiday } from './../holiday/holiday.entity';
import { Exception } from './../exception/exception.entity';
import { Entity, Column, PrimaryGeneratedColumn, OneToMany, ManyToOne, JoinColumn } from 'typeorm';
import { County } from '../geographic/county.entity';
import { Group } from '../group/group.entity';

@Entity({name: 'establecimiento'})
export class Establishment {

  @PrimaryGeneratedColumn({name: 'id_establecimiento'})
  id: number;

  @Column({name: 'rbd'})
  rbd: number;

  @Column({name: 'dv_rbd'})
  dvRbd: number;

  @Column({name: 'cod_establec'})
  establishmentCode: number;

  @Column({length: 100, name: 'nombre'})
  name: string;

  @Column({length: 100, name: 'sitio_web'})
  website: string;

  @Column({length: 1, name: 'autorizo_intercambio_correo'})
  authorizeMailExchange: string;

  @ManyToOne(/* istanbul ignore next */ type => County, /* istanbul ignore next */ county => county.establishments)
  @JoinColumn({name: 'comuna_id'})
  county: County;

  @Column({length: 100, name: 'responsable'})
  responsible: string;

  @Column({length: 8, name: 'dependencia'})
  dependency: string;

  @Column({name: 'inicio_ro'})
  startRoDate: Date;

  @Column({name: 'termino_ro'})
  endRoDate: Date;

  @Column({length: 36, name: 'estado'})
  status: string;

  @Column({length: 10, name: 'resolucion'})
  resolution: string;

  @Column({name: 'fecha_resolucion'})
  resolutionDate: Date;

  @Column({length: 14, name: 'genero'})
  gender: string;

  @Column({name: 'ingreso_sistema'})
  systemLoginDate: Date;

  @Column({name: 'actualizacion'})
  updatedAt: Date;

  @Column({length: 3, name: 'codigo_area_telefono'})
  phoneAreaCode: string;

  @Column({length: 50, name: 'telefono'})
  phone: string;

  @Column({length: 50, name: 'celular'})
  cellPhone: string;

  @Column({length: 100, name: 'correo_electronico'})
  email: string;

  @Column({length: 120, name: 'direccion'})
  address: string;

  @Column({length: 10, name: 'numero_direccion'})
  addressNumber: string;

  @Column({length: 200, name: 'direccion_referencia'})
  referenceAddress: string;

  @Column({length: 15, name: 'codigo_postal'})
  postalCode: string;

  @Column({length: 50, name: 'longitud'})
  longitude: string;

  @Column({length: 50, name: 'latitud'})
  latitude: string;

  @Column({name: 'traspaso_sige'})
  sigeTransfer: number;

  @Column({name: 'traspaso_fecha'})
  transferDate: Date;

  @OneToMany(/* istanbul ignore next */ type => Group, /* istanbul ignore next */ group => group.establishment)
  groups: Group[];

  @OneToMany(/* istanbul ignore next */ type => Exception, /* istanbul ignore next */ exceptions => exceptions.establishment)
  exceptions: Exception[];

  @OneToMany(/* istanbul ignore next */ type => Holiday, /* istanbul ignore next */ holiday => holiday.establishment)
  holidays: Holiday[];
}
