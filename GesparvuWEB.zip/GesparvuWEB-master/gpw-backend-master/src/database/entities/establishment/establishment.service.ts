import { Establishment } from './establishment.entity';
import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';

@Injectable()
export class EstablishmentService {
  constructor(
    @InjectRepository(Establishment)
    private readonly establishmentRepository: Repository<Establishment>,
  ) { }

  public getEstablishmentsWithGroupsByCounty(countyId: number): Promise<Establishment[]> {
    return this.establishmentRepository
    .createQueryBuilder('establishment')
    .leftJoinAndSelect('establishment.groups', 'group')
    .where('establishment.county.id = :countyid', { countyid: countyId })
    .getMany();
  }
}
