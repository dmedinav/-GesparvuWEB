import { establishmentDataMock } from './../../../common/mocks/establishment';
import { Test, TestingModule } from '@nestjs/testing';
import { EstablishmentService } from './establishment.service';

describe('EstablishmentService', () => {
  let service: EstablishmentService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [
        EstablishmentService,
        {
          provide: 'EstablishmentRepository',
          useValue: {
            createQueryBuilder: () => {/**/},
          },
        },
      ],
    }).compile();

    service = module.get<EstablishmentService>(EstablishmentService);
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });

  it('should call the orm api on function call.', async () => {
    // tslint:disable-next-line:no-string-literal
    const queryBuilderSpy = spyOn(service['establishmentRepository'], 'createQueryBuilder').and.returnValue({
      leftJoinAndSelect: () => ({
        where: () => ({
          getMany: () => Promise.resolve(establishmentDataMock),
        }),
      }),
    });
    const geographicInfo = await service.getEstablishmentsWithGroupsByCounty(1);

    expect(queryBuilderSpy).toBeCalledWith('establishment');
    expect(geographicInfo).toEqual(establishmentDataMock);
  });

});
