import { Test, TestingModule } from '@nestjs/testing';
import { PeriodService } from './period.service';

describe('PeriodService', () => {
  let service: PeriodService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [PeriodService,
        {
          provide: 'PeriodRepository',
          useValue: {
            createQueryBuilder: () => {/**/ },
          },
        },
      ],
    }).compile();

    service = module.get<PeriodService>(PeriodService);
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });

  it('should call the orm api on function call and return a query.', async () => {
    // tslint:disable-next-line:no-string-literal
    const queryBuilderSpy = spyOn(service['periodRepository'], 'createQueryBuilder').and.returnValue({
      where: () => ({
        andWhere: () => ({
          select: () => ({
            getQuery: () => Promise.resolve({}),
          }),
        }),
      }),
    });
    const periodQuery = await service.getPeriodQuery();

    expect(queryBuilderSpy).toBeCalledWith('period');
    expect(periodQuery).toEqual({});
  });

  it('should call the orm api on function call.', async () => {
    // tslint:disable-next-line:no-string-literal
    const queryBuilderSpy = spyOn(service['periodRepository'], 'createQueryBuilder').and.returnValue({
      where: () => ({
        andWhere: () => ({
          select: () => ({
            getOne: () => Promise.resolve({}),
          }),
        }),
      }),
    });
    const period = await service.getActive(2019, 8);

    expect(queryBuilderSpy).toBeCalledWith('period');
    expect(period).toEqual({});
  });

  it('should return false', async () => {
    expect((await service.isActiveMonth(2019, 8))).toBeFalsy();
  });

  it('should return true', async () => {
    spyOn(service, 'getActive').and.returnValue({active: true});
    expect((await service.isActiveMonth(2019, 8))).toBeTruthy();
  });

});
