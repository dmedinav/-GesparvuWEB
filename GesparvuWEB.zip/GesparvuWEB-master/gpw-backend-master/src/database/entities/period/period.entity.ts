import { Entity, Column, OneToMany, PrimaryColumn } from 'typeorm';
import { Group } from '../group/group.entity';

@Entity({ name: 'periodo' })
export class Period {

  @Column({ name: 'ano_parvulario' })
  academicYear: number;

  @PrimaryColumn({ name: 'mes' })
  month: number;

  @PrimaryColumn({ name: 'ano' })
  year: number;

  @Column({ name: 'activo' })
  active: boolean;

  @OneToMany(/* istanbul ignore next */ type => Group, /* istanbul ignore next */ group => group.academicYear)
  groups: Group[];
}
