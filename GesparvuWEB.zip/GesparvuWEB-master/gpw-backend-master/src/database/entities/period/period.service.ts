// tslint:disable:object-literal-shorthand
import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Period } from './period.entity';

@Injectable()
export class PeriodService {
  constructor(
    @InjectRepository(Period)
    private readonly periodRepository: Repository<Period>,
  ) { }

  public getPeriodQuery(): string {
    return this.periodRepository.createQueryBuilder('period')
    .where('period.year = :year')
    .andWhere('period.month = :month')
    .select(['period.academicYear'])
    .getQuery();
  }

  public getActive(year: number, month: number): Promise<Period> {
    return this.periodRepository.createQueryBuilder('period')
    .where('period.year = :year', {year})
    .andWhere('period.month = :month', {month})
    .select(['period.active'])
    .getOne();
  }

  public getPeriodsByAcademicYear(academicYear: number): Promise<Period[]> {
    return this.periodRepository.createQueryBuilder('period')
      .where('period.academicYear = :academicYear', {academicYear})
      .select(['period.academicYear', 'period.month', 'period.year'])
      .getMany();
  }

  public async isActiveMonth(year: number, month: number): Promise<boolean> {
    try {
      return (await this.getActive(year, month)).active;
    } catch (error) {
      return false;
    }
  }

}
