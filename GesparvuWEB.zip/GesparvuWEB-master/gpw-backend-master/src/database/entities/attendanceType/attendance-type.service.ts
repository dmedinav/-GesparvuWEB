import { AttendanceType } from './attendance-type.entity';
import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';

@Injectable()
export class AttendanceTypeService {
  constructor(
    @InjectRepository(AttendanceType)
    private readonly attendanceTypeRepository: Repository<AttendanceType>,
  ) { }

  public getAttendanceTypesForExceptionType(exceptionType: number): Promise<AttendanceType> {
    return this.attendanceTypeRepository.createQueryBuilder('attendanceType')
    .leftJoinAndSelect('attendanceType.exceptionTypes', 'exceptionType')
    .where('exceptionType.id = :exceptionTypeId', { exceptionTypeId: exceptionType })
    .getOne();
  }

  public async getAllAttendanceTypes() {
    return this.attendanceTypeRepository.find({ select : ['type', 'sigeCode'] });
  }

}
