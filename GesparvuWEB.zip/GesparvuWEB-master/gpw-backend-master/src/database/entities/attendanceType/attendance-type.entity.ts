import { Holiday } from './../holiday/holiday.entity';
import { ExceptionType } from './../exceptionType/exception-type.entity';
import { Entity, Column, PrimaryGeneratedColumn, OneToMany } from 'typeorm';

@Entity({name: 'tipo_asistencia'})
export class AttendanceType {

  @PrimaryGeneratedColumn({name: 'id_tipo_asistencia'})
  id: number;

  @Column({length: 2000, name: 'descripcion'})
  description: string;

  @Column({ name: 'cod_sige'})
  sigeCode: number;

  @Column({length: 100, name: 'tipo'})
  type: string;

  @OneToMany(/* istanbul ignore next */ type => ExceptionType, /* istanbul ignore next */ exceptionTypes => exceptionTypes.attendanceType)
  exceptionTypes: ExceptionType[];

  @OneToMany(/* istanbul ignore next */ type => Holiday, /* istanbul ignore next */ holiday => holiday.attendanceType)
  holidays: Holiday[];
}
