import { AttendanceType } from './attendance-type.entity';
import { Module } from '@nestjs/common';
import { AttendanceTypeService } from './attendance-type.service';
import { TypeOrmModule } from '@nestjs/typeorm';

@Module({
  imports: [TypeOrmModule.forFeature([AttendanceType])],
  providers: [AttendanceTypeService],
  exports: [AttendanceTypeService],
})
export class AttendanceTypeModule {}
