import { attendanceTypeMock } from '../../../common/mocks/attendance-type';
import { attendanceWithoutMonthlyAttendanceMock } from './../../../common/mocks/attendance';
import { Test, TestingModule } from '@nestjs/testing';
import { AttendanceTypeService } from './attendance-type.service';

describe('AttendanceTypeService', () => {
  let service: AttendanceTypeService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [AttendanceTypeService,
        {
          provide: 'AttendanceTypeRepository',
          useValue: {
            createQueryBuilder: () => {/**/},
            find: () => {/**/},
          },
        },
      ],
    }).compile();

    service = module.get<AttendanceTypeService>(AttendanceTypeService);
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });

  it('should call the orm api on function call.', async () => {
    // tslint:disable-next-line:no-string-literal
    const queryBuilderSpy = spyOn(service['attendanceTypeRepository'], 'createQueryBuilder').and.returnValue({
      leftJoinAndSelect: () => ({
        where: () => ({
          getOne: () => Promise.resolve(attendanceTypeMock),
        }),
      }),
    });
    const attendanceTypes = await service.getAttendanceTypesForExceptionType(1);

    expect(queryBuilderSpy).toBeCalledWith('attendanceType');
    expect(attendanceTypes).toEqual(attendanceTypeMock);
  });

  it('should call function getAllAttendanceTypes.', async () => {
    // tslint:disable-next-line:no-string-literal
    spyOn(service['attendanceTypeRepository'], 'find').and.returnValue(Promise.resolve(attendanceWithoutMonthlyAttendanceMock));
    expect(await service.getAllAttendanceTypes()).toEqual(attendanceWithoutMonthlyAttendanceMock);
  });

});
