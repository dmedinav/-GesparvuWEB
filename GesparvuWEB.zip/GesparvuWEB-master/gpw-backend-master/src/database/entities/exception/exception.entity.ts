import { County } from '../geographic/county.entity';
import { Entity, Column, PrimaryGeneratedColumn, ManyToOne, JoinColumn, CreateDateColumn } from 'typeorm';
import { Group } from '../group/group.entity';
import { Region } from '../geographic/region.entity';
import { Establishment } from '../establishment/establishment.entity';
import { ExceptionType } from '../exceptionType/exception-type.entity';

@Entity({name: 'excepcion'})
export class Exception {

  @PrimaryGeneratedColumn({name: 'id_excepcion'})
  id: number;

  @Column({type: 'timestamptz', name: 'fecha'})
  date: Date;

  @Column({name: 'pais'})
  country: boolean;

  @ManyToOne(/* istanbul ignore next */ type => Region, /* istanbul ignore next */ region => region.exceptions)
  @JoinColumn({name: 'region_id'})
  region: Region;

  @ManyToOne(/* istanbul ignore next */ type => County, /* istanbul ignore next */ county => county.exceptions)
  @JoinColumn({name: 'comuna_id'})
  county: County;

  @ManyToOne(/* istanbul ignore next */ type => Establishment, /* istanbul ignore next */ establishment => establishment.exceptions)
  @JoinColumn({name: 'establecimiento_id'})
  establishment: Establishment;

  @ManyToOne(/* istanbul ignore next */ type => Group, /* istanbul ignore next */ group => group.exceptions)
  @JoinColumn({name: 'grupo_id'})
  group: Group;

  @ManyToOne(/* istanbul ignore next */ type => ExceptionType, /* istanbul ignore next */ exceptionType => exceptionType.exceptions)
  @JoinColumn({name: 'tipo_excepcion_id'})
  exceptionType: ExceptionType;

  @Column({length: 2000, name: 'descripcion'})
  description: string;

  @CreateDateColumn({name: 'fecha_creacion'})
  timestamp: Date;

  @Column({name: 'traspaso_sige'})
  sigeTransfer: number;

}
