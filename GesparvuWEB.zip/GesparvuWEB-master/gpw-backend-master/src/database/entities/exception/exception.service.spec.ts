import { exceptionCreationMock, getExceptionsParamsDtoMock } from './../../../common/mocks/exception';
import { Test, TestingModule } from '@nestjs/testing';
import { ExceptionService } from './exception.service';

describe('ExceptionService', () => {
  let service: ExceptionService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [
        ExceptionService,
        {
          provide: 'GroupService',
          useValue: {
            getGroupLocationQuery: () => {/**/ },
          },
        },
        {
          provide: 'ExceptionRepository',
          useValue: {
            createQueryBuilder: () => ({}),
          },
        },
        {
          provide: 'HolidayRepository',
          useValue: {
            createQueryBuilder: () => ({}),
          },
        },
      ],
    }).compile();

    service = module.get<ExceptionService>(ExceptionService);
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });

  it('should call find on function call.', async () => {
    // tslint:disable-next-line:no-string-literal
    spyOn(service['exceptionRepository'], 'createQueryBuilder').and.returnValue({
      insert: () => ({
        into: () => ({
          values: () => ({
            getQueryAndParameters: () => Promise.resolve({}),
          }),
        }),
      }),
    } as any);
    expect(await service.createException(exceptionCreationMock)).toEqual({});
  });

  it('should call getRawMany', async () => {
    // tslint:disable-next-line:no-string-literal
    spyOn(service['exceptionRepository'], 'createQueryBuilder').and.returnValue({
      setParameter: () => ({
        innerJoin: () => ({
          where: () => ({
            andWhere: () => ({
              andWhere: () => ({
                orderBy: () => ({
                  select: () => ({
                    addSelect: () => ({
                      addSelect: () => ({
                        addSelect: () => ({
                          addSelect: () => ({
                            addSelect: () => ({
                              getRawMany: () => Promise.resolve({}),
                            }),
                          }),
                        }),
                      }),
                    }),
                  }),
                }),
              }),
            }),
          }),
        }),
      }),
    } as any);

    expect(await service.getExceptionsByMonthAndGroup(
      getExceptionsParamsDtoMock.month,
      getExceptionsParamsDtoMock.year,
      getExceptionsParamsDtoMock.group,
    )).toEqual({});
  });

});
