import { CREATION_SIGE_CODE } from './../../../common/constants/misc';
import { Exception } from './exception.entity';
import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { IExceptionCalendar } from '../../../common/interfaces/exception-calendar.interface';
import { GroupService } from '../group/group.service';

@Injectable()
export class ExceptionService {
  constructor(
    @InjectRepository(Exception)
    private readonly exceptionRepository: Repository<Exception>,
    private readonly groupService: GroupService,
  ) { }

  public createException(exception: Exception) {
    exception.sigeTransfer = CREATION_SIGE_CODE;
    return this.exceptionRepository
      .createQueryBuilder('exception')
      .insert()
      .into(Exception)
      .values(exception)
      .getQueryAndParameters();
  }

  // tslint:disable: quotemark
  public getExceptionsByMonthAndGroup(month: number, year: number, group: number): Promise<IExceptionCalendar[]> {
    const groupQuery = this.groupService.getGroupLocationQuery(group);

    return this.exceptionRepository.createQueryBuilder('exception')
      .setParameter('groupid', group)
      .innerJoin('(' + groupQuery + ')', 'groups', 'exception.group.id = groups.id OR'
        + ' exception.establishment.id = groups.establishment OR'
        + ' exception.county.id = groups.county OR'
        + ' exception.region.id = groups.region OR'
        + ' exception.country = true')
      .where("date_part('year', exception.date) = :year", { year })
      .andWhere("date_part('month', exception.date) = :month", { month })
      .andWhere('(exception.group.id is null OR exception.group.id = :group)', { group })
      .orderBy('exception.timestamp')
      .select(['exception.date as date'])
      .addSelect(['exception.timestamp as timestamp'])
      .addSelect(['exception.description as description'])
      .addSelect('null', 'irrevocable')
      .addSelect('false', 'isHoliday')
      .addSelect('null', 'irrevocable')
      .getRawMany();
  }
}
