// tslint:disable:object-literal-shorthand
import { Enrollment } from './enrollment.entity';
import { Period } from '../period/period.entity';
import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { PeriodService } from '../period/period.service';
import Utils from '../../../common/utils/utils';
import { GroupTeacher } from '../group_teacher/group_teacher.entity';
import { Teacher } from '../teacher/teacher.entity';

// tslint:disable: quotemark
@Injectable()
export class EnrollmentService {
  constructor(
    @InjectRepository(Enrollment)
    private readonly enrollmentRepository: Repository<Enrollment>,
    private readonly periodService: PeriodService,
  ) { }

  public async getEnrollmentsByGroup(group: number, year: number, month: number, day: number = 0, monthly: boolean = true): Promise<Enrollment[]> {
    const date = !monthly ? new Date(year, month - 1, day) : new Date(year, month, day);
    date.setHours(23, 59, 59);
    return Utils.convertAttendanceArrayInEnrollments(
      await this.enrollmentRepository
        .createQueryBuilder('enrollment')
        .where('enrollment.group.id = :group', { group })
        .andWhere('attendances.year = :year', { year: year })
        .andWhere('attendances.month = :month', { month: month })
        .andWhere('((enrollment.retirementDate IS NULL AND enrollment.enrollmentDate <= :date) ' +
          'OR (:monthly AND DATE_PART(\'MONTH\', enrollment.retirementDate) >= :month ' +
          'AND DATE_PART(\'MONTH\', enrollment.enrollmentDate) <= :month) ' +
          'OR (NOT :monthly AND enrollment.retirementDate >= :date ' +
          'AND enrollment.enrollmentDate <= :date))', { date, monthly, month })
        .leftJoin('enrollment.infant', 'infant')
        .leftJoin('enrollment.attendances', 'attendances')
        .leftJoin('enrollment.group', 'group')
        .leftJoin('group.establishment', 'establishment')
        .leftJoin('group.level', 'level')
        .select(['enrollment.id', 'enrollment.enrollmentDate', 'enrollment.retirementDate'])
        .addSelect(['infant.id', 'infant.names', 'infant.fathersLastname', 'infant.mothersLastname', 'infant.rut', 'infant.rutDv'])
        .addSelect(['attendances.id', 'attendances.attendance'])
        .addSelect(['group.id', 'group.name'])
        .addSelect(['establishment.id', 'establishment.name', 'establishment.establishmentCode'])
        .addSelect(['level.id', 'level.label'])
        .orderBy('infant.fathersLastname')
        .getMany(),
    );
  }

  public getEnrollments(teacherRut: number, filter: string = ''): Promise<any[]> {

    const filterArray = [];
    for (const element of filter.toLocaleLowerCase().split(' ')) {
      filterArray.push('%' + element + '%');
    }
    const periodQuery = this.periodService.getPeriodQuery();

    return this.enrollmentRepository.createQueryBuilder('enrollment')
      .setParameter('year', new Date().getUTCFullYear().toString())
      .setParameter('month', (new Date().getUTCMonth() + 1).toString())
      .innerJoin(Teacher, 'teacher', 'teacher.rut = :rut', { rut: teacherRut })
      .innerJoin(GroupTeacher,
        'groupTeacher',
        'teacher.id = groupTeacher.teacher AND enrollment.group = groupTeacher.group')
      .innerJoin('enrollment.group', 'group')
      .innerJoin('enrollment.infant', 'infant')
      .innerJoin(
        '(' + periodQuery + ')', 'period',
        'period.period_ano_parvulario = group.academicYear')
      .where('( CAST(infant.rut AS varchar) LIKE ANY (ARRAY[:...filter])',
        { filter: filterArray })
      .orWhere(
        "LOWER(CONCAT(infant.rut, '-', infant.rutDv)) LIKE ANY (ARRAY[:...filter])",
        { filter: filterArray })
      .orWhere(
        'LOWER(infant.names) LIKE ANY (ARRAY[:...filter])',
        { filter: filterArray })
      .orWhere(
        'LOWER(infant.fathersLastname) LIKE ANY (ARRAY[:...filter])',
        { filter: filterArray })
      .orWhere(
        'LOWER(infant.mothersLastname) LIKE ANY (ARRAY[:...filter]) )',
        { filter: filterArray })
      .select([
        'group.id',
        'group.name'
      ])
      .addSelect([
        'infant.id',
        'infant.names',
        'infant.fathersLastname',
        'infant.mothersLastname',
        'infant.rut',
        'infant.rutDv',
        'infant.sexuality',
        'infant.birthDate'
      ])
      .addSelect([
        'enrollment.id',
        'enrollment.enrollmentDate',
        'enrollment.retirementDate'])
      .orderBy('infant.fathersLastname')
      .getMany();
  }

  public getEnrollment(enrollmentId: number): Promise<Enrollment> {
    return this.enrollmentRepository
      .createQueryBuilder('enrollment')
      .where(
        'enrollment.id = :id',
        { id: enrollmentId })
      .leftJoin(
        'enrollment.infant',
        'infant')
      .leftJoin(
        'enrollment.group',
        'group')
      .leftJoin(
        'group.level',
        'level')
      .select([
        'enrollment.id',
        'enrollment.enrollmentDate',
        'enrollment.retirementDate'
      ])
      .addSelect([
        'infant.id',
        'infant.names',
        'infant.fathersLastname',
        'infant.mothersLastname',
        'infant.rut',
        'infant.rutDv',
        'infant.sexuality',
        'infant.birthDate'
      ])
      .addSelect(['group.id', 'group.name'])
      .addSelect(['level.id', 'level.label'])
      .getOne();
  }

  public createEnrollment(enrollment: Enrollment) {
    return this.enrollmentRepository.save(enrollment);
  }

  public updateEnrollment(criteria, partialEntity) {
    return this.enrollmentRepository.update(criteria, partialEntity);
  }

  public getEnrollmentPeriods(enrollment: Enrollment): Promise<Period[]> {
    return this.periodService.getPeriodsByAcademicYear(enrollment.group.academicYear);
  }
}
