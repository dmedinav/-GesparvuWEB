import { Test, TestingModule } from '@nestjs/testing';
import { EnrollmentService } from './enrollment.service';
import { enrollmentDataMock } from '../../../common/mocks/enrollment';

describe('EnrollmentService', () => {
  let service: EnrollmentService;
  const enrollmentDayMock = JSON.parse(JSON.stringify(enrollmentDataMock));
  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [
        EnrollmentService,
        {
          provide: 'EnrollmentRepository',
          useValue: {
            createQueryBuilder: () => {/**/ },
          },
        },
        {
          provide: 'PeriodService',
          useValue: {
            getPeriodQuery: () => {/**/ },
          },
        },
      ],
    }).compile();
    service = module.get<EnrollmentService>(EnrollmentService);
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });

  it('should call the orm api on function call and return enrollments by group id', async () => {
    // tslint:disable-next-line:no-string-literal
    const queryBuilderSpy = spyOn(service['enrollmentRepository'], 'createQueryBuilder').and.returnValue({
      where: () => ({
        andWhere: () => ({
          andWhere: () => ({
            andWhere: () => ({
              leftJoin: () => ({
                leftJoin: () => ({
                  leftJoin: () => ({
                    leftJoin: () => ({
                      leftJoin: () => ({
                        select: () => ({
                          addSelect: () => ({
                            addSelect: () => ({
                              addSelect: () => ({
                                addSelect: () => ({
                                  addSelect: () => ({
                                    orderBy: () => ({
                                      getMany: () => Promise.resolve(enrollmentDataMock),
                                    }),
                                  }),
                                }),
                              }),
                            }),
                          }),
                        }),
                      }),
                    }),
                  }),
                }),
              }),
            }),
          }),
        }),
      }),
    });
    const enrollments = await service.getEnrollmentsByGroup(1, 2019, 12);

    expect(queryBuilderSpy).toBeCalledWith('enrollment');
    expect(enrollments).toEqual(enrollmentDataMock);
  });

  it('should call the orm api on function call and return enrollments by group id with selected day', async () => {
    // tslint:disable-next-line:no-string-literal
    const queryBuilderSpy = spyOn(service['enrollmentRepository'], 'createQueryBuilder').and.returnValue({
      where: () => ({
        andWhere: () => ({
          andWhere: () => ({
            andWhere: () => ({
              leftJoin: () => ({
                leftJoin: () => ({
                  leftJoin: () => ({
                    leftJoin: () => ({
                      leftJoin: () => ({
                        select: () => ({
                          addSelect: () => ({
                            addSelect: () => ({
                              addSelect: () => ({
                                addSelect: () => ({
                                  addSelect: () => ({
                                    orderBy: () => ({
                                      getMany: () => Promise.resolve(enrollmentDayMock),
                                    }),
                                  }),
                                }),
                              }),
                            }),
                          }),
                        }),
                      }),
                    }),
                  }),
                }),
              }),
            }),
          }),
        }),
      }),
    });
    const enrollments = await service.getEnrollmentsByGroup(1, 2019, 12, 10, false);

    expect(queryBuilderSpy).toBeCalledWith('enrollment');
    expect(enrollments).toEqual(enrollmentDayMock);
  });

  it('should call the orm api on function call and return enrollments by filter', async () => {
    // tslint:disable-next-line:no-string-literal
    const queryBuilderSpy = spyOn(service['enrollmentRepository'], 'createQueryBuilder').and.returnValue({
      setParameter: () => ({
        setParameter: () => ({
          innerJoin: () => ({
            innerJoin: () => ({
              innerJoin: () => ({
                innerJoin: () => ({
                  innerJoin: () => ({
                    where: () => ({
                      orWhere: () => ({
                        orWhere: () => ({
                          orWhere: () => ({
                            orWhere: () => ({
                              select: () => ({
                                addSelect: () => ({
                                  addSelect: () => ({
                                    orderBy: () => ({
                                      getMany: () => Promise.resolve(enrollmentDataMock),
                                    }),
                                  }),
                                }),
                              }),
                            }),
                          }),
                        }),
                      }),
                    }),
                  }),
                }),
              }),
            }),
          }),
        }),
      }),
    });
    const enrollments = await service.getEnrollments(11111111);

    expect(queryBuilderSpy).toBeCalledWith('enrollment');
    expect(enrollments).toEqual(enrollmentDataMock);
  });

  it('should call the orm api on function call and return an enrollment', async () => {
    // tslint:disable-next-line:no-string-literal
    const queryBuilderSpy = spyOn(service['enrollmentRepository'], 'createQueryBuilder').and.returnValue({
      where: () => ({
        leftJoin: () => ({
          leftJoin: () => ({
            leftJoin: () => ({
              select: () => ({
                addSelect: () => ({
                  addSelect: () => ({
                    addSelect: () => ({
                      getOne: () => Promise.resolve(enrollmentDataMock),
                    }),
                  }),
                }),
              }),
            }),
          }),
        }),
      }),
    });
    const enrollment = await service.getEnrollment(1);

    expect(queryBuilderSpy).toBeCalledWith('enrollment');
    expect(enrollment).toEqual(enrollmentDataMock);
  });

});
