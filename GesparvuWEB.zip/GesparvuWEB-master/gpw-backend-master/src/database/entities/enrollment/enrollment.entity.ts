import { Entity, Column, PrimaryGeneratedColumn, ManyToOne, JoinColumn, OneToMany, OneToOne } from 'typeorm';
import { Infant } from '../infant/infant.entity';
import { Group } from '../group/group.entity';
import { Attendance } from '../attendance/attendance.entity';
import { Movement } from '../movement/movement.entity';

@Entity({name: 'matricula'})
export class Enrollment {

  @PrimaryGeneratedColumn({name: 'id_matricula'})
  id: number;

  @Column({name: 'fecha_incorporacion'})
  enrollmentDate: Date;

  @Column({name: 'fecha_retiro'})
  retirementDate: Date;

  @OneToOne(/* istanbul ignore next */ type => Infant)
  @JoinColumn({name: 'parvulo_id'})
  infant: Infant;

  @ManyToOne(/* istanbul ignore next */ type => Group, /* istanbul ignore next */ group => group.enrollments)
  @JoinColumn({name: 'grupo_id'})
  group: Group;

  @ManyToOne(/* istanbul ignore next */ type => Movement, /* istanbul ignore next */ movement => movement.enrollments)
  @JoinColumn({name: 'movimiento_id'})
  movement: Movement;

  @Column({length: 30, name: 'modificado_por'})
  modifiedBy: string;

  @Column({name: 'fecha_modificacion'})
  modificationDate: Date;

  @Column({name: 'traspaso_sige'})
  sigeTransfer: number;

  @Column({name: 'traspaso_fecha'})
  transferDate: Date;

  @Column({name: 'comentario'})
  comment: string;

  @OneToMany(/* istanbul ignore next */ type => Attendance, /* istanbul ignore next */ attendance => attendance.enrollment)
  attendances: Attendance[];

}
