import { Infant } from './infant.entity';
import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';

@Injectable()
export class InfantService {
  constructor(
    @InjectRepository(Infant)
    private readonly infantRepository: Repository<Infant>,
  ) { }

  public getLastInfant() {
    return this.infantRepository.find(
      {
        order: {
          id: "DESC"
        }
      }
    )[0];
  }

  public createOrUpdateInfant(infant: Infant) {
    return this.infantRepository.save(infant);
  }

  public findByRut(rut: number): Promise<Infant> {
    return this.infantRepository.findOne({ where: { rut: rut } });
  }
}
