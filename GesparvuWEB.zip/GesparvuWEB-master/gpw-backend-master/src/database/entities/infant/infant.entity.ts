import { Entity, Column, PrimaryGeneratedColumn, OneToOne, BaseEntity } from 'typeorm';
import { Enrollment } from '../enrollment/enrollment.entity';
import { SimInfant } from '../simInfant/sim-infant.entity';
import { InfantForm } from '../infantForm/infant-form.entity';
import { IInfant } from '../../../common/interfaces/infant.interface';

@Entity({ name: 'parvulo' })
export class Infant extends BaseEntity implements IInfant {

  @PrimaryGeneratedColumn("increment", { name: 'id_parvulo', type: 'integer' })
  id: number;

  @Column({ name: 'rut' })
  rut: number;

  @Column({ length: 1, name: 'dv' })
  rutDv: string;

  @Column({ length: 50, name: 'apellido_paterno' })
  fathersLastname: string;

  @Column({ length: 50, name: 'apellido_materno' })
  mothersLastname: string;

  @Column({ length: 100, name: 'nombres' })
  names: string;

  @Column({ name: 'sexualidad_id' })
  sexuality: number;

  @Column({ name: 'fecha_nacimiento' })
  birthDate: Date;

  @Column({ name: 'fecha_defuncion' })
  deathDate: Date;

  @Column({ name: 'comuna_id' })
  county: number;

  @Column({ name: 'etnia_id' })
  ethnicGroup: number;

  @Column({ name: 'nacionalidad_id' })
  nationality: number;

  @Column({ name: 'ndes_educvas_espc_id' })
  ndesEducvasEspc: number;

  @Column({ length: 20, name: 'telefono' })
  phone: string;

  @Column({ length: 20, name: 'celular' })
  cellPhone: string;

  @Column({ length: 100, name: 'correo_electronico' })
  email: string;

  @Column({ length: 100, name: 'direccion' })
  address: string;

  @Column({ length: 20, name: 'numero_direccion' })
  addressNumber: string;

  @Column({ length: 20, name: 'numeo_dpto' })
  apartmentNumber: string;

  @Column({ length: 100, name: 'informacion_adicional' })
  adittionalInfo: string;

  @Column({ name: 'traspaso_sige' })
  sigeTransfer: number;

  @Column({ name: 'traspaso_fecha' })
  transferDate: Date;

  @Column({ name: 'normalizado' })
  normalized: boolean;

  @OneToOne(/* istanbul ignore next */ type => Enrollment, /* istanbul ignore next */ enrollment => enrollment.group)
  enrollment: Enrollment;

  public getFullRut(): string {
    return this.rut + "-" + this.rutDv;
  }

  public updateFromSim(sim: SimInfant) {
    this.updateFromOtherInfant(sim);
    this.normalized = true;
  }

  public updateFromForm(infantForm: InfantForm) {
    this.updateFromOtherInfant(infantForm);
  }

  private updateFromOtherInfant(otherInfant: IInfant) {
    this.rut = otherInfant.rut;
    this.rutDv = otherInfant.rutDv;
    this.fathersLastname = otherInfant.fathersLastname;
    this.mothersLastname = otherInfant.mothersLastname;
    this.names = otherInfant.names;
    this.sexuality = otherInfant.sexuality;
    this.birthDate =
      otherInfant.birthDate ? new Date(otherInfant.birthDate) : null;
  }
}
