import { Entity, Column, PrimaryColumn, ManyToOne, JoinColumn, OneToMany, BaseEntity } from 'typeorm';
import { IInfant } from '../../../common/interfaces/infant.interface';

@Entity({ name: 'sim_parvulo' })
export class SimInfant extends BaseEntity implements IInfant {
    @PrimaryColumn({ name: 'run' })
    rut: number;

    @Column({ name: 'run_dv' })
    rutDv: string;

    @Column({ length: 50, name: 'apell_paterno' })
    fathersLastname: string;

    @Column({ length: 50, name: 'apell_materno' })
    mothersLastname: string;

    @Column({ length: 100, name: 'nombres' })
    names: string;

    @Column({ name: 'fec_nacim' })
    birthDate: Date;

    @Column({ name: 'sexo' })
    sexuality: number;
}
