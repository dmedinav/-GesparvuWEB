import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { SimInfant } from './sim-infant.entity';

@Injectable()
export class SimInfantService {
    constructor(
        @InjectRepository(SimInfant)
        private readonly simInfantRepository: Repository<SimInfant>,
    ) { }

    public findByRut(rut: number): Promise<SimInfant> {
        return this.simInfantRepository.findOne({ where: { rut: rut } });
    }
}
