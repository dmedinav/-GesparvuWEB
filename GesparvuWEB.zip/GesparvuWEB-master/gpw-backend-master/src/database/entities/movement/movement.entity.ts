import { Enrollment } from './../enrollment/enrollment.entity';
import { Entity, Column, PrimaryGeneratedColumn, ManyToOne, JoinColumn, OneToMany } from 'typeorm';
import { MovementType } from '../movementType/movement-type.entity';

@Entity({name: 'movimiento'})
export class Movement {

  @PrimaryGeneratedColumn({name: 'id_movimiento'})
  id: number;

  @ManyToOne(/* istanbul ignore next */ type => MovementType, /* istanbul ignore next */ movementType => movementType.movements)
  @JoinColumn({name: 'tipo_movimiento_id'})
  movementType: MovementType;

  @Column({name: 'correl_tipo_mov'})
  correlativeMovementType: number;

  @Column({length: 40, name: 'descripcion'})
  description: string;

  @Column({name: 'activo'})
  active: boolean;

  @OneToMany(/* istanbul ignore next */ type => Enrollment, /* istanbul ignore next */ enrollment => enrollment.movement)
  enrollments: Enrollment[];
}
