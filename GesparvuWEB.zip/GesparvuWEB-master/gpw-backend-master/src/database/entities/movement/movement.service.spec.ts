import { Test, TestingModule } from '@nestjs/testing';
import { MovementService } from './movement.service';

describe('MovementService', () => {
  let service: MovementService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [
        MovementService,
        {
          provide: 'MovementRepository',
          useValue: {
            createQueryBuilder: () => {/**/},
          },
        },
    ],
    }).compile();

    service = module.get<MovementService>(MovementService);
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });

  it('should retrieve all movements', async () => {
    // tslint:disable-next-line:no-string-literal
    const getSpyOn = spyOn(service['movementRepository'], 'createQueryBuilder').and.returnValue({
      leftJoinAndSelect: () => ({
        where: () => ({
          select: () => ({
            addSelect: () => ({
              getRawMany: () => Promise.resolve({}),
            }),
          }),
        }),
      }),
    } as any);
    const movementObjects = await service.getMovementTypes();
    expect(getSpyOn).toBeCalledWith('movement');
    expect(movementObjects).toEqual({});
  });

});
