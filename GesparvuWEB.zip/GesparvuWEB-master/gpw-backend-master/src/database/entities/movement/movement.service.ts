import { IMovementTypes } from './../../../common/interfaces/movement.interface';
import { Movement } from './movement.entity';
import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';

// tslint:disable:quotemark
@Injectable()
export class MovementService {
  constructor(
    @InjectRepository(Movement)
    private readonly movementRepository: Repository<Movement>,
  ) { }

  public async getMovementTypes(): Promise<IMovementTypes[]> {
    return this.movementRepository.createQueryBuilder('movement')
    .leftJoinAndSelect('movement.movementType', 'movementType')
    .where('movement.active = true')
    .select("concat(movementType.code, movement.correlativeMovementType, ' - ', movement.description )", 'description')
    .addSelect('movement.id', 'id')
    .getRawMany();
  }

}
