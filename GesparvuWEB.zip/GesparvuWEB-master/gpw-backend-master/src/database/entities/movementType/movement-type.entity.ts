import { Entity, Column, PrimaryGeneratedColumn, OneToMany } from 'typeorm';
import { Movement } from '../movement/movement.entity';

@Entity({name: 'tipo_movimiento'})
export class MovementType {

  @PrimaryGeneratedColumn({name: 'id_tipo_movimiento'})
  id: number;

  @Column({length: 1, name: 'cod_tipo_mov'})
  code: string;

  @Column({length: 15, name: 'descripcion'})
  description: string;

  @OneToMany(/* istanbul ignore next */ type => Movement, /* istanbul ignore next */ movement => movement.movementType)
  movements: Movement[];
}
