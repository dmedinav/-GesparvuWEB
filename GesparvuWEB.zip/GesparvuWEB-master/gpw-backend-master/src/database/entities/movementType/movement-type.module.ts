import { MovementType } from './movement-type.entity';
import { Module } from '@nestjs/common';
import { MovementTypeService } from './movement-type.service';
import { TypeOrmModule } from '@nestjs/typeorm';

@Module({
  imports: [TypeOrmModule.forFeature([MovementType])],
  providers: [MovementTypeService],
})
export class MovementTypeModule {}
