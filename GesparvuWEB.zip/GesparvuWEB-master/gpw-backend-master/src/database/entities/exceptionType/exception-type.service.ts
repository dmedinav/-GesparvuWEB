import { ExceptionType } from './exception-type.entity';
import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';

@Injectable()
export class ExceptionTypeService {
  constructor(
    @InjectRepository(ExceptionType)
    private readonly exceptionTypeRepository: Repository<ExceptionType>,
  ) { }

  public getAllExceptionTypes(): Promise<ExceptionType[]> {
    return this.exceptionTypeRepository.find({ select : ['id', 'description']});
  }
}
