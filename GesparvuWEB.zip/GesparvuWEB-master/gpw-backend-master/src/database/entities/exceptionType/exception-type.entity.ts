import { Exception } from './../exception/exception.entity';
import { AttendanceType } from './../attendanceType/attendance-type.entity';
import { Entity, Column, PrimaryGeneratedColumn, ManyToOne, JoinColumn, OneToMany } from 'typeorm';

@Entity({name: 'tipo_excepcion'})
export class ExceptionType {

  @PrimaryGeneratedColumn({name: 'id_tipo_excepcion'})
  id: number;

  @Column({length: 2000, name: 'descripcion'})
  description: string;

  @ManyToOne(/* istanbul ignore next */ type => AttendanceType, /* istanbul ignore next */ attendanceType => attendanceType.exceptionTypes)
  @JoinColumn({name: 'tipo_asistencia_id'})
  attendanceType: AttendanceType;

  @Column({name: 'trabajo'})
  workDay: boolean;

  @OneToMany(/* istanbul ignore next */ type => Exception, /* istanbul ignore next */ exception => exception.exceptionType)
  exceptions: Exception[];
}
