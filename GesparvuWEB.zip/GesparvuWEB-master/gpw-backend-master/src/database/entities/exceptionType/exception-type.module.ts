import { ExceptionType } from './exception-type.entity';
import { Module } from '@nestjs/common';
import { ExceptionTypeService } from './exception-type.service';
import { TypeOrmModule } from '@nestjs/typeorm';

@Module({
  imports: [TypeOrmModule.forFeature([ExceptionType])],
  providers: [ExceptionTypeService],
})
export class ExceptionTypeModule {}
