import { Test, TestingModule } from '@nestjs/testing';
import { ExceptionTypeService } from './exception-type.service';
import { exceptionTypeMock } from '../../../common/mocks/exception-type';

describe('MovementTypeService', () => {
  let service: ExceptionTypeService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [ExceptionTypeService,
        {
          provide: 'ExceptionTypeRepository',
          useValue: {
            find: () => {/**/},
          },
        },
      ],
    }).compile();

    service = module.get<ExceptionTypeService>(ExceptionTypeService);
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });

  it('should call find on function call.', async () => {
    // tslint:disable-next-line:no-string-literal
    spyOn(service['exceptionTypeRepository'], 'find').and.returnValue(Promise.resolve([exceptionTypeMock]));
    expect(await service.getAllExceptionTypes()).toEqual([exceptionTypeMock]);
  });

});
