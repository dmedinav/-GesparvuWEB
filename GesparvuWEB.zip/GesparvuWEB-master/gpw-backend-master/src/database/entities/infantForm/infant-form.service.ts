import { InfantForm } from './infant-form.entity';
import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';

@Injectable()
export class InfantFormService {
  constructor(
    @InjectRepository(InfantForm)
    private readonly infantFormRepository: Repository<InfantForm>,
  ) { }

  public createInfantForm(infantForm: InfantForm): Promise<InfantForm> {
    return this.infantFormRepository.save(infantForm);
  }

}
