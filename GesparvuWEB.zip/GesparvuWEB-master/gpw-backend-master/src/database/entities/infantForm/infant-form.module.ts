import { InfantForm } from './infant-form.entity';
import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { InfantFormService } from './infant-form.service';

@Module({
  imports: [TypeOrmModule.forFeature([InfantForm])],
  providers: [InfantFormService],
  exports: [InfantFormService],
})
export class InfantFormModule {}
