import { Test, TestingModule } from '@nestjs/testing';
import { InfantFormService } from './infant-form.service';
import { InfantForm } from './infant-form.entity';

describe('InfantFormService', () => {
  let service: InfantFormService;
  const expectedResult = new InfantForm();


  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [InfantFormService,
        {
          provide: 'InfantFormRepository',
          useValue: {
            save: () => expectedResult,
          },
        },
    ],
    }).compile();

    service = module.get<InfantFormService>(InfantFormService);
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });

  it('should call the orm save method and return an the expected result', async () => {
    const infantCreation = await service.createInfantForm(null);
    expect(infantCreation).toEqual(expectedResult);
  });

});
