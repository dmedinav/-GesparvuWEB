import { Group } from './../group/group.entity';
import { Entity, Column, CreateDateColumn, PrimaryGeneratedColumn, OneToOne, JoinColumn, OneToMany, ManyToOne, BaseEntity } from 'typeorm';
import { Sexuality } from '../sexuality/sexuality.entity';
import { IInfant } from '../../../common/interfaces/infant.interface';

@Entity({ name: 'form_parvulo' })
export class InfantForm extends BaseEntity implements IInfant {

  @PrimaryGeneratedColumn({ name: 'id_form_parvulo' })
  id: number;

  @Column({ name: 'run' })
  rut: number;

  @Column({ length: 1, name: 'run_dv' })
  rutDv: string;

  @Column({ length: 50, name: 'apell_paterno' })
  fathersLastname: string;

  @Column({ name: 'grupo_id' })
  @OneToOne(/* istanbul ignore next */ type => Group)
  @JoinColumn({ name: 'grupo_id' })
  group: number;

  @Column({ length: 50, name: 'apell_materno' })
  mothersLastname: string;

  @Column({ length: 100, name: 'nombres' })
  names: string;

  @Column({ name: 'sexo' })
  sexuality: number;

  @Column({ name: 'fec_nacim' })
  birthDate: Date;

  @Column({ name: 'fecha_matricula' })
  enrollmentDate: Date;

  @CreateDateColumn({ name: 'fecha_creacion' })
  timestamp: Date;

  @Column({ name: 'ingresado_gp' })
  gwJoined: boolean;

  @Column({ name: 'fecha_gp' })
  gwDate: Date;

  @Column({ name: 'manual' })
  manual: boolean;

  @Column({ name: 'con_rut' })
  withRut: boolean;

  @Column({ name: 'asistencia_dia_matricula' })
  isPresent: boolean;

  @Column({ length: 1000, name: 'comentario' })
  description: string;

  public close(enrollmentId: number) {
    this.gwJoined = true;
    this.gwDate = new Date();
    this.description =
      "Solicitud Procesada con ID Matricula N " + enrollmentId;
    this.save();
  }

}
