import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Sexuality } from './sexuality.entity';

@Injectable()
export class SexualityService {
  constructor(
    @InjectRepository(Sexuality)
    private readonly sexualityRepository: Repository<Sexuality>,
  ) { }

  public async getAll() {
    return this.sexualityRepository.find({ select : ['id', 'description'] });
  }

}
