import { Test, TestingModule } from '@nestjs/testing';
import { SexualityService } from './sexuality.service';

describe('SexualityService', () => {
  let service: SexualityService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [SexualityService,
        {
          provide: 'SexualityRepository',
          useValue: {
            createQueryBuilder: () => {/**/},
            find: () => {/**/},
          },
        },
      ],
    }).compile();

    service = module.get<SexualityService>(SexualityService);
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });

  it('should call function getAll sexualities.', async () => {
    // tslint:disable-next-line:no-string-literal
    spyOn(service['sexualityRepository'], 'find').and.returnValue(Promise.resolve({}));
    expect(await service.getAll()).toEqual({});
  });

});
