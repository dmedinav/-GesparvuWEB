import { Entity, Column, PrimaryColumn, OneToMany } from 'typeorm';
import { InfantForm } from '../infantForm/infant-form.entity';

@Entity({ name: 'sexualidad' })
export class Sexuality {

  @PrimaryColumn({ name: 'id_sexualidad' })
  id: number;

  @Column({length: 20, name: 'descripcion'})
  description: string;

  @OneToMany(/* istanbul ignore next */ type => InfantForm, /* istanbul ignore next */ infantForm => infantForm.sexuality)
  infantForm: InfantForm;
}
