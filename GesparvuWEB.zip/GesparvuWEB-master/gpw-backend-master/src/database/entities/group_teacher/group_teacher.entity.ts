import { ViewEntity, ViewColumn } from 'typeorm';

@ViewEntity({name: 'view_grupo_docente'})
export class GroupTeacher {

  @ViewColumn()
  teacher: number;

  @ViewColumn()
  group: number;

  @ViewColumn()
  responsable: string;

  @ViewColumn()
  incorporationDate: Date;

  @ViewColumn()
  retirementDate: Date;

}
