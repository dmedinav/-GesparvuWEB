import { Test, TestingModule } from '@nestjs/testing';
import { GroupTeacherService } from './group_teacher.service';

// tslint:disable:no-string-literal
describe('GroupTeacherService', () => {
  let service: GroupTeacherService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [GroupTeacherService,
        {
          provide: 'GroupTeacherRepository',
          useValue: {
            createQueryBuilder: () => {/**/},
          },
        },
      ],
    }).compile();

    service = module.get<GroupTeacherService>(GroupTeacherService);
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });

});
