import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { GroupTeacher } from './group_teacher.entity';

@Injectable()
export class GroupTeacherService {
  constructor(
    @InjectRepository(GroupTeacher)
    private readonly groupTeacherService: Repository<GroupTeacher>,

  ) { }

}
