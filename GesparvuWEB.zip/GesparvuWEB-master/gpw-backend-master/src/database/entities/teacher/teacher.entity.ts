import { Entity, Column, PrimaryGeneratedColumn } from 'typeorm';

@Entity({name: 'docente'})
export class Teacher {

  @PrimaryGeneratedColumn({name: 'id_docente'})
  id: number;

  @Column({name: 'rut'})
  rut: number;

  @Column({length: 1, name: 'dv'})
  rutDv: string;

  @Column({length: 50, name: 'apellido_paterno'})
  fathersLastname: string;

  @Column({length: 50, name: 'apellido_materno'})
  mothersLastname: string;

  @Column({length: 100, name: 'nombres'})
  names: string;

  @Column({name: 'fecha_nacimiento'})
  birthDate: Date;

  @Column({name: 'sexualidad_id'})
  sexuality: number;

  @Column({name: 'pais_id'})
  country: number;

  @Column({name: 'nacionalidad_id'})
  nationality: number;

  @Column({name: 'etnia_id'})
  ethnicGroup: number;

  @Column({length: 20, name: 'celular'})
  cellPhone: string;

  @Column({length: 100, name: 'correo_electronico'})
  email: string;

  @Column({name: 'edo_civil_id'})
  civilStatus: number;

  @Column({name: 'tipo_docente_id'})
  teacherType: number;

}
