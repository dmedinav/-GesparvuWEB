import { ViewEntity, ViewColumn } from 'typeorm';

@ViewEntity({name: 'view_parvulo_sim'})
export class ViewSimInfant {

  @ViewColumn()
  rut: number;

  @ViewColumn()
  rutDv: string;

  @ViewColumn()
  fathersLastname: string;

  @ViewColumn()
  mothersLastname: string;

  @ViewColumn()
  names: string;

  @ViewColumn()
  sexuality: number;

  @ViewColumn()
  birthDate: Date;

}
