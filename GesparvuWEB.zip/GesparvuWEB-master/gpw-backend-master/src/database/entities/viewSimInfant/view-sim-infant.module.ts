import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { ViewSimInfantService } from './view-sim-infant.service';

@Module({
  imports: [TypeOrmModule.forRoot()],
  providers: [ViewSimInfantService],
  exports: [ViewSimInfantService],
})
export class ViewSimInfantModule {}
