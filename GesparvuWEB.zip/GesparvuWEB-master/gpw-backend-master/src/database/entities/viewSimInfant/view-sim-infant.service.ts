import { Injectable } from '@nestjs/common';
import { getManager } from 'typeorm';
import { ViewSimInfant } from './view-sim-infant.entity';

@Injectable()
export class ViewSimInfantService {

  // tslint:disable-next-line:no-empty
  constructor() { }

  public getInfant(rut: number, rutDv: string): Promise<ViewSimInfant> {
    const lowerRutDv = rutDv.toLocaleLowerCase();
    return getManager().createQueryBuilder()
    .from(ViewSimInfant, 'infant')
    .where('infant.rut = :rut', {rut})
    .andWhere('LOWER(infant.rutDv) = :lowerRutDv', {lowerRutDv})
    .getRawOne();
  }

}
