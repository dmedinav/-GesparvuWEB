import { Test, TestingModule } from '@nestjs/testing';
import { ViewSimInfantService } from './view-sim-infant.service';

jest.mock('typeorm', () => ({
  getManager: () => ({
    createQueryBuilder: () => ({
      from: () => ({
        where: () => ({
          andWhere: () => ({
            getRawOne: () => Promise.resolve({}),
          }),
        }),
      }),
    }),
  }),
  ViewColumn: () => jest.fn(),
  ViewEntity: () => jest.fn(),
}));

describe('ViewSimInfantService', () => {
  let service: ViewSimInfantService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [ViewSimInfantService],
    }).compile();

    service = module.get<ViewSimInfantService>(ViewSimInfantService);
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });

  it('should execute a getRawOne.', async () => {
    expect(await service.getInfant(22222222, '1')).toEqual({});
  });

});
