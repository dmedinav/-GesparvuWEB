import { Test, TestingModule } from '@nestjs/testing';
import { GroupService } from './group.service';
import { groupDataMock, groupByTeacherParamsMock } from '../../../common/mocks/group';

describe('GroupService', () => {
  let service: GroupService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [
        GroupService,
        {
          provide: 'GroupRepository',
          useValue: {
            createQueryBuilder: () => {/**/ },
          },
        },
        {
          provide: 'PeriodService',
          useValue: {
            getPeriodQuery: () => {/**/ },
          },
        },
      ],
    }).compile();

    service = module.get<GroupService>(GroupService);
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });

  it('should call the orm api on function call with a sub query.', async () => {
    // tslint:disable-next-line:no-string-literal
    const queryBuilderSpy = spyOn(service['groupRepository'], 'createQueryBuilder').and.returnValue({
      setParameter: () => ({
        setParameter: () => ({
          leftJoin: () => ({
            leftJoin: () => ({
              leftJoin: () => ({
                innerJoin: () => ({
                  where: () => ({
                    select: () => ({
                      addSelect: () => ({
                        orderBy: () => ({
                          orderBy: () => ({
                            getRawMany: () => Promise.resolve(groupDataMock),
                          }),
                        }),
                      }),
                    }),
                  }),
                }),
              }),
            }),
          }),
        }),
      }),
    });
    const enrollment = await service.getGroupsByTeacher(groupByTeacherParamsMock.teacher);

    expect(queryBuilderSpy).toBeCalledWith('group');
    expect(enrollment).toEqual(groupDataMock);
  });

  it('should call the orm api on function call and return a query string', async () => {
    // tslint:disable-next-line:no-string-literal
    const queryBuilderSpy = spyOn(service['groupRepository'], 'createQueryBuilder').and.returnValue({
      innerJoin: () => ({
        innerJoin: () => ({
          innerJoin: () => ({
            innerJoin: () => ({
              where: () => ({
                select: () => ({
                  addSelect: () => ({
                    addSelect: () => ({
                      addSelect: () => ({
                        getQuery: () => Promise.resolve(groupDataMock),
                      }),
                    }),
                  }),
                }),
              }),
            }),
          }),
        }),
      }),
    });
    const enrollment = await service.getGroupLocationQuery(1);
    expect(enrollment).toEqual(groupDataMock);
  });

});
