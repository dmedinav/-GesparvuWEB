import { Group } from './group.entity';
import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { PeriodService } from '../period/period.service';
import { GroupTeacher } from '../group_teacher/group_teacher.entity';
import { Teacher } from '../teacher/teacher.entity';

@Injectable()
export class GroupService {
  constructor(
    @InjectRepository(Group)
    private readonly groupRepository: Repository<Group>,
    private readonly periodService: PeriodService,
  ) { }

  public getGroupsByTeacher(teacherRut: number): Promise<Group[]> {
    const periodQuery = this.periodService.getPeriodQuery();
    return this.groupRepository.createQueryBuilder('group')
      .setParameter('year', new Date().getUTCFullYear().toString())
      .setParameter('month', (new Date().getUTCMonth() + 1).toString())
      .leftJoin(GroupTeacher, 'groupTeacher', 'group.id = groupTeacher.group')
      .leftJoin(Teacher, 'teacher', 'teacher.id = groupTeacher.teacher')
      .leftJoin('group.level', 'level')
      .innerJoin('(' + periodQuery + ')', 'period', 'period.period_ano_parvulario = group.academicYear')
      .where('teacher.rut = :rut', { rut: teacherRut })
      // tslint:disable-next-line: quotemark
      .select("concat(level.label, ' Grupo ', group.name)", 'name')
      .addSelect('group.id', 'id')
      .orderBy('level.code')
      .orderBy('group.name', 'ASC')
      .getRawMany();
  }

  public getGroupLocationQuery(groupId: number): string {
    return this.groupRepository.createQueryBuilder('group')
      .innerJoin('group.establishment', 'establishment')
      .innerJoin('establishment.county', 'county')
      .innerJoin('county.province', 'province')
      .innerJoin('province.region', 'region')
      .where('group.id = :groupid', { groupid: groupId })
      .select('group.id', 'id')
      .addSelect('establishment.id', 'establishment')
      .addSelect('county.id', 'county')
      .addSelect('region.id', 'region')
      .getQuery();
  }

  public async getGroup(groupId: number): Promise<Group> {
    return this.groupRepository.findOne(groupId, {relations: ['establishment']});
  }
}
