import { Holiday } from './../holiday/holiday.entity';
import { Exception } from './../exception/exception.entity';
import { Entity, Column, PrimaryGeneratedColumn, ManyToOne, JoinColumn, OneToMany, OneToOne } from 'typeorm';
import { Enrollment } from '../enrollment/enrollment.entity';
import { Establishment } from '../establishment/establishment.entity';
import { Period } from '../period/period.entity';
import { Level } from '../level/level.entity';

@Entity({name: 'grupo'})
export class Group {

  @PrimaryGeneratedColumn({name: 'id_grupo'})
  id: number;

  @Column({length: 2, name: 'letra'})
  name: string;

  @OneToOne(/* istanbul ignore next */ type => Level)
  @JoinColumn({name: 'nivel_grado_id'})
  level: Level;

  @Column({name: 'modalidad_id'})
  modality: number;

  @Column({name: 'programa_id'})
  program: number;

  @ManyToOne(/* istanbul ignore next */ type => Establishment, /* istanbul ignore next */ establishment => establishment.groups)
  @JoinColumn({name: 'establecimiento_id'})
  establishment: Establishment;

  @Column({name: 'ano_parvulario'})
  academicYear: number;

  @Column({name: 'traspaso_sige'})
  sigeTransfer: number;

  @Column({name: 'traspaso_fecha'})
  transferDate: Date;

  @Column({name: 'capacidad'})
  capacity: number;

  @Column({name: 'jornada_id'})
  workday: number;

  @OneToMany(/* istanbul ignore next */ type => Enrollment, /* istanbul ignore next */ enrollment => enrollment.group)
  enrollments: Enrollment[];

  @OneToMany(/* istanbul ignore next */ type => Exception, /* istanbul ignore next */ exceptions => exceptions.group)
  exceptions: Exception[];

  @OneToMany(/* istanbul ignore next */ type => Holiday, /* istanbul ignore next */ holiday => holiday.group)
  holidays: Holiday[];

  @ManyToOne(/* istanbul ignore next */ type => Period, /* istanbul ignore next */ period => period.academicYear)
  @JoinColumn({name: 'ano_parvulario'})
  period: Period;
}
