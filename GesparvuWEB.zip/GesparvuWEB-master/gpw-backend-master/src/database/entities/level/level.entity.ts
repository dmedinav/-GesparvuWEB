import { Entity, PrimaryGeneratedColumn, Column, JoinColumn, OneToOne } from 'typeorm';
import { Group } from '../../entities/group/group.entity';

@Entity({ name: 'nivel_grado' })
export class Level {

    @PrimaryGeneratedColumn({ name: 'id_nivel_grado' })
    id: number;

    @OneToOne(/* istanbul ignore next */ type => Group)
    @JoinColumn({ name: 'id_nivel_grado' })
    group: Group;

    @Column({ name: 'cod_nivel' })
    code: number;

    @Column({ length: 50, name: 'glosa_nivel' })
    label: string;

    @Column({ name: 'grado_sige_id' })
    grade: number;

    @Column({ length: 100, name: 'rango_edad' })
    ageRange: string;

}
