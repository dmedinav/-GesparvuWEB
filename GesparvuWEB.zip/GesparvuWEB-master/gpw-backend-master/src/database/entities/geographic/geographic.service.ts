import { Region } from './region.entity';
import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';

@Injectable()
export class GeographicService {
  constructor(
    @InjectRepository(Region)
    private readonly regionRepository: Repository<Region>,
  ) { }

  public getRegionsWithProvincesAndCounties(): Promise<Region[]> {
    return this.regionRepository
    .createQueryBuilder('region')
    .leftJoinAndSelect('region.provinces', 'province')
    .leftJoinAndSelect('province.counties', 'county')
    .getMany();
  }
}
