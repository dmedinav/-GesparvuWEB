import { Holiday } from './../holiday/holiday.entity';
import { Entity, Column, PrimaryGeneratedColumn, OneToMany } from 'typeorm';
import { Province } from './province.entity';
import { Exception } from '../exception/exception.entity';

@Entity({name: 'region'})
export class Region {

    @PrimaryGeneratedColumn({name: 'id_region'})
    id: number;

    @Column({length: 80, name: 'nombre'})
    name: string;

    @Column({name: 'cod_region'})
    regionCode: number;

    @OneToMany(/* istanbul ignore next */ type => Province, /* istanbul ignore next */ province => province.region)
    provinces: Province[];

    @OneToMany(/* istanbul ignore next */ type => Exception, /* istanbul ignore next */ exceptions => exceptions.region)
    exceptions: Exception[];

    @OneToMany(/* istanbul ignore next */ type => Holiday, /* istanbul ignore next */ holiday => holiday.region)
    holidays: Holiday[];
}
