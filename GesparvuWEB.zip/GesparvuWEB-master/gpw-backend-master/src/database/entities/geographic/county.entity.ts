import { Holiday } from './../holiday/holiday.entity';
import { Exception } from '../exception/exception.entity';
import { Entity, Column, PrimaryGeneratedColumn, OneToMany, ManyToOne, JoinColumn } from 'typeorm';
import { Province } from './province.entity';
import { Establishment } from '../establishment/establishment.entity';

@Entity({name: 'comuna'})
export class County {

  @PrimaryGeneratedColumn({name: 'id_comuna'})
  id: number;

  @Column({length: 80, name: 'nombre'})
  name: string;

  @ManyToOne(/* istanbul ignore next */ type => Province, /* istanbul ignore next */ province => province.counties)
  @JoinColumn({name: 'provincia_id'})
  province: Province;

  @OneToMany(/* istanbul ignore next */ type => Establishment, /* istanbul ignore next */ establishment => establishment.county)
  establishments: Establishment[];

  @OneToMany(/* istanbul ignore next */ type => Exception, /* istanbul ignore next */ exceptions => exceptions.county)
  exceptions: Exception[];

  @OneToMany(/* istanbul ignore next */ type => Holiday, /* istanbul ignore next */ holiday => holiday.county)
  holidays: Holiday[];
}
