import { Test, TestingModule } from '@nestjs/testing';
import { GeographicService } from './geographic.service';
import { regionDataMock } from '../../../common/mocks/region';

describe('GeographicService', () => {
  let service: GeographicService;
  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [
        GeographicService,
        {
          provide: 'RegionRepository',
          useValue: {
          createQueryBuilder: () => {/**/},
          },
        },
      ],
    }).compile();
    service = module.get<GeographicService>(GeographicService);
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });

  it('should call the orm api on function call.', async () => {
    // tslint:disable-next-line:no-string-literal
    const queryBuilderSpy = spyOn(service['regionRepository'], 'createQueryBuilder').and.returnValue({
      leftJoinAndSelect: () => ({
        leftJoinAndSelect: () => ({
          getMany: () => Promise.resolve(regionDataMock),
        }),
      }),
    });
    const geographicInfo = await service.getRegionsWithProvincesAndCounties();

    expect(queryBuilderSpy).toBeCalledWith('region');
    expect(geographicInfo).toEqual(regionDataMock);
  });
});
