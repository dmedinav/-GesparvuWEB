import { Entity, Column, PrimaryGeneratedColumn, ManyToOne, JoinColumn, OneToMany } from 'typeorm';
import { Region } from './region.entity';
import { County } from './county.entity';

@Entity({name: 'provincia'})
export class Province {

  @PrimaryGeneratedColumn({name: 'id_provincia'})
  id: number;

  @Column({length: 80, name: 'nombre'})
  name: string;

  @ManyToOne(/* istanbul ignore next */ type => Region, /* istanbul ignore next */ region => region.provinces)
  @JoinColumn({name: 'region_id'})
  region: Region;

  @OneToMany(/* istanbul ignore next */ type => County, /* istanbul ignore next */ county => county.province)
  counties: County[];
}
