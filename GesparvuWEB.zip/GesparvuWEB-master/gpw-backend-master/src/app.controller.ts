import { Controller, Get } from '@nestjs/common';

@Controller()
export class AppController {

    constructor() {/**/}

    @Get()
    public getVersion(): any {
      return {
        name: 'JUNJI-RAD-Backend API',
        date: new Date(),
        version: process.env.npm_package_version,
      };
    }
}
