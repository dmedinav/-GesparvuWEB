import { MovementModule } from './api/movements/movement.module';
import { LogService } from './common/logs/logs.service';
import { ExceptionTypeModule } from './api/exceptionType/exception-type.module';
import { HolidayModule } from './database/entities/holiday/holiday.module';
import { ExceptionModule } from './api/exception/exception.module';
import { Module } from '@nestjs/common';
import { AppController } from './app.controller';
import { TypeOrmModule } from '@nestjs/typeorm';
import { EstablishmentModule } from './api/establishment/establishment.module';
import { GroupModule } from './api/group/group.module';
import { EnrollmentModule } from './api/enrollment/enrollment.module';
import { InfantModule } from './api/infant/infant.module';
import { AttendanceModule } from './api/attendance/attendance.module';
import { MovementTypeModule } from './database/entities/movementType/movement-type.module';
import { GeographicModule } from './api/geographic/geographic.module';
import { AuthModule } from './api/auth/auth.module';
import { PeriodModule } from './database/entities/period/period.module';

@Module({
  imports: [
    TypeOrmModule.forRoot(),
    AuthModule,
    EstablishmentModule,
    PeriodModule,
    GroupModule,
    EnrollmentModule,
    InfantModule,
    AttendanceModule,
    MovementModule,
    MovementTypeModule,
    GeographicModule,
    ExceptionModule,
    HolidayModule,
    ExceptionTypeModule,
  ],
  providers: [LogService],
  controllers: [AppController],
})
export class AppModule {}
